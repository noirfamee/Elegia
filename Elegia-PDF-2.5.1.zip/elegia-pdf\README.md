# Elegia PDF

Extensión de Chrome (Manifest V3) para **leer PDFs**, **marcarlos con tintas de color** y **sacar capturas en imagen** de lo marcado. Incluye índice navegable (y generado cuando el PDF no lo trae), búsqueda, notas, salto manual de páginas e impresión con o sin las marcas.

![Pantalla principal](docs/captura-pantalla.png)

## Interfaz

Identidad sobria: papel, tinta y reglas de 1 px, sin esquinas redondeadas; la interfaz habla en sans y deja la mono para los códigos.

- **Barra principal** con controles con nombre: **Documento** (abrir otro PDF), **Buscar** (ocupa el espacio libre y, al usarlo, se estira tapando Tema y Colores; con su contador y flechas), **Tema** (papel de la interfaz y ajustes; muestra sólo el nombre del papel), **Colores** (tintas de los marcatextos), **Estilo de marca** (marcador o subrayado) y **Texto** (A− / % / A+). Se puede **ocultar**: queda una línea con el documento, *Modo oscuro* y *Mostrar barra*.
- **Franja de lectura**: *Página n de N* (se puede escribir el número), el porcentaje leído, *Volver* tras un salto, el **mapa de marcas** (todo el documento en una línea, cada marca en su lugar y con su color; clic para saltar), la cuenta por tinta y los botones **Imprimir** y **Guardar**.
- **Panel lateral** con dos pestañas: **Marcas** (filtro por tinta; cada marca con número, tinta, página e *Ir a la página*; al elegirla aparecen *Copiar*, *Capturar*, *Nota* y *Borrar*; abajo, *Copiar como texto* y *Capturar imagen*) e **Índice** (cada parte con su página y cuadros con tus marcas en esa sección; la entrada donde estás leyendo se marca *estás aquí*).
- **Tema**: el papel de la interfaz (Claro / Vanilla / Gris / Oscuro o *Automático · según la hora del día*) y los ajustes *Imprimir con las marcas* y *Abrir aquí los PDFs de Chrome*.
- **Colores**: los juegos de tintas de los marcatextos, cada uno con sus tintas con nombre, y el ajuste *Invertir texto en tintas oscuras*.

## Características

- **5 temas**, cada uno con sus tintas con nombre (ver abajo), con mezcla *multiply*: el texto sigue legible.
- Dos estilos de marca: bloque de marcador o línea gruesa.
- **Notas** en cada marca: *Nota* en la barra de la selección (marca y abre la nota de una vez), en el menú de la marca o en la lista. La tarjeta sale de la marca unida por un cable; `Ctrl+Enter` guarda, `Esc` cancela. Salen también en *Copiar como texto*.
- **Microanimaciones** (se apagan si el sistema pide *reducir movimiento*): la marca nueva avanza renglón por renglón con un cursor delante y se abre en su lugar en la lista; al buscar, la lupa se vuelve tres puntos que giran, una línea barre la página y el contador cae a su sitio; el cambio de modo abre el papel nuevo en círculo desde el clic, con una luz que recorre las reglas; el logotipo destella al pasar el mouse; los controles se invierten un momento al pulsarlos.
- **Índice del documento**: los marcadores del PDF, con su página, subsecciones plegables y salto directo. Los enlaces internos impresos en el propio PDF también funcionan, y `Volver` regresa a donde estabas.
- **Índice generado** para los PDFs que no traen marcadores: se arma solo a partir de las etiquetas del PDF, de su tabla de contenido impresa o de los títulos detectados por el tamaño y el peso de la letra. Se calcula una vez por documento y se puede regenerar.
- **Buscar en el documento** (`Ctrl+F`): todas las coincidencias con un contorno en la página (la actual, en rojo), contador `03 / 27`, `Enter` / `Mayús+Enter` para recorrerlas. No distingue mayúsculas ni acentos («analisis» encuentra «análisis»).
- **Mapa de marcas** en la franja superior, con aviso al pasar el mouse (`Marca 05 · Rojo · p. 34`).
- **Imprimir** el documento completo (`Ctrl+P`), con o sin las marcas. Sin marcas que pintar la impresión es inmediata y el texto sale vectorial; con marcas se rasteriza a ~150 ppp, con progreso y opción de cancelar.
- **Guardar** (`Ctrl+S`): descarga el PDF original.
- Capturas PNG en alta resolución (página re-renderizada a ~2400 px de ancho): copiar al portapapeles o descargar.
- **Capturar imagen**: una sola hoja con todas las marcas en orden, con el color y la página de cada una.
- Las marcas se guardan automáticamente por documento (`chrome.storage.local`).
- **4 modos de lectura**: Claro (papel blanco), **Vanilla** (papel cálido, descansa la vista), **Gris** (menos brillo, sin color) y Oscuro. La página del PDF toma el tono del modo. *Automático* cambia según la hora: claro de 7 a 18 h, oscuro desde las 18 h.
- **Invertir texto en tintas oscuras**: al marcar con Negro, Carbón, Azul o Vino, la marca queda sólida y el texto se vuelve claro (también en capturas e impresión). Se puede apagar en **Colores**.
- Deshacer / rehacer, marcado automático, atajos de teclado.
- Se abre automáticamente con los PDFs de Chrome (se puede desactivar).

![Ejemplo de «Capturar imagen»](docs/ejemplo-capturar-todos.png)

## Temas y tintas

Se eligen en **Colores**; las teclas `1`–`3` cambian de tinta (con texto seleccionado, lo marcan).

| Tema | Tintas |
|---|---|
| **Elegia** — *identidad de la casa* | Rojo `#E2432A` · Grafito `#8C8880` · Negro `#111111` |
| **New Order** | Piedra `#D9D4C8` · Pizarra `#657A83` · Carbón `#292C30` |
| **Francia** | Azul `#172B55` · Blanco `#F5F0E8` · Rojo `#C93648` |
| **Rosa mexicano** | Rosa `#E4007C` · Pastel `#F5A6C8` · Vino `#7D174D` |
| **Clásico** | Amarillo `#F2D64B` · Rosa `#F07FA8` · Verde `#8FD16A` |

Las tintas oscuras se aplican con transparencia para no tapar el texto, y las muy claras (Piedra, Blanco) llevan un borde fino para notarse sobre el papel. Se ajusta en `THEMES` (`alpha`, `edge`, `ui`) dentro de `viewer.js`; para añadir un tema basta con agregar otra entrada ahí.

Las marcas guardadas conservan su color aunque cambies de tema, incluidas las hechas con temas de versiones anteriores (*Classic*, *Código*).
## Instalación

1. Clona o descarga este repositorio.
2. Abre `chrome://extensions` y activa **Modo de desarrollador**.
3. **Cargar descomprimida** → elige la carpeta del repositorio (la que contiene `manifest.json`).
4. Para PDFs locales: en **Detalles** activa **Permitir el acceso a las URL de archivo**.

## Uso

| Acción | Cómo |
|---|---|
| Abrir un PDF | Ábrelo en Chrome, clic en el ícono, `Alt+Shift+S`, clic derecho en un enlace → *Abrir PDF con Elegia PDF*, o arrástralo a la ventana |
| Marcar | Selecciona texto y elige una tinta en la barra flotante («Marcar en») |
| Marcar + capturar | **Capturar** en la barra flotante |
| Editar una marca | Clic sobre ella en la página (tinta, copiar, captura, borrar) o en la lista del panel (copiar, capturar, nota, borrar) |
| Moverte por el documento | Pestaña **Índice**, el mapa de marcas, los enlaces del propio PDF o *Página n de N* en la franja |
| Buscar una palabra | Campo **Buscar** de la barra o `Ctrl+F`; si tienes texto seleccionado, busca eso |
| Guardar el PDF | **Guardar** o `Ctrl+S`: baja el PDF original, sin las marcas |
| Imprimir | **Imprimir** o `Ctrl+P`; el ajuste *Imprimir con las marcas* (en **Tema**) decide si salen |
| Hoja con todo | **Capturar imagen** en el panel de marcas |

### Atajos

| Tecla | Acción |
|---|---|
| `1`–`3` | Tinta del tema actual (con texto seleccionado, la marca) |
| `H` | Marcar la selección |
| `M` | Activa / desactiva el marcado automático (marca al soltar el mouse) |
| `Ctrl+F` | Buscar en el documento |
| `Enter` / `Mayús+Enter`, `F3`, `Ctrl+G` | Siguiente / anterior coincidencia |
| `I` | Mostrar el índice / volver a las marcas |
| `←` `→` | Página anterior / siguiente |
| `G` | Ir a una página (escribe el número y `Enter`) |
| `Alt+←` | Volver tras saltar por el índice o un enlace |
| `Ctrl+P` | Imprimir |
| `Ctrl+S` | Guardar el PDF |
| `Supr` | Borrar la marca activa |
| `Ctrl+Z` / `Ctrl+Y` | Deshacer / rehacer |
| `Ctrl` + rueda, `Ctrl +/−`, `Ctrl+0` | Zoom / ajustar al ancho |

## Cómo funciona

Chrome no permite que las extensiones modifiquen su visor de PDF nativo, así que la extensión incluye un visor propio basado en [PDF.js](https://mozilla.github.io/pdf.js/).

```
manifest.json     Permisos y configuración MV3
background.js     Service worker: redirige los PDFs al visor, menú contextual, atajo
viewer.html/css   Interfaz del visor
viewer.js         Render de páginas, índice, navegación, marcas, notas, capturas, impresión
toc-gen.js        Índice generado para PDFs sin marcadores
lib/              PDF.js (build min), cmaps y fuentes estándar
icons/            Íconos
docs/             Imágenes de la documentación
```

- **Selección → marca:** se leen los rectángulos reales de los glifos del *text layer*, se agrupan por línea y se guardan **normalizados (0–1)** por página, así sobreviven a cualquier zoom.
- **Capa de marcas:** va entre el canvas del PDF y el text layer, con `mix-blend-mode: multiply`.
- **Búsqueda:** el texto de cada página sale de `getTextContent()` con las mismas opciones que el text layer, así cada fragmento coincide con su `span` (`textLayer.textDivs[i]`). Se compara sin mayúsculas ni acentos y con los espacios colapsados, guardando a qué posición del original corresponde cada carácter; las coincidencias se pintan en su propia capa con los rectángulos reales de los glifos (`Range.getClientRects()`). El texto de las páginas se cachea, y la búsqueda recorre el documento por tandas sin bloquear la lectura.
- **Índice y enlaces:** `getOutline()` da los marcadores y `getAnnotations()` los enlaces de cada página; ambos destinos se resuelven con `getPageIndex()` a página + posición vertical, y se cachean. Los enlaces van en su propia capa encima del texto, desactivada mientras arrastras para seleccionar.
- **Índice generado:** si `getOutline()` no trae nada, `toc-gen.js` lee el texto de todas las páginas (agrupado en líneas) y prueba tres fuentes, de la más fiable a la menos fiable, quedándose con la primera que dé resultado:
  1. **PDF etiquetado:** los nodos `H1`…`H6` de `getStructTree()`, con su texto tomado del contenido marcado.
  2. **Tabla de contenido impresa:** en las primeras páginas busca líneas `Título ...... 23`. El número impreso se traduce a página del PDF con `getPageLabels()`, o calculando el desfase entre la numeración impresa y la del PDF (busca los títulos en el cuerpo y se queda con el desfase que más se repite). El nivel sale de la sangría o, si no hay, de la numeración.
  3. **Tipografía:** las líneas en letra más grande que el texto normal (o en negrita al mismo tamaño) son candidatas. Se descartan encabezados y pies repetidos, párrafos enteros y estilos demasiado frecuentes; los niveles salen del tamaño, el peso y la numeración (`2.` por encima de `2.1`).
  El resultado tiene la misma forma que los marcadores (los destinos son `[página, XYZ, y]`, que `resolveDest` ya entiende) y se guarda en `toc:<fingerprint>`. Para recalcular todos los índices guardados basta con subir `TOC_VERSION`.
- **Capturas:** la página se re-renderiza a alta resolución, se recorta la zona marcada y se dibujan las marcas sobre el canvas.
- **Impresión:** hay dos rutas. Si no hay marcas que pintar (ninguno, o el interruptor apagado) el PDF original se imprime tal cual desde un `iframe` con su `blob:` — inmediato y vectorial, sin rasterizar nada. Si hay marcas que pintar no queda otra que rasterizar: cada página se renderiza a ~150 ppp (tope de 16 MP por página) con `intent: "print"`, se le pintan encima los marcas y se arma todo en un contenedor que solo existe en `@media print`, con `@page` del tamaño real del PDF. Esa ruta va de 2 a 3 páginas en paralelo, espera los `decode()` al final y se puede cancelar a media preparación. Si la ruta directa falla (por ejemplo, si Chrome está configurado para descargar los PDFs en vez de abrirlos) cae sola a la rasterizada.
- **Datos:** clave `doc:<fingerprint del PDF>`, así que las marcas (y sus notas) reaparecen aunque cambies el archivo de lugar.

## Permisos

| Permiso | Para qué |
|---|---|
| `storage` | Guardar marcas, notas y preferencias |
| `webRequest` + `<all_urls>` | Detectar respuestas `application/pdf` y abrirlas en el visor |
| `tabs`, `contextMenus` | Redirigir pestañas y menú de clic derecho |
| `clipboardWrite` | Copiar imágenes y texto |

Todo ocurre en local; la extensión no envía datos a ningún servidor.

## Limitaciones

- Solo PDFs con capa de texto. Los escaneados necesitan OCR (no incluido).
- Las marcas no se escriben dentro del PDF; viven en la extensión.
- El índice generado es una aproximación: con maquetaciones raras puede saltarse títulos o colar alguna línea que no lo es. En los PDFs escaneados (sin texto) no se puede generar; ahí quedan los enlaces impresos y el salto por número de página.
- Imprimir **con** las marcas rasteriza las páginas, así que ese PDF impreso no conserva el texto seleccionable y tarda más cuanto más largo sea el documento. Imprimir sin ellos no tiene ninguna de las dos desventajas.

## Ideas a futuro

- Exportar las marcas a Markdown / JSON.
- Guardar un PDF con las anotaciones incrustadas.
- OCR para PDFs escaneados.

## Licencia

MIT — ver [LICENSE](LICENSE). Incluye PDF.js (Apache-2.0) en `lib/`.
