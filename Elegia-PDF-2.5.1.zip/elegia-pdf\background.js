// Elegia PDF — service worker
const VIEWER = chrome.runtime.getURL("viewer.html");
// URLs que el usuario pidió ver en el visor nativo de Chrome (no redirigir)
async function isBypassed(url) {
  const { bypass = {} } = await chrome.storage.session.get("bypass");
  const t = bypass[url];
  return !!t && Date.now() - t < 120_000;
}
async function addBypass(url) {
  const { bypass = {} } = await chrome.storage.session.get("bypass");
  bypass[url] = Date.now();
  await chrome.storage.session.set({ bypass });
}

const viewerUrlFor = (url) => `${VIEWER}?file=${encodeURIComponent(url)}`;
const looksLikePdf = (url) =>
  /^(https?|file|ftp):/i.test(url || "") && /\.pdf($|[?#])/i.test(url);

async function shouldRedirect(url) {
  const { autoOpen = true } = await chrome.storage.local.get("autoOpen");
  return autoOpen && !(await isBypassed(url));
}

// --- Clic en el ícono: abre el PDF de la pestaña actual (o el visor vacío)
chrome.action.onClicked.addListener(async (tab) => {
  if (tab?.url && /^(https?|file):/i.test(tab.url) && !tab.url.startsWith(VIEWER)) {
    // Si no parece PDF igual lo intentamos: el visor avisa si no lo es.
    chrome.tabs.update(tab.id, { url: viewerUrlFor(tab.url) });
  } else {
    chrome.tabs.create({ url: VIEWER });
  }
});

// --- Menú contextual
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "open-link",
      title: "Abrir PDF con Elegia PDF",
      contexts: ["link"]
    });
    chrome.contextMenus.create({
      id: "open-page",
      title: "Subrayar este PDF con Elegia PDF",
      contexts: ["page"],
      documentUrlPatterns: ["*://*/*.pdf", "*://*/*.pdf?*", "file:///*.pdf", "file:///*.PDF"]
    });
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "open-link" && info.linkUrl) {
    chrome.tabs.create({ url: viewerUrlFor(info.linkUrl), index: (tab?.index ?? 0) + 1 });
  } else if (info.menuItemId === "open-page" && tab) {
    chrome.tabs.update(tab.id, { url: viewerUrlFor(info.pageUrl || tab.url) });
  }
});

// --- Apertura automática: detecta respuestas PDF (por Content-Type) en pestañas
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.tabId < 0 || details.method !== "GET") return;
    if (details.statusCode < 200 || details.statusCode >= 300) return;
    const ct = (details.responseHeaders || []).find((h) => h.name.toLowerCase() === "content-type");
    const cd = (details.responseHeaders || []).find((h) => h.name.toLowerCase() === "content-disposition");
    const isPdf = ct && /application\/(x-)?pdf/i.test(ct.value || "");
    const isAttachment = cd && /attachment/i.test(cd.value || "");
    if (!isPdf || isAttachment) return;
    shouldRedirect(details.url).then((on) => {
      if (on) chrome.tabs.update(details.tabId, { url: viewerUrlFor(details.url) });
    });
  },
  { urls: ["<all_urls>"], types: ["main_frame"] },
  ["responseHeaders"]
);

// PDFs locales (file://) no pasan por webRequest
chrome.tabs.onUpdated.addListener((tabId, change) => {
  const url = change.url;
  if (!url || !url.startsWith("file:") || !looksLikePdf(url)) return;
  shouldRedirect(url).then((on) => {
    if (on) chrome.tabs.update(tabId, { url: viewerUrlFor(url) });
  });
});

// Mensajes desde el visor
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "open-native" && msg.url) {
    addBypass(msg.url).then(() => {
      chrome.tabs.update(sender.tab.id, { url: msg.url });
      sendResponse({ ok: true });
    });
    return true;
  }
});
