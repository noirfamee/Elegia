/* ============================================================
   Índice generado para PDFs sin marcadores
   Tres fuentes, de la más fiable a la menos; se usa la primera que dé resultado:
     1. tagged    — la estructura etiquetada del PDF (H1…H6)
     2. printed   — la tabla de contenido impresa en las primeras páginas
     3. generated — títulos detectados por el tamaño y el peso de la letra
   El resultado tiene la forma de getOutline(): { title, dest, items }, con
   dest = [índice de página, { name: "XYZ" }, null, y, null], que resolveDest ya entiende.
   ============================================================ */

export const TOC_VERSION = 1; // súbelo si cambia el algoritmo: invalida los índices guardados
const MAX_PAGES = 3000;

/**
 * @returns {Promise<{source: "tagged"|"printed"|"generated", items: object[]} | null>}
 *          null si no encontró nada o si el documento cambió a media lectura
 */
export async function generateToc(pdf, { onProgress = () => {}, isStale = () => false, isBusy = () => false } = {}) {
  const pages = await readPages(pdf, onProgress, isStale, isBusy);
  if (!pages || isStale()) return null;

  const tagged = await fromStructTree(pdf, pages, isStale);
  if (isStale()) return null;
  if (tagged) return { source: "tagged", items: toOutline(tagged) };

  const printed = await fromPrintedToc(pdf, pages);
  if (isStale()) return null;
  if (printed) return { source: "printed", items: toOutline(printed) };

  await loadFontWeights(pdf, pages, isStale, isBusy);
  if (isStale()) return null;
  const typo = fromTypography(pages);
  return typo ? { source: "generated", items: toOutline(typo) } : null;
}

/* ============================================================
   Utilidades de texto
   ============================================================ */
const idle = () => new Promise((r) => setTimeout(r, 0));
const clean = (s) => s.replace(/[­]/g, "").replace(/\s+/g, " ").trim();
const hasLetter = (s) => /\p{L}/u.test(s);
/** minúsculas, sin acentos ni puntuación: para comparar títulos */
const norm = (s) => s.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();

const NUMBERING = /^(?:(?:cap[ií]tulo|chapter|parte|part|secci[oó]n|section|anexo|ap[eé]ndice|appendix|libro|book|tema|unidad|unit|lecci[oó]n|lesson)\b\s*[\dIVXLCivxlc]*\.?|(\d{1,2}(?:\.\d{1,2}){0,4})\.?(?=\s|$)|[IVXLC]{1,6}\.(?=\s)|[A-Z]\.(?=\s))/u;
/** profundidad de la numeración: «2.3.1 Algo» → 3, «Capítulo 4» → 1, sin numerar → 0 */
function numberingDepth(t) {
  const m = NUMBERING.exec(t);
  if (!m) return 0;
  return m[1] ? m[1].split(".").length : 1;
}
const stripNumbering = (t) => t.replace(NUMBERING, "").replace(/^[\s.:–—-]+/, "");

const ROMAN = /^[ivxlcdm]{1,7}$/i;
function romanToInt(s) {
  const v = { i: 1, v: 5, x: 10, l: 50, c: 100, d: 500, m: 1000 };
  let n = 0;
  s = s.toLowerCase();
  for (let i = 0; i < s.length; i++) {
    const a = v[s[i]], b = v[s[i + 1]] || 0;
    n += a < b ? -a : a;
  }
  return n;
}

/* ============================================================
   Lectura: el texto de cada página agrupado en líneas
   ============================================================ */
async function readPages(pdf, onProgress, isStale, isBusy) {
  const n = Math.min(pdf.numPages, MAX_PAGES);
  const out = [];
  for (let num = 1; num <= n; num++) {
    // si el visor está dibujando una página, se espera: leer no debe retrasar lo que ves
    while (isBusy() && !isStale()) await new Promise((r) => setTimeout(r, 50));
    if (isStale()) return null;
    try {
      const page = await pdf.getPage(num);
      const vp = page.getViewport({ scale: 1 });
      const tc = await page.getTextContent({ includeMarkedContent: true });
      out.push({ num, ...buildLines(tc.items, vp) });
    } catch (e) {
      if (isStale()) return null;
      out.push({ num, lines: [], marked: new Map() });
    }
    if (num % 8 === 0 || num === n) { onProgress(num, n); await idle(); }
  }
  return out;
}

/**
 * Une los fragmentos de texto que comparten línea base.
 * Cada línea guarda sus «segmentos» (lo separado por un hueco grande): sirve para
 * reconocer «Título ............ 23» aunque los puntos guía no sean texto.
 */
function buildLines(items, vp) {
  const lines = [], marked = new Map(), stack = [];
  let cur = null;
  for (const it of items) {
    if (it.type) { // contenido marcado (PDF etiquetado)
      if (it.type === "endMarkedContent") stack.pop();
      else stack.push(it.id ?? null);
      continue;
    }
    const s = it.str;
    if (!s) continue;
    const [, b, c, d, x, y] = it.transform;
    if (Math.abs(b) > 0.01 || Math.abs(c) > 0.01) continue; // sólo texto horizontal
    const size = Math.abs(d);
    if (size < 1) continue;

    const mcid = stack.findLast((v) => v != null);
    if (mcid != null) {
      const m = marked.get(mcid);
      if (m) m.text += s;
      else marked.set(mcid, { text: s, y, size });
    }
    if (!s.trim()) { if (cur) cur.space = true; continue; }

    const gap = cur ? x - cur.x2 : 0;
    if (cur && Math.abs(cur.y - y) < Math.max(cur.size, size) * 0.45 && gap > -size * 0.5) {
      const seg = cur.segs.at(-1);
      if (gap > size * 1.5) cur.segs.push({ x, text: s });
      else seg.text += (cur.space || gap > size * 0.15) && !/\s$/.test(seg.text) && !/^\s/.test(s) ? " " + s : s;
      cur.x2 = Math.max(cur.x2, x + it.width);
      cur.space = !!it.hasEOL;
    } else {
      cur = { x, y, x2: x + it.width, size, segs: [{ x, text: s }], sizes: new Map(), fonts: new Map(), space: false };
      lines.push(cur);
    }
    const k = Math.round(size * 2) / 2, ch = s.trim().length;
    cur.sizes.set(k, (cur.sizes.get(k) || 0) + ch);
    cur.fonts.set(it.fontName, (cur.fonts.get(it.fontName) || 0) + ch);
  }
  for (const l of lines) {
    l.segs.forEach((g) => (g.text = clean(g.text)));
    l.text = l.segs.map((g) => g.text).join(" ");
    l.chars = [...l.sizes.values()].reduce((a, v) => a + v, 0);
    l.size = [...l.sizes].sort((a, b) => b[1] - a[1])[0][0]; // el tamaño que más caracteres ocupa
    l.ry = vp.convertToViewportPoint(l.x, l.y)[1] / vp.height; // 0 arriba … 1 abajo
    l.top = l.y + l.size;                                      // y del destino (coordenadas PDF)
    l.bold = false;
    delete l.sizes; delete l.space;
  }
  return { lines, marked };
}

/* ============================================================
   1. PDF etiquetado: los nodos H1…H6 del árbol de estructura
   ============================================================ */
const HEADING_ROLE = /^(?:h|heading\s*|t[ií]tulo\s*|encabezado\s*)([1-6])$/i;

async function fromStructTree(pdf, pages, isStale) {
  if (!pages.some((p) => p.marked.size)) return null;
  const out = [];
  for (const pg of pages) {
    if (isStale()) return null;
    if (!pg.marked.size) continue;
    let tree = null;
    try { tree = await (await pdf.getPage(pg.num)).getStructTree(); } catch {}
    if (tree) walkStruct(tree, pg, out);
  }
  return out.length >= 2 ? flattenSingleTop(rankLevels(out)) : null;
}

function walkStruct(node, pg, out) {
  for (const ch of node.children || []) {
    if (ch.type) continue; // contenido, anotación u objeto: no es un nodo de estructura
    const role = (ch.role || "").trim();
    const m = HEADING_ROLE.exec(role);
    const level = m ? +m[1] : role === "Title" ? 0 : role === "H" ? 1 : null;
    if (level == null) { walkStruct(ch, pg, out); continue; }
    const ids = [];
    collectIds(ch, ids);
    const parts = ids.map((id) => pg.marked.get(id)).filter(Boolean);
    const title = clean(parts.map((p) => p.text).join(" "));
    if (parts.length && hasLetter(title) && title.length <= 200) {
      out.push({ level, title, page: pg.num, top: parts[0].y + parts[0].size });
    }
  }
}
function collectIds(node, ids) {
  for (const ch of node.children || []) {
    if (ch.type === "content") ids.push(ch.id);
    else if (!ch.type) collectIds(ch, ids);
  }
}

/* ============================================================
   2. Tabla de contenido impresa
   ============================================================ */
const TOC_HEADING = /^(?:[íi]ndice(?: general| de contenidos?)?|contenidos?|sumario|tabla de contenidos?|table of contents|contents)$/i;
const LEADER = /^(.*?[\p{L}\p{N})\]»"'”?!])\s*(?:[.·…_‥⋯]\s*){3,}(\d{1,4}|[ivxlcdm]{1,7})$/iu;
const PAGE_NUM = /^(?:\d{1,4}|[ivxlcdm]{1,7})$/i;

/** «Título ...... 23» → { title, label: "23" } */
function tocEntry(line) {
  let title = null, label = null;
  const m = LEADER.exec(line.text);
  if (m) { title = m[1]; label = m[2]; }
  else if (line.segs.length >= 2 && PAGE_NUM.test(line.segs.at(-1).text)) {
    title = line.segs.slice(0, -1).map((g) => g.text).join(" ");
    label = line.segs.at(-1).text;
  }
  if (!title) return null;
  title = clean(title.replace(/[\s.·…_‥⋯]+$/, ""));
  if (title.length < 2 || !hasLetter(title) || TOC_HEADING.test(title)) return null;
  return { title, label: label.toLowerCase(), x: line.x, size: line.size };
}

function tocPageEntries(pg) {
  const entries = [];
  let words = 0, heading = false, pending = null;
  for (const l of pg.lines) {
    if (!hasLetter(l.text)) continue;
    words++;
    if (TOC_HEADING.test(l.text.replace(/[:.]$/, ""))) { heading = true; pending = null; continue; }
    const e = tocEntry(l);
    if (e) {
      // título largo partido en dos líneas: la primera no lleva número
      if (pending && pending.y - l.y < l.size * 2.4 && pending.y > l.y && l.x >= pending.x - l.size) {
        e.title = clean(pending.text + " " + e.title);
        e.x = Math.min(e.x, pending.x);
      }
      entries.push(e);
      pending = null;
    } else pending = l.text.length < 140 ? l : null;
  }
  const isToc = entries.length >= 4 && entries.length >= words * 0.35 || heading && entries.length >= 3;
  return isToc ? entries.map((e) => ({ ...e, tocPage: pg.num })) : null;
}

/** ¿la página tiene una línea que empiece con este título? → la línea */
function findTitle(pg, want) {
  if (!pg) return null;
  pg.norms ??= pg.lines.map((l) => norm(l.text));
  const head = want.slice(0, 40);
  for (let i = 0; i < pg.norms.length; i++) {
    const n = pg.norms[i];
    if (!n) continue;
    if (n.startsWith(head) || n.length >= 8 && n.length >= want.length * 0.5 && want.startsWith(n)) return pg.lines[i];
    // el título también puede venir numerado en el cuerpo y no en la tabla, o al revés
    const bare = norm(stripNumbering(pg.lines[i].text));
    if (bare && bare.startsWith(head)) return pg.lines[i];
  }
  return null;
}

async function fromPrintedToc(pdf, pages) {
  const limit = Math.min(pages.length, 40, Math.max(12, Math.ceil(pages.length * 0.15)));
  let entries = [], last = 0, misses = 0;
  for (let i = 0; i < limit; i++) {
    const found = tocPageEntries(pages[i]);
    if (found) { entries.push(...found); last = pages[i].num; misses = 0; }
    else if (entries.length && ++misses > 1) break; // la tabla ya terminó
  }
  if (entries.length < 3) return null;

  // los números de página deben ir (casi siempre) en aumento
  const arabic = entries.filter((e) => /^\d+$/.test(e.label)).map((e) => +e.label);
  let up = 0;
  for (let i = 1; i < arabic.length; i++) if (arabic[i] >= arabic[i - 1]) up++;
  if (arabic.length < 3 || up < (arabic.length - 1) * 0.75) return null;

  // número impreso → página del PDF: primero las etiquetas de página, si son de verdad
  let byLabel = null;
  try {
    const labels = await pdf.getPageLabels();
    if (labels?.some((l, i) => String(l).trim() !== String(i + 1))) {
      byLabel = new Map();
      labels.forEach((l, i) => { const k = String(l).trim().toLowerCase(); if (k && !byLabel.has(k)) byLabel.set(k, i + 1); });
    }
  } catch {}

  // si no, el desfase entre la numeración impresa y la del PDF: el que más se repite
  let offset = 0;
  if (!byLabel) {
    const votes = new Map();
    for (const e of entries.slice(0, 40)) {
      if (!/^\d+$/.test(e.label)) continue;
      const want = norm(stripNumbering(e.title)) || norm(e.title);
      if (want.length < 4) continue;
      const n = +e.label;
      for (let p = Math.max(last + 1, n - 10); p <= Math.min(pages.length, n + 80); p++) {
        if (findTitle(pages[p - 1], want)) { votes.set(p - n, (votes.get(p - n) || 0) + 1); break; }
      }
    }
    const best = [...votes].sort((a, b) => b[1] - a[1])[0];
    if (best) offset = best[0];
  }

  // niveles: por sangría (relativa al margen de cada página) o, si no hay, por numeración
  const minX = new Map();
  for (const e of entries) minX.set(e.tocPage, Math.min(minX.get(e.tocPage) ?? Infinity, e.x));
  const rel = entries.map((e) => e.x - minX.get(e.tocPage));
  const tol = Math.max(4, median(entries.map((e) => e.size)) * 0.8);
  const steps = [];
  for (const r of [...rel].sort((a, b) => a - b)) if (!steps.length || r - steps.at(-1) > tol) steps.push(r);
  const byIndent = steps.length >= 2 && steps.length <= 5;

  const out = [];
  entries.forEach((e, i) => {
    let page;
    if (byLabel?.has(e.label)) page = byLabel.get(e.label);
    else if (/^\d+$/.test(e.label)) page = +e.label + offset;
    else if (ROMAN.test(e.label)) page = romanToInt(e.label);
    if (!page) return;
    page = Math.max(1, Math.min(pages.length, page));

    // afina la página (±2) buscando el título y de paso toma su posición vertical
    const want = norm(stripNumbering(e.title)) || norm(e.title);
    let top = null;
    if (want.length >= 3) {
      for (const p of [page, page + 1, page - 1, page + 2, page - 2]) {
        if (p <= last || p < 1 || p > pages.length) continue;
        const hit = findTitle(pages[p - 1], want);
        if (hit) { page = p; top = hit.top; break; }
      }
    }
    let level;
    if (byIndent) level = steps.findLastIndex((s) => rel[i] >= s - tol / 2);
    else level = Math.max(0, numberingDepth(e.title) - 1);
    out.push({ level: Math.max(0, level), title: e.title, page, top });
  });
  return out.length >= 3 ? flattenSingleTop(out) : null;
}

function median(a) {
  const s = [...a].sort((x, y) => x - y);
  return s.length ? s[Math.floor(s.length / 2)] : 0;
}

/* ============================================================
   3. Heurística tipográfica
   ============================================================ */
const BOLD_NAME = /bold|black|heavy|semibold|demi|extrab|ultrab|negrita/i;

/** Qué fuentes son negritas. Las fuentes sólo llegan a commonObjs cuando se arma la lista
    de operaciones de alguna página que las usa, así que se pide la de una página por fuente. */
async function loadFontWeights(pdf, pages, isStale, isBusy = () => false) {
  const firstPage = new Map();
  for (const pg of pages) for (const l of pg.lines) for (const f of l.fonts.keys()) if (!firstPage.has(f)) firstPage.set(f, pg.num);
  const weights = new Map(), done = new Set();
  for (const [f, num] of firstPage) {
    while (isBusy() && !isStale()) await new Promise((r) => setTimeout(r, 50));
    if (isStale()) return;
    try {
      const page = await pdf.getPage(num);
      const objs = page.commonObjs;
      if (!objs.has(f) && !done.has(num)) { done.add(num); await page.getOperatorList(); }
      const font = await new Promise((res) => {
        const t = setTimeout(() => res(null), 3000);
        objs.get(f, (v) => { clearTimeout(t); res(v); });
      });
      weights.set(f, !!(font && (font.bold || font.black || BOLD_NAME.test(font.name || ""))));
    } catch { weights.set(f, false); }
  }
  for (const pg of pages) for (const l of pg.lines) {
    let b = 0;
    for (const [f, n] of l.fonts) if (weights.get(f)) b += n;
    l.bold = b >= l.chars * 0.85;
  }
}

/** Encabezados y pies de página: textos (sin contar los dígitos) que se repiten arriba o abajo */
function runningLines(pages) {
  const seen = new Map();
  for (const pg of pages) for (const l of pg.lines) {
    if (l.ry > 0.1 && l.ry < 0.9) continue;
    const k = (l.ry <= 0.1 ? "t:" : "b:") + norm(l.text).replace(/\d+/g, "#");
    l.runKey = k;
    (seen.get(k) || seen.set(k, new Set()).get(k)).add(pg.num);
  }
  const min = Math.max(3, pages.length * 0.2);
  const out = new Set();
  for (const pg of pages) for (const l of pg.lines) if (l.runKey && seen.get(l.runKey).size >= min) out.add(l);
  return out;
}

function fromTypography(pages) {
  // tamaño y peso del texto normal: el que más caracteres ocupa
  const hist = new Map();
  let total = 0, boldChars = 0;
  for (const pg of pages) for (const l of pg.lines) {
    hist.set(l.size, (hist.get(l.size) || 0) + l.chars);
    total += l.chars;
    if (l.bold) boldChars += l.chars;
  }
  if (!total) return null;
  const body = [...hist].sort((a, b) => b[1] - a[1])[0][0];
  const bodyBold = boldChars > total * 0.5;
  const running = runningLines(pages);

  let cands = [];
  for (const pg of pages) {
    let prev = null, prevIdx = -9;
    pg.lines.forEach((l, i) => {
      const t = l.text;
      if (t.length < 2 || t.length > 160 || !hasLetter(t) || running.has(l) || /[,;]$/.test(t)) return;
      const num = numberingDepth(t);
      const big = l.size >= body * 1.12;
      const strong = !bodyBold && l.bold && l.size >= body * 0.95 && t.length <= 90 && (num || !/[.:]$/.test(t));
      if (!big && !strong) return;
      if (!num && /\.$/.test(t) && t.length > 40) return; // una frase normal, no un título
      const key = `${l.size}|${l.bold ? 1 : 0}`;
      // un título largo partido en varias líneas seguidas, con el mismo estilo
      if (prev && prevIdx === i - 1 && prev.key === key && prev.y - l.y > 0 && prev.y - l.y < l.size * 1.8) {
        prev.title = clean(prev.title + " " + t);
        prev.y = l.y;
        prev.lines++;
      } else {
        prev = { key, size: l.size, bold: l.bold, title: t, page: pg.num, top: l.top, y: l.y, lines: 1, num };
        cands.push(prev);
      }
      prevIdx = i;
    });
  }
  // párrafos enteros en letra grande no son títulos
  cands = cands.filter((c) => c.lines <= 3 && c.title.length <= 200);
  // en la portada sólo cuenta el título: autor, fecha, etc. llevan estilos que no se repiten
  const elsewhere = new Set(cands.filter((c) => c.page > 1).map((c) => c.key));
  const firstOnCover = cands.find((c) => c.page === 1);
  cands = cands.filter((c) => c.page > 1 || c === firstOnCover || elsewhere.has(c.key));

  // un estilo que aparece en casi todo el documento tampoco es de títulos
  const count = new Map();
  for (const c of cands) count.set(c.key, (count.get(c.key) || 0) + 1);
  for (const [k, n] of count) if (n > 25 && n > pages.length * 2.5) count.delete(k);

  // niveles: de la letra más grande a la más chica, negrita antes que normal; máximo 4
  const keys = [...count.keys()]
    .map((k) => { const [s, b] = k.split("|"); return { k, s: +s, b: +b }; })
    .sort((a, b) => b.s - a.s || b.b - a.b)
    .slice(0, 4)
    .map((x) => x.k);
  // con el mismo estilo, la numeración separa niveles: «2.» por encima de «2.1»
  // (sin numerar cuenta como un nivel de numeración, para no quedar por encima de «1.»)
  let out = cands
    .filter((c) => keys.includes(c.key))
    .map((c) => ({ level: keys.indexOf(c.key) * 10 + Math.max(1, c.num), title: c.title, page: c.page, top: c.top }));

  // demasiadas entradas: se quitan los niveles más finos
  out = rankLevels(out);
  let maxLevel = Math.max(0, ...out.map((e) => e.level));
  while (out.length > 400 && maxLevel > 0) { out = out.filter((e) => e.level < maxLevel); maxLevel--; }
  return out.length >= 2 ? flattenSingleTop(out) : null;
}

/* ============================================================
   Armado del árbol
   ============================================================ */
/** Comprime los niveles usados a 0, 1, 2… (H1 y H3 sin H2 → 0 y 1) */
function rankLevels(entries) {
  const used = [...new Set(entries.map((e) => e.level))].sort((a, b) => a - b);
  return entries.map((e) => ({ ...e, level: used.indexOf(e.level) }));
}

/** Si el nivel superior es una sola entrada al principio (el título de la portada),
    se deja como hermana de las demás para que no esconda todo el índice debajo de ella. */
function flattenSingleTop(entries) {
  const top = entries.filter((e) => e.level === 0);
  if (top.length === 1 && entries[0].level === 0 && entries.length > 1) {
    return entries.map((e, i) => (i === 0 ? e : { ...e, level: Math.max(0, e.level - 1) }));
  }
  return entries;
}

function toOutline(entries) {
  const root = { items: [] }, stack = [{ level: -1, node: root }];
  for (const e of entries) {
    while (stack.at(-1).level >= e.level) stack.pop();
    const node = { title: e.title, dest: [e.page - 1, { name: "XYZ" }, null, e.top ?? null, null], items: [] };
    stack.at(-1).node.items.push(node);
    stack.push({ level: e.level, node });
  }
  return root.items;
}
