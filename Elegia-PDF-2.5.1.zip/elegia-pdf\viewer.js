import * as pdfjsLib from "./lib/pdf.min.mjs";
import { generateToc, TOC_VERSION } from "./toc-gen.js";

pdfjsLib.GlobalWorkerOptions.workerSrc = "./lib/pdf.worker.min.mjs";
const hasChrome = typeof chrome !== "undefined" && !!chrome.storage;
const APP = "Elegia PDF";

/* ============================================================
   Configuración
   ============================================================ */
/* Temas, cada uno con sus tintas con nombre (las teclas 1–4 las eligen).
   alpha = opacidad del marcador (los oscuros se aclaran para no tapar el texto)
   edge  = borde fino para colores muy claros sobre la página blanca
   ui    = versión visible del color sobre la interfaz oscura
   Los id de las tintas no cambian nunca: las marcas guardadas los usan. */
const THEMES = [
  { id: "elegia", name: "Elegia", sub: "Identidad de la casa", def: 0,
    colors: [
      { id: "el-rojo",    name: "Rojo",    hex: "#E2432A", alpha: 0.62 },
      { id: "el-grafito", name: "Grafito", hex: "#8C8880", alpha: 0.6 },
      { id: "el-negro",   name: "Negro",   hex: "#111111", alpha: 0.3, ui: "#9A968E" },
    ] },
  { id: "neworder", name: "New Order", sub: "Piedra, pizarra y carbón", def: 1,
    colors: [
      { id: "no-paper", name: "Piedra",  hex: "#D9D4C8", alpha: 1,   edge: "rgba(70,58,30,.42)" },
      { id: "no-steel", name: "Pizarra", hex: "#657A83", alpha: 0.85 },
      { id: "no-char",  name: "Carbón",  hex: "#292C30", alpha: 0.52, ui: "#8b939b" },
    ] },
  { id: "francia", name: "Francia", sub: "Azul, blanco y rojo", def: 2,
    colors: [
      { id: "fr-navy",  name: "Azul",   hex: "#172B55", alpha: 0.52, ui: "#4f76c9" },
      { id: "fr-ivory", name: "Blanco", hex: "#F5F0E8", alpha: 1,   edge: "rgba(110,85,40,.45)" },
      { id: "fr-red",   name: "Rojo",   hex: "#C93648", alpha: 0.88 },
    ] },
  { id: "rosa", name: "Rosa mexicano", sub: "Rosa, pastel y vino", def: 0,
    colors: [
      { id: "rm-rosa",   name: "Rosa",   hex: "#E4007C", alpha: 1 },
      { id: "rm-chicle", name: "Pastel", hex: "#F5A6C8", alpha: 1 },
      { id: "rm-bugam",  name: "Vino",   hex: "#7D174D", alpha: 0.55, ui: "#c2417f" },
    ] },
  { id: "clasico", name: "Clásico", sub: "Amarillo, rosa y verde", def: 0,
    colors: [
      { id: "cs-amarillo", name: "Amarillo", hex: "#F2D64B", alpha: 0.85 },
      { id: "cs-rosa",     name: "Rosa",     hex: "#F07FA8", alpha: 0.72 },
      { id: "cs-verde",    name: "Verde",    hex: "#8FD16A", alpha: 0.75 },
    ] },
];
// marcas hechas con temas que ya no están (siguen viéndose igual)
const LEGACY = [
  { id: "co-amarillo", name: "Amarillo", hex: "#E9C43C", alpha: 0.85 },
  { id: "co-rojo", name: "Rojo", hex: "#D64A34", alpha: 0.7 },
  { id: "co-azul", name: "Azul", hex: "#2F64A8", alpha: 0.55, ui: "#6F9BE0" },
  { id: "co-verde", name: "Verde", hex: "#3F8F5A", alpha: 0.6 },
  { id: "cl-amarillo", name: "Amarillo", hex: "#FFFF00", alpha: 1 },
  { id: "cl-verde", name: "Verde", hex: "#39FF14", alpha: 1 },
  { id: "cl-naranja", name: "Naranja", hex: "#FF8000", alpha: 1 },
  { id: "yellow", name: "Amarillo", hex: "#FFE500" }, { id: "pink", name: "Rosa", hex: "#FF3EA5" },
  { id: "green", name: "Verde", hex: "#00E676" },    { id: "blue", name: "Cian", hex: "#00C8FF" },
  { id: "orange", name: "Naranja", hex: "#FF8A00" }, { id: "purple", name: "Morado", hex: "#B45CFF" },
];
const ALL_COLORS = [...THEMES.flatMap((t) => t.colors), ...LEGACY];
const colorDef = (id) => ALL_COLORS.find((c) => c.id === id) || THEMES[0].colors[0];
/** El fondo de la interfaz es casi del color de la tinta: necesita un contorno para verse */
const needsEdge = (def) => !!def.edge || (document.documentElement.dataset.mode === "dark" && !!def.ui);
/** Tinta oscura (Negro, Carbón, Azul, Vino…): luminancia relativa baja */
function isDarkInk(def) {
  const n = parseInt(def.hex.slice(1, 7), 16);
  const lin = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
  return 0.2126 * lin(n >> 16) + 0.7152 * lin((n >> 8) & 255) + 0.0722 * lin(n & 255) < 0.08;
}
/** «Invertir texto en tintas oscuras»: la marca va sólida y el texto queda claro (no en modo oscuro: ahí ya es claro) */
const inverts = (h) => state.invertDark && h.style !== "underline" && isDarkInk(colorDef(h.color));

/* Modos de lectura: el papel de la interfaz y de la página */
const MODES = {
  light:   { name: "Claro",   swatch: "#FAF9F6", desc: "papel blanco, máximo contraste" },
  vanilla: { name: "Vanilla", swatch: "#F6EED6", desc: "papel cálido, descansa la vista" },
  gris:    { name: "Gris",    swatch: "#B4B4B1", desc: "menos brillo, sin color" },
  dark:    { name: "Oscuro",  swatch: "#171717", desc: "para leer de noche" },
};
/** «Automático»: claro de 7 a 18 h, oscuro desde las 18 h */
function modeByHour(d = new Date()) {
  const h = d.getHours();
  return h >= 7 && h < 18 ? "light" : "dark";
}
const curTheme = () => THEMES.find((t) => t.id === state.theme) || THEMES[0];
const themeColors = () => curTheme().colors;
const ZOOMS = [0.5, 0.67, 0.75, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4];
const CAPTURE_WIDTH = 2400; // px del ancho de página al capturar (nitidez)
const PRINT_DPI = 150;      // resolución de impresión

/* ============================================================
   Estado
   ============================================================ */
const state = {
  pdf: null,
  docKey: null,
  docName: "",
  sourceUrl: null,
  scale: 1,
  fit: true,
  pages: [],
  highlights: [],
  outline: null,
  outlineSource: null, // bookmarks | tagged | printed | generated
  history: [],     // posiciones para «Volver» tras saltar por índice o enlace
  curPage: 1,
  theme: "elegia",
  mode: "auto",     // light | vanilla | gris | dark | auto (según la hora del día)
  invertDark: true, // texto claro sobre las tintas oscuras
  color: "el-rojo",
  style: "marker",
  markerMode: false,
  printHl: true,
  sideTab: "hl",
  filter: null,
  activeId: null,
  fresh: null,      // marca recién hecha: se dibuja avanzando y se abre en la lista
  savedNote: null,  // marca cuya nota se acaba de guardar (sello «Nota guardada»)
  listRise: false,  // al abrir un documento, la lista entra subiendo
  undo: [],
  redo: [],
};

const $ = (id) => document.getElementById(id);
const els = {
  viewer: $("viewer"), pages: $("pages"), empty: $("empty"), docTitle: $("docTitle"), docTitleMini: $("docTitleMini"),
  topbar: $("topbar"), topbarMini: $("topbarMini"), modeQuick: $("modeQuick"),
  themeBtn: $("themeBtn"), themeDots: $("themeDots"), themeName: $("themeName"), themePop: $("themePop"), themeList: $("themeList"),
  markMap: $("markMap"), markTip: $("markTip"), legend: $("legend"), readPct: $("readPct"), exportLabel: $("exportLabel"),
  invertDark: $("invertDark"), invertSample: $("invertSample"), modeDesc: $("modeDesc"),
  modeBtn: $("modeBtn"), modePop: $("modePop"), modeSwatch: $("modeSwatch"), modeName: $("modeName"),
  selBar: $("selBar"), selSwatches: $("selSwatches"),
  hlMenu: $("hlMenu"), menuSwatches: $("menuSwatches"), hlList: $("hlList"),
  hlCount: $("hlCount"), filters: $("filters"), zoomLabel: $("zoomLabel"),
  toast: $("toast"), modal: $("shotModal"), shotImg: $("shotImg"),
  shotMeta: $("shotMeta"), shotFilters: $("shotFilters"), shotNote: $("shotNote"),
  autoOpen: $("autoOpen"), openNative: $("openNative"),
  findBar: $("findBar"), findInput: $("findInput"), findCount: $("findCount"),
  pageInput: $("pageInput"), pageTotal: $("pageTotal"),
  pagePrev: $("pagePrev"), pageNext: $("pageNext"), navBack: $("navBack"),
  panelHl: $("panelHl"), panelToc: $("panelToc"), toc: $("toc"), tocMeta: $("tocMeta"), tocExpand: $("tocExpand"),
  tocNote: $("tocNote"), tocNoteText: $("tocNoteText"), tocRegen: $("tocRegen"),
  printBtn: $("printBtn"), printBox: $("printBox"), printStyle: $("printPageStyle"), printHl: $("printHl"),
  wordmark: $("wordmark"), findIc: $("findIc"), sweep: $("sweep"), strip: $("strip"), sidebar: $("sidebar"),
  composer: $("composer"), cpDot: $("cpDot"), cpWire: $("cpWire"), cpCard: $("cpCard"), cpBar: $("cpBar"),
  cpTitle: $("cpTitle"), cpText: $("cpText"), cpLen: $("cpLen"),
};
const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
const reducedMotion = () => matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ============================================================
   Utilidades
   ============================================================ */
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
let toastTimer;
/** ms = 0 deja el aviso fijo hasta el siguiente */
function toast(msg, ms = 1800) {
  els.toast.textContent = msg;
  els.toast.hidden = false;
  clearTimeout(toastTimer);
  if (ms) toastTimer = setTimeout(() => (els.toast.hidden = true), ms);
}
const cleanText = (s) =>
  s.replace(/[­]/g, "")
   .replace(/(\p{L})-\s*\n\s*(?=\p{Ll})/gu, "$1")
   .replace(/\s+/g, " ")
   .trim();
const safeName = (s) => (s || "documento").replace(/\.pdf$/i, "").replace(/[^\p{L}\p{N}_-]+/gu, "_").slice(0, 60);

/** Rectángulo de dibujo (un poco más amplio que el glifo para que se vea "rotulado") */
function drawBox([x, y, w, h], pageAspect) {
  // h y w están normalizados; padX en función de la altura real
  const padY = h * 0.05;
  const padX = h * 0.12 * pageAspect; // compensa que x se normaliza por el ancho
  return [x - padX, y - padY, w + padX * 2, h + padY * 2];
}

/* ============================================================
   Preferencias y almacenamiento
   ============================================================ */
const store = {
  async get(key, def) {
    if (!hasChrome) { try { return JSON.parse(localStorage.getItem(key)) ?? def; } catch { return def; } }
    const r = await chrome.storage.local.get(key);
    return r[key] ?? def;
  },
  async set(key, val) {
    if (!hasChrome) { localStorage.setItem(key, JSON.stringify(val)); return; }
    await chrome.storage.local.set({ [key]: val });
  },
};

async function loadPrefs() {
  const p = await store.get("prefs", {});
  state.theme = THEMES.some((t) => t.id === p.theme) ? p.theme : "elegia";
  const th = curTheme();
  state.color = th.colors.some((c) => c.id === p.color) ? p.color : th.colors[th.def].id;
  state.style = p.style || "marker";
  state.markerMode = !!p.markerMode;
  state.printHl = p.printHl !== false;
  state.sideTab = p.sideTab === "toc" ? "toc" : "hl";
  state.mode = p.mode in MODES || p.mode === "auto" ? p.mode : "auto";
  state.invertDark = p.invertDark !== false;
  els.invertDark.checked = state.invertDark;
  applyMode();
  if (p.sideHidden) document.body.classList.add("side-hidden");
  setBarHidden(!!p.barHidden, false);
  els.printHl.checked = state.printHl;
  els.autoOpen.checked = await store.get("autoOpen", true);
}
function savePrefs() {
  store.set("prefs", {
    theme: state.theme, mode: state.mode, invertDark: state.invertDark, color: state.color, style: state.style, markerMode: state.markerMode,
    printHl: state.printHl, sideTab: state.sideTab,
    sideHidden: document.body.classList.contains("side-hidden"),
    barHidden: els.topbar.hidden,
  });
}
let saveTimer;
function saveHighlights() {
  if (!state.docKey) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    store.set(state.docKey, { name: state.docName, url: state.sourceUrl, updated: Date.now(), highlights: state.highlights });
  }, 250);
}

/* ============================================================
   UI: temas, modo y barra
   ============================================================ */
/** Variables de color para un elemento: tinta y su versión para modo oscuro */
function colorVars(el, def) {
  el.style.setProperty("--c", def.hex);
  el.style.setProperty("--cd", def.ui || def.hex);
}
/** Cuadradito de color (<i>) con contorno si hace falta */
function swatchI(def) {
  const i = document.createElement("i");
  colorVars(i, def);
  if (needsEdge(def)) i.className = "edge";
  return i;
}

/** Botones de color de las barras flotantes: cuadrado + nombre de la tinta */
function buildSwatches(container, { onPick }) {
  container.innerHTML = "";
  themeColors().forEach((c, i) => {
    const b = document.createElement("button");
    b.className = "swatch";
    colorVars(b, c);
    b.title = `${c.name} (${i + 1})`;
    b.dataset.color = c.id;
    b.innerHTML = `<span class="dot"></span>`;
    b.append(c.name);
    b.addEventListener("mousedown", (e) => e.preventDefault()); // no perder la selección
    b.addEventListener("click", () => onPick(c.id));
    container.appendChild(b);
  });
}
function syncPalette() {
  document.querySelectorAll("button[data-style]").forEach((b) => b.classList.toggle("on", b.dataset.style === state.style));
  document.querySelectorAll("button[data-mode]").forEach((b) => b.classList.toggle("on", b.dataset.mode === state.mode));
  applyThemeVars();
}
function applyThemeVars() {
  const th = curTheme(), root = document.documentElement.style;
  for (let i = 0; i < 4; i++) {
    if (th.colors[i]) root.setProperty(`--t${i + 1}`, th.colors[i].hex);
    else root.removeProperty(`--t${i + 1}`);
  }
  els.themeName.textContent = th.name;
  els.themeDots.replaceChildren(...th.colors.map(swatchI));
  els.themeList.querySelectorAll(".theme-row").forEach((r) => {
    const on = r.dataset.theme === state.theme;
    r.classList.toggle("on", on);
    r.setAttribute("aria-checked", on);
  });
  // ejemplo del ajuste de inversión, con la tinta más oscura del tema
  const darkest = th.colors.find(isDarkInk);
  els.invertSample.style.background = darkest?.hex || "#111111";
  els.invertSample.textContent = `texto marcado en ${darkest?.name || "Negro"}`;
  const dark = document.documentElement.dataset.mode === "dark";
  els.modeQuick.lastElementChild.textContent = dark ? "Modo claro" : "Modo oscuro";
  els.modeQuick.title = dark ? "Cambiar a modo claro" : "Cambiar a modo oscuro";
  els.modeQuick.firstElementChild.innerHTML = dark
    ? `<path d="M12 3v2 M12 19v2 M3 12h2 M19 12h2 M5.6 5.6l1.4 1.4 M17 17l1.4 1.4 M5.6 18.4L7 17 M17 7l1.4-1.4 M12 8a4 4 0 1 0 0 8a4 4 0 1 0 0-8"/>`
    : `<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>`;
}
/** Lista de temas del selector «Colores» */
function buildThemes() {
  els.themeList.innerHTML = "";
  THEMES.forEach((t) => {
    const b = document.createElement("button");
    b.className = "theme-row";
    b.dataset.theme = t.id;
    b.setAttribute("role", "menuitemradio");
    const strip = document.createElement("span");
    strip.className = "theme-strip";
    t.colors.forEach((c) => { const i = document.createElement("i"); colorVars(i, c); strip.appendChild(i); });
    const txt = document.createElement("span");
    txt.className = "theme-txt";
    const name = document.createElement("b");
    name.textContent = t.name;
    const inks = document.createElement("span");
    inks.textContent = t.colors.map((c) => c.name).join(" · ");
    txt.append(name, inks);
    const check = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    check.setAttribute("viewBox", "0 0 24 24");
    check.classList.add("ic", "theme-check");
    check.innerHTML = `<path d="M5 12l5 5l9-10"/>`;
    b.append(strip, txt, check);
    b.addEventListener("click", () => setTheme(t.id));
    els.themeList.appendChild(b);
  });
}
/** Aplica el modo elegido (en «auto», el que toca a esta hora). Devuelve true si cambió. */
function applyMode() {
  const eff = state.mode === "auto" ? modeByHour() : state.mode;
  const changed = document.documentElement.dataset.mode !== eff;
  document.documentElement.dataset.mode = eff;
  const m = MODES[eff];
  els.modeDesc.textContent = state.mode === "auto"
    ? `Automático: ahora ${m.name.toLowerCase()} (claro de día, oscuro desde las 18 h)`
    : `${m.name}: ${m.desc}`;
  // en la barra sólo el nombre del papel; «Automático» queda en la descripción y en el aviso
  els.modeName.textContent = m.name;
  els.modeBtn.title = state.mode === "auto" ? `Automático · ${m.name}` : "Papel de la interfaz y ajustes";
  els.modeSwatch.style.setProperty("--c", m.swatch);
  return changed;
}
/** ev: el clic que lo pidió (el papel nuevo se abre en círculo desde ahí) */
function setMode(mode, ev) {
  if (mode === state.mode) return;
  state.mode = mode;
  transitionMode(() => {
    applyMode();
    syncPalette();
    refreshMarks(); // contornos e inversión dependen del modo
  }, mode, ev);
  savePrefs();
}
/** Punto de origen del círculo: el clic, o el centro del botón si se pulsó con el teclado */
function clickPoint(ev) {
  if (ev && (ev.clientX || ev.clientY)) return [ev.clientX, ev.clientY];
  const r = ev?.currentTarget?.getBoundingClientRect?.();
  return r ? [r.left + r.width / 2, r.top + r.height / 2] : [innerWidth - 160, 42];
}
/** Cambia de papel con una transición: círculo desde el clic, luz por las reglas y destello del logotipo */
function transitionMode(apply, mode, ev) {
  const next = mode === "auto" ? modeByHour() : mode;
  if (next === document.documentElement.dataset.mode || !document.startViewTransition || reducedMotion()) { apply(); return; }
  const [x, y] = clickPoint(ev);
  const vt = document.startViewTransition(apply);
  vt.ready.then(() => {
    const r = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
    document.documentElement.animate(
      { clipPath: [`circle(0px at ${x}px ${y}px)`, `circle(${r}px at ${x}px ${y}px)`] },
      { duration: 1300, easing: "cubic-bezier(.65,0,.25,1)", pseudoElement: "::view-transition-new(root)" }
    );
  }).catch(() => {});
  sweepLines();
  glowWordmark(2400);
}
let sweepTimer;
/** Una luz corre por la regla de la franja y por el borde del panel */
function sweepLines() {
  const W = innerWidth, H = innerHeight, lines = [];
  const strip = els.strip.getBoundingClientRect();
  lines.push(`M0 ${strip.top}H${W}`);
  if (els.sidebar.offsetWidth) { const s = els.sidebar.getBoundingClientRect(); lines.push(`M${s.left} ${strip.bottom}V${H}`); }
  els.sweep.setAttribute("viewBox", `0 0 ${W} ${H}`);
  els.sweep.innerHTML = lines.map((d, i) => `<path d="${d}" pathLength="100" style="--d:${(i * 0.13).toFixed(2)}s"/>`).join("");
  clearTimeout(sweepTimer);
  sweepTimer = setTimeout(() => els.sweep.replaceChildren(), 2200);
}
let glowTimer;
function glowWordmark(ms) {
  els.wordmark.classList.add("lit");
  clearTimeout(glowTimer);
  glowTimer = setTimeout(() => els.wordmark.classList.remove("lit"), ms);
}
/** Vuelve a pintar las marcas (página y lista) cuando cambia algo que afecta cómo se ven */
function refreshMarks() {
  state.pages.forEach(drawPageHighlights);
  renderList();
}
function setTheme(id) {
  if (id === state.theme) return;
  const slot = Math.max(0, themeColors().findIndex((c) => c.id === state.color));
  state.theme = id;
  const cols = curTheme().colors;
  state.color = cols[Math.min(slot, cols.length - 1)].id;
  rebuildSwatches();
  syncPalette();
  savePrefs();
}
/** Barra principal oculta: queda una línea con lo mínimo */
function setBarHidden(hidden, save = true) {
  els.topbar.hidden = hidden;
  els.topbarMini.hidden = !hidden;
  if (save) { savePrefs(); if (state.fit) setTimeout(onResize, 0); }
}
/* Ventanas de la barra: «Tema» (papel de la interfaz y ajustes) y «Colores» (tintas de los marcatextos) */
const POPS = () => [[els.modeBtn, els.modePop], [els.themeBtn, els.themePop]];
function openPop(btn, pop) {
  closeThemePop();
  const r = btn.getBoundingClientRect();
  pop.hidden = false;
  pop.style.top = `${r.bottom + 8}px`;
  pop.style.left = `${clamp(r.right - pop.offsetWidth, 8, innerWidth - pop.offsetWidth - 8)}px`;
  btn.setAttribute("aria-expanded", "true");
}
const togglePop = (btn, pop) => (pop.hidden ? openPop(btn, pop) : closeThemePop());
/** Cierra la ventana que esté abierta (cualquiera de las dos) */
function closeThemePop() {
  for (const [btn, pop] of POPS()) {
    if (pop.hidden) continue;
    pop.hidden = true;
    btn.setAttribute("aria-expanded", "false");
  }
}
const anyPopOpen = () => POPS().some(([, pop]) => !pop.hidden);
function setColor(id) { state.color = id; syncPalette(); savePrefs(); }
/** Marcado automático (tecla M): marca al soltar el mouse */
function toggleMarkerMode() {
  state.markerMode = !state.markerMode;
  savePrefs();
  toast(state.markerMode ? "Marcado automático: marca al soltar · M para desactivar" : "Marcado automático desactivado");
}

/* ============================================================
   Carga del documento
   ============================================================ */
async function openFromUrl(url) {
  state.sourceUrl = url;
  els.openNative.hidden = !/^(https?|file):/i.test(url);
  showMessage("Cargando PDF…");
  // PDF.js lo pide por partes (rangos HTTP): la primera página aparece sin esperar la descarga completa
  let name = "";
  try { name = decodeURIComponent(new URL(url, location.href).pathname.split("/").pop() || ""); } catch {}
  if (await openDocument({ url }, name || "documento.pdf", { quiet: true })) return;
  // si no se pudo (servidor raro, archivo local sin permiso, no es un PDF…), se descarga entero y se explica el error
  try {
    const res = await fetch(url, { credentials: "include" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = await res.arrayBuffer();
    const head = new TextDecoder().decode(new Uint8Array(buf.slice(0, 1024)));
    if (!head.includes("%PDF")) throw new Error("NOT_PDF");
    const cd = res.headers.get("content-disposition") || "";
    const m = cd.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i);
    if (m) name = decodeURIComponent(m[1]);
    await openDocument(new Uint8Array(buf), name || "documento.pdf");
  } catch (err) {
    console.error(err);
    if (String(err.message) === "NOT_PDF") {
      showMessage("Esta página no es un PDF.", "Abre un PDF o arrástralo aquí.");
    } else if (url.startsWith("file:")) {
      showMessage(
        "No tengo permiso para leer archivos locales.",
        `Ve a chrome://extensions → ${APP} → Detalles y activa «Permitir el acceso a las URL de archivo». O arrastra el PDF aquí.`
      );
    } else {
      showMessage("No se pudo cargar el PDF.", `${err.message}. Puedes descargarlo y arrastrarlo aquí.`);
    }
  }
}

async function openFile(file) {
  if (!file) return;
  state.sourceUrl = null;
  els.openNative.hidden = true;
  showMessage("Cargando PDF…");
  const buf = new Uint8Array(await file.arrayBuffer());
  await openDocument(buf, file.name);
}

function showMessage(title, sub = "") {
  els.pages.innerHTML = "";
  els.empty.hidden = false;
  els.empty.querySelector("h1").textContent = title;
  els.empty.querySelector("p").textContent = sub;
}

/** src: los bytes del PDF (Uint8Array) o { url } para que PDF.js lo pida por partes.
    Devuelve true si se abrió; con quiet no muestra el error (quien llama tiene un plan B). */
async function openDocument(src, name, { quiet = false } = {}) {
  if (state.pdf) { state.pdf.destroy(); state.pdf = null; }
  hiResCache.clear();
  destCache.clear();
  resetFind();
  let pdf;
  try {
    pdf = await pdfjsLib.getDocument({
      ...(src instanceof Uint8Array ? { data: src } : { url: src.url, withCredentials: true }),
      cMapUrl: "./lib/cmaps/",
      cMapPacked: true,
      standardFontDataUrl: "./lib/standard_fonts/",
      isEvalSupported: false,
    }).promise;
  } catch (e) {
    if (!quiet) showMessage("No se pudo abrir el PDF.", e?.message || "");
    return false;
  }
  if (!(src instanceof Uint8Array)) {
    // el nombre que manda el servidor (Content-Disposition), si lo hay
    const md = await pdf.getMetadata().catch(() => null);
    if (md?.contentDispositionFilename) name = md.contentDispositionFilename;
  }
  state.pdf = pdf;
  state.docName = name;
  state.docKey = "doc:" + (pdf.fingerprints?.[0] || name);
  state.highlights = (await store.get(state.docKey, {}))?.highlights || [];
  closeComposer();
  state.undo = []; state.redo = []; state.activeId = null; state.filter = null;
  state.fresh = null; state.savedNote = null; state.listRise = true;
  state.history = []; state.curPage = 1; state.outline = null; state.outlineSource = null;
  updateBackBtn();
  els.docTitle.textContent = name;
  els.docTitleMini.textContent = name;
  document.title = `${name} · ${APP}`;
  els.empty.hidden = true;
  els.pageTotal.textContent = `de ${pdf.numPages}`;
  els.pageInput.style.width = `${String(pdf.numPages).length + 1}ch`;
  els.pageInput.value = 1;
  await buildPages();
  renderList();
  updatePageIndicator();
  loadOutline(pdf);
  measurePages(pdf);
  if (els.findInput.value.trim()) runSearch(els.findInput.value);
  return true;
}

/* ============================================================
   Páginas
   ============================================================ */
let observer;
async function buildPages() {
  const pdf = state.pdf;
  els.pages.innerHTML = "";
  state.pages = [];
  observer?.disconnect();
  observer = new IntersectionObserver(onIntersect, { root: els.viewer, rootMargin: "800px 0px" });

  const first = await pdf.getPage(1);
  const baseVp = first.getViewport({ scale: 1 });
  if (state.fit) state.scale = fitScale(baseVp.width);

  // Todas las páginas empiezan con el tamaño de la primera; las que midan distinto se
  // corrigen al dibujarlas o en segundo plano (measurePages): abrir no espera a medirlas todas
  const dims = Array.from({ length: pdf.numPages }, () => ({ w: baseVp.width, h: baseVp.height }));

  const frag = document.createDocumentFragment();
  dims.forEach((d, i) => {
    const div = document.createElement("div");
    div.className = "page loading" + (i < 4 ? " enter" : ""); // las primeras entran subiendo
    div.dataset.page = i + 1;
    const hl = document.createElement("div");
    hl.className = "hl-layer";
    const fl = document.createElement("div");
    fl.className = "find-layer";
    const num = document.createElement("div");
    num.className = "page-num";
    num.textContent = `${i + 1} / ${pdf.numPages}`;
    div.append(hl, fl, num);
    const pv = { num: i + 1, w: d.w, h: d.h, div, hlLayer: hl, findLayer: fl, canvas: null, textLayer: null, textLayerObj: null, linkLayer: null, renderedScale: 0, task: null, visible: false };
    state.pages.push(pv);
    sizePage(pv);
    frag.appendChild(div);
    observer.observe(div);
  });
  els.pages.appendChild(frag);
  state.pages.forEach(drawPageHighlights);
  updateZoomLabel();
  setTimeout(() => state.pages.slice(0, 4).forEach((pv) => pv.div.classList.remove("enter")), 900);
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let rendering = 0; // páginas dibujándose ahora mismo

/** Espera a que las páginas visibles estén pintadas: el trabajo pesado (índice, medidas) va después */
async function afterFirstPaint(pdf, extra = 400) {
  const t0 = Date.now();
  while (pdf === state.pdf && Date.now() - t0 < 10000 &&
         (rendering > 0 || state.pages.some((p) => p.visible && p.renderedScale !== state.scale))) await sleep(80);
  await sleep(extra);
}

/** Si una página no mide lo que se supuso, se corrige sin mover lo que estás leyendo */
function resizePage(pv, w, h) {
  if (Math.abs(w - pv.w) < 0.5 && Math.abs(h - pv.h) < 0.5) return false;
  const a = anchor();
  pv.w = w; pv.h = h;
  sizePage(pv);
  drawPageHighlights(pv);
  if (a && a.pv.num > pv.num) els.viewer.scrollTop = a.pv.div.offsetTop + a.frac * a.pv.div.offsetHeight;
  return true;
}

/** Medidas reales de todas las páginas, en segundo plano y por tandas (para PDFs con páginas de tamaños distintos) */
async function measurePages(pdf) {
  await afterFirstPaint(pdf, 800);
  for (let i = 2; i <= pdf.numPages; i += 40) {
    while (rendering > 0 && pdf === state.pdf) await sleep(60);
    if (pdf !== state.pdf) return;
    const nums = [];
    for (let n = i; n < i + 40 && n <= pdf.numPages; n++) nums.push(n);
    let pages;
    try { pages = await Promise.all(nums.map((n) => pdf.getPage(n))); } catch { return; }
    if (pdf !== state.pdf) return;
    pages.forEach((p, k) => {
      const vp = p.getViewport({ scale: 1 }), pv = state.pages[nums[k] - 1];
      if (resizePage(pv, vp.width, vp.height) && pv.renderedScale) { pv.renderedScale = 0; if (pv.visible) renderPage(pv); }
    });
    await sleep(0);
  }
}

function fitScale(pageW) {
  const avail = els.viewer.clientWidth - 48;
  return clamp(avail / pageW, 0.4, 2.2);
}
function sizePage(pv) {
  pv.div.style.width = `${Math.floor(pv.w * state.scale)}px`;
  pv.div.style.height = `${Math.floor(pv.h * state.scale)}px`;
  pv.div.style.setProperty("--scale-factor", state.scale);
}

function onIntersect(entries) {
  for (const e of entries) {
    const pv = state.pages[+e.target.dataset.page - 1];
    if (!pv) continue;
    pv.visible = e.isIntersecting;
    if (pv.visible && pv.renderedScale !== state.scale) renderPage(pv);
  }
}

async function renderPage(pv) {
  const scale = state.scale;
  const pdf = state.pdf;
  if (pv.task) { try { pv.task.cancel(); } catch {} }
  rendering++;
  let page, vp, canvas;
  try {
    page = await pdf.getPage(pv.num);
    const base = page.getViewport({ scale: 1 });
    resizePage(pv, base.width, base.height);
    vp = page.getViewport({ scale });
    // más de 2× no se nota a simple vista y cuesta el doble de memoria y de tiempo
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas = document.createElement("canvas");
    canvas.width = Math.floor(vp.width * dpr);
    canvas.height = Math.floor(vp.height * dpr);
    const task = page.render({
      canvasContext: canvas.getContext("2d", { alpha: false }),
      viewport: vp,
      transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : null,
    });
    pv.task = task;
    try { await task.promise; } catch (e) { if (e?.name === "RenderingCancelledException") return; throw e; }
    if (pv.task === task) pv.task = null;
  } finally {
    rendering--;
  }
  if (scale !== state.scale || pdf !== state.pdf) return;

  // texto seleccionable
  const tl = document.createElement("div");
  tl.className = "textLayer";
  const textLayer = new pdfjsLib.TextLayer({
    textContentSource: page.streamTextContent({ includeMarkedContent: true, disableNormalization: true }),
    container: tl,
    viewport: vp,
  });
  await textLayer.render();
  const eoc = document.createElement("div");
  eoc.className = "endOfContent";
  tl.appendChild(eoc);

  pv.canvas?.remove();
  pv.textLayer?.remove();
  pv.canvas = canvas;
  pv.textLayer = tl;
  pv.textLayerObj = textLayer;
  pv.div.insertBefore(canvas, pv.hlLayer);
  if (pv.linkLayer) pv.div.insertBefore(tl, pv.linkLayer);
  else pv.div.appendChild(tl);
  pv.div.classList.remove("loading");
  pv.renderedScale = scale;
  drawFindMarks(pv);

  buildLinks(pv, page); // los enlaces no dependen del zoom: se crean una sola vez
}

/* ============================================================
   Enlaces del PDF e índice (marcadores)
   ============================================================ */
const destCache = new Map();

/** Convierte un destino de PDF (nombre o arreglo) en { page, frac } — frac = posición vertical 0–1 */
function resolveDest(dest) {
  const key = typeof dest === "string" ? "n:" + dest : "a:" + JSON.stringify(dest);
  if (destCache.has(key)) return destCache.get(key);
  const pdf = state.pdf;
  const p = (async () => {
    try {
      const explicit = typeof dest === "string" ? await pdf.getDestination(dest) : dest;
      if (!Array.isArray(explicit) || !explicit.length) return null;
      const ref = explicit[0];
      let idx;
      if (ref && typeof ref === "object") idx = await pdf.getPageIndex(ref);
      else if (Number.isInteger(ref)) idx = ref;
      else return null;
      const num = idx + 1;
      if (num < 1 || num > pdf.numPages) return null;
      // posición vertical dentro de la página (si el destino la trae)
      const kind = explicit[1]?.name;
      let top = null;
      if (kind === "XYZ") top = explicit[3];
      else if (kind === "FitH" || kind === "FitBH") top = explicit[2];
      else if (kind === "FitR") top = explicit[5];
      let frac = 0;
      if (typeof top === "number") {
        const page = await pdf.getPage(num);
        const vp = page.getViewport({ scale: 1 });
        const [, y] = vp.convertToViewportPoint(0, top);
        frac = clamp(y / vp.height, 0, 1);
      }
      return { page: num, frac };
    } catch (e) {
      console.warn("Destino no válido", dest, e);
      return null;
    }
  })();
  destCache.set(key, p);
  return p;
}

function runNamedAction(action) {
  const n = state.pages.length;
  if (action === "NextPage") goToPage(state.curPage + 1);
  else if (action === "PrevPage") goToPage(state.curPage - 1);
  else if (action === "FirstPage") navigateTo({ page: 1, frac: 0 });
  else if (action === "LastPage") navigateTo({ page: n, frac: 0 });
  else if (action === "GoBack") goBack();
}

async function buildLinks(pv, page) {
  if (pv.linkLayer) return;
  const layer = document.createElement("div");
  layer.className = "link-layer";
  pv.linkLayer = layer;
  pv.div.appendChild(layer);
  let annots = [];
  try { annots = await page.getAnnotations({ intent: "display" }); } catch { return; }
  const vp = page.getViewport({ scale: 1 });
  for (const a of annots) {
    if (a.subtype !== "Link" || !a.rect) continue;
    const dest = a.dest ?? null, url = a.url || null, action = a.action || null;
    if (!dest && !url && !action) continue;
    const [x1, y1, x2, y2] = vp.convertToViewportRectangle(a.rect);
    const x = Math.min(x1, x2) / vp.width, y = Math.min(y1, y2) / vp.height;
    const w = Math.abs(x2 - x1) / vp.width, h = Math.abs(y2 - y1) / vp.height;
    if (w <= 0 || h <= 0) continue;
    const el = document.createElement("a");
    el.className = "pdf-link";
    el.draggable = false;
    el.style.left = `${x * 100}%`; el.style.top = `${y * 100}%`;
    el.style.width = `${w * 100}%`; el.style.height = `${h * 100}%`;
    if (url) {
      el.href = url; el.target = "_blank"; el.rel = "noopener noreferrer"; el.title = url;
    } else {
      el.href = "#";
      el.title = dest ? "Ir al destino" : "Acción del documento";
      if (dest) resolveDest(dest).then((d) => { if (d) el.title = `Ir a la página ${d.page}`; });
      el.addEventListener("click", async (e) => {
        e.preventDefault();
        if (dest) {
          const d = await resolveDest(dest);
          if (d) navigateTo(d);
          else toast("Este enlace no apunta a ninguna página");
        } else runNamedAction(action);
      });
    }
    layer.appendChild(el);
  }
}

/* Si el PDF no trae marcadores, se genera un índice (toc-gen.js) y se guarda
   por documento, así sólo se calcula una vez. */
const tocKey = () => state.docKey.replace(/^doc:/, "toc:");
let tocRun = 0;

async function loadOutline(pdf, { regenerate = false } = {}) {
  const run = ++tocRun;
  const stale = () => pdf !== state.pdf || run !== tocRun;
  renderToc("loading");
  let outline = null;
  if (!regenerate) {
    try { outline = await pdf.getOutline(); } catch (e) { console.warn(e); }
    if (stale()) return;
    if (outline?.length) {
      state.outline = outline; state.outlineSource = "bookmarks";
      return renderToc();
    }
  }

  const key = tocKey();
  let saved = regenerate ? null : await store.get(key, null);
  if (stale()) return;
  if (saved?.v !== TOC_VERSION) {
    renderToc("generating");
    // primero que se vea el documento; el índice se arma después, cediendo el paso a cada página que se dibuja
    await afterFirstPaint(pdf);
    if (stale()) return;
    let res = null;
    try {
      res = await generateToc(pdf, {
        isStale: stale,
        isBusy: () => rendering > 0,
        onProgress: (n, total) => { if (!stale()) els.tocMeta.textContent = `Generando índice… ${n} de ${total}`; },
      });
    } catch (e) { console.warn("No se pudo generar el índice", e); }
    if (stale()) return;
    saved = { v: TOC_VERSION, source: res?.source || null, items: res?.items || [], created: Date.now() };
    store.set(key, saved);
  }
  state.outline = saved.items?.length ? saved.items : null;
  state.outlineSource = state.outline ? saved.source : null;
  renderToc();
}

const TOC_SOURCE = {
  tagged: "Índice generado a partir de las etiquetas del PDF.",
  printed: "Índice generado a partir de la tabla de contenido impresa.",
  generated: "Índice generado a partir de los títulos (tamaño y peso de la letra). Puede tener errores.",
};

const CARET = `<svg class="ic sm" viewBox="0 0 24 24"><path d="M6 9l6 6l6-6"/></svg>`;
/* Entradas del índice ya resueltas, en orden: { page, el (fila o cabecera), sec, depth } */
let tocEntries = [];
let tocSecs = [];   // secciones de primer nivel: { page, sec, marks }

/** status: "loading" (leyendo marcadores) · "generating" (armando un índice) · sin valor = listo */
function renderToc(status = null) {
  const root = els.toc;
  root.innerHTML = "";
  tocEntries = []; tocSecs = [];
  els.tocExpand.hidden = true;
  const generated = !!state.pdf && !!state.outline && !status && state.outlineSource !== "bookmarks";
  els.tocNote.hidden = !generated;
  els.tocNoteText.textContent = TOC_SOURCE[state.outlineSource] || "";
  if (!state.pdf) {
    els.tocMeta.textContent = "";
    root.innerHTML = `<li class="toc-empty">Abre un PDF para ver su índice.</li>`;
    return;
  }
  if (status === "loading") {
    els.tocMeta.textContent = "Leyendo índice…";
    return;
  }
  if (status === "generating") {
    els.tocMeta.textContent = "Generando índice…";
    root.innerHTML = `<li class="toc-empty">Este PDF no trae marcadores, así que estoy armando un índice a partir de su texto.</li>`;
    return;
  }
  if (!state.outline) {
    els.tocMeta.textContent = "Sin índice";
    root.innerHTML = `<li class="toc-empty">Este PDF no trae marcadores y no encontré títulos para armar un índice.<br><br>
      Si tiene una tabla de contenido impresa, haz clic en sus entradas: los enlaces internos llevan a su página.
      También puedes escribir el número de página en la franja de arriba, o pulsar <b>G</b>.</li>`;
    return;
  }

  const clean = (t) => (t || "").replace(/\s+/g, " ").trim() || "(sin título)";
  /** Al hacer clic: saltar al destino (o abrir la URL / ejecutar la acción) */
  const onActivate = (item, target) => async () => {
    if (target) {
      const d = await target;
      if (!d) return toast("Esta entrada del índice no apunta a ninguna página");
      navigateTo(d);
    } else if (item.url) {
      window.open(item.url, "_blank", "noopener");
    } else if (item.action) {
      runNamedAction(item.action);
    }
  };
  const pending = [];
  const register = (item, el, sec, depth, pg) => {
    const target = item.dest ? resolveDest(item.dest) : null;
    const entry = { page: null, el, sec, depth };
    tocEntries.push(entry);
    if (target) pending.push(target.then((d) => { if (d) { entry.page = d.page; pg.textContent = `p. ${d.page}`; } }));
    return target;
  };

  /** Subsecciones: filas compactas, sin plegar */
  const buildKids = (items, parent, sec, depth) => {
    for (const item of items) {
      const li = document.createElement("li");
      const row = document.createElement("button");
      row.className = "toc-row";
      const title = document.createElement("span");
      title.className = "toc-title";
      title.textContent = clean(item.title);
      const pg = document.createElement("span");
      pg.className = "toc-page";
      row.append(title, pg);
      li.appendChild(row);
      row.addEventListener("click", onActivate(item, register(item, row, sec, depth, pg)));
      if (item.items?.length) {
        const ul = document.createElement("ul");
        buildKids(item.items, ul, sec, depth + 1);
        li.appendChild(ul);
      }
      parent.appendChild(li);
    }
  };

  let nested = false;
  state.outline.forEach((item, i) => {
    const sec = document.createElement("li");
    sec.className = "toc-sec";
    const head = document.createElement("div");
    head.className = "toc-head";
    const num = document.createElement("span");
    num.className = "toc-num";
    num.textContent = String(i + 1).padStart(2, "0");
    const link = document.createElement("button");
    link.className = "toc-link";
    link.textContent = clean(item.title);
    if (item.bold) link.style.fontWeight = "500";
    if (item.italic) link.style.fontStyle = "italic";
    const pg = document.createElement("span");
    pg.className = "toc-page";
    const caret = document.createElement("button");
    caret.className = "toc-caret" + (item.items?.length ? "" : " blank");
    caret.innerHTML = CARET;
    caret.setAttribute("aria-label", "Mostrar u ocultar subsecciones");
    head.append(num, link, pg, caret);
    const marks = document.createElement("div");
    marks.className = "toc-marks";
    sec.append(head, marks);
    link.addEventListener("click", onActivate(item, register(item, head, sec, 0, pg)));
    tocSecs.push({ sec, marks, entry: tocEntries.at(-1) });

    if (item.items?.length) {
      nested = true;
      const kids = document.createElement("ul");
      kids.className = "toc-kids";
      kids.hidden = true;
      buildKids(item.items, kids, sec, 1);
      sec.appendChild(kids);
      caret.setAttribute("aria-expanded", "false");
      caret.addEventListener("click", () => {
        kids.hidden = !kids.hidden;
        caret.classList.toggle("open", !kids.hidden);
        caret.setAttribute("aria-expanded", !kids.hidden);
      });
    }
    root.appendChild(sec);
  });

  const n = state.outline.length;
  els.tocMeta.textContent = `${n} parte${n === 1 ? "" : "s"} · los cuadros muestran tus marcas por sección`;
  els.tocExpand.hidden = !nested;
  els.tocExpand.textContent = "Expandir todo";
  const outline = state.outline;
  Promise.all(pending).then(() => {
    if (outline !== state.outline) return;
    updateTocMarks();
    updateTocHere(true);
  });
}

/** Debajo de cada sección: un cuadrado por marca (con su color) y cuántas hay */
function updateTocMarks() {
  if (!tocSecs.length) return;
  const n = state.pages.length || Infinity;
  const starts = tocSecs.map((s) => s.entry.page);
  tocSecs.forEach((s, i) => {
    const from = starts[i];
    const to = starts.slice(i + 1).find((p) => p != null && p > (from ?? 0)) ?? n + 1;
    const list = from == null ? [] : sortedHighlights().filter((h) => h.parts[0].page >= from && h.parts[0].page < to);
    s.sec.classList.toggle("nomarks", !list.length);
    if (!list.length) { s.marks.textContent = "Sin marcas"; return; }
    const row = document.createElement("span");
    row.className = "sq-row";
    list.slice(0, 12).forEach((h) => row.appendChild(swatchI(colorDef(h.color))));
    s.marks.replaceChildren(row, `${list.length} marca${list.length === 1 ? "" : "s"}`);
  });
}

/** Marca la entrada donde estás leyendo y abre su sección */
let tocHereEl = null;
function updateTocHere(reveal = false) {
  if (!tocEntries.length) return;
  let here = null;
  for (const e of tocEntries) if (e.page != null && e.page <= state.curPage && (!here || e.page >= here.page)) here = e;
  if (here?.el === tocHereEl) return;
  tocHereEl = here?.el || null;
  els.toc.querySelectorAll(".here, .here-in").forEach((x) => x.classList.remove("here", "here-in"));
  if (!here) return;
  here.sec.classList.add("here-in");
  if (here.depth > 0) {
    here.el.classList.add("here");
    const kids = here.sec.querySelector(".toc-kids");
    if (kids?.hidden) { kids.hidden = false; here.sec.querySelector(".toc-caret")?.classList.add("open"); }
  }
  if (reveal && !els.panelToc.hidden) here.sec.scrollIntoView({ block: "nearest" });
}

function setSideTab(tab, save = true) {
  state.sideTab = tab;
  els.panelHl.hidden = tab !== "hl";
  els.panelToc.hidden = tab !== "toc";
  if (tab === "toc") updateTocHere(true);
  document.querySelectorAll(".side-tabs button").forEach((b) => {
    const on = b.dataset.tab === tab;
    b.classList.toggle("active", on);
    b.setAttribute("aria-selected", on);
  });
  if (save) savePrefs();
}

/* ============================================================
   Navegación entre páginas
   ============================================================ */
function goToPage(n, frac = 0) {
  if (!state.pages.length) return;
  n = clamp(Math.round(n), 1, state.pages.length);
  const pv = state.pages[n - 1];
  const off = frac > 0.02 ? 36 : 12;
  els.viewer.scrollTo({ top: Math.max(0, pv.div.offsetTop + frac * pv.div.offsetHeight - off) });
  state.curPage = n;
  hideBars();
  updatePageIndicator();
}

/** Salto «lejano» (índice, enlace, número de página): se puede volver con Alt+← */
function navigateTo({ page, frac = 0 }) {
  if (!state.pages.length || !page) return;
  const a = anchor();
  if (a) {
    state.history.push({ page: a.pv.num, frac: a.frac });
    if (state.history.length > 50) state.history.shift();
    updateBackBtn();
  }
  goToPage(page, frac);
  markDestination(page, frac);
}

function goBack() {
  const h = state.history.pop();
  updateBackBtn();
  if (!h) return;
  const pv = state.pages[h.page - 1];
  if (!pv) return;
  els.viewer.scrollTo({ top: pv.div.offsetTop + h.frac * pv.div.offsetHeight });
  hideBars();
}

function updateBackBtn() {
  const has = state.history.length > 0;
  els.navBack.hidden = !has;
}

/** Una línea breve de color marca dónde cae el destino dentro de la página */
function markDestination(page, frac) {
  if (frac <= 0.02) return;
  const pv = state.pages[page - 1];
  if (!pv) return;
  const m = document.createElement("div");
  m.className = "dest-mark";
  m.style.top = `${frac * 100}%`;
  pv.div.appendChild(m);
  setTimeout(() => m.remove(), 1500);
}

/* ============================================================
   Buscar en el documento
   ============================================================ */
/* El texto de cada página sale de getTextContent con las mismas opciones que el
   text layer, así el elemento i coincide con textLayer.textDivs[i] y las coincidencias
   se pintan con los rectángulos reales de los glifos. Sin distinguir mayúsculas ni acentos. */
const find = {
  run: 0,
  matches: [],        // { page, start, end } — posiciones en el texto de la página
  byPage: new Map(),  // página → índices en matches
  cur: -1,
  done: false,
  texts: new Map(),   // página → { items: [{ start, len, frac }], folded, map }
};

/** minúsculas, sin acentos y con los espacios colapsados; map[i] = posición en el original */
function foldText(s) {
  let folded = "", space = false;
  const map = [];
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (/\s/.test(ch)) {
      if (!space && folded) { folded += " "; map.push(i); }
      space = true;
      continue;
    }
    if (ch === "­") continue; // guion suave
    space = false;
    for (const c of ch.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase()) { folded += c; map.push(i); }
  }
  return { folded, map };
}

async function pageText(num) {
  if (find.texts.has(num)) return find.texts.get(num);
  const pdf = state.pdf;
  const page = await pdf.getPage(num);
  const vp = page.getViewport({ scale: 1 });
  const tc = await page.getTextContent({ includeMarkedContent: true, disableNormalization: true });
  const items = [];
  let text = "";
  for (const it of tc.items) {
    if (it.str === undefined) continue; // contenido marcado: el text layer tampoco lo cuenta
    const [, , , d, x, y] = it.transform;
    const top = vp.convertToViewportPoint(x, y + Math.abs(d))[1] / vp.height;
    items.push({ start: text.length, len: it.str.length, frac: clamp(top, 0, 1) });
    text += it.str + (it.hasEOL ? "\n" : "");
  }
  const t = { items, ...foldText(text) };
  if (pdf === state.pdf) find.texts.set(num, t); // no guardar el texto de un documento que ya se cerró
  return t;
}

function resetFind() {
  find.run++;
  find.matches = []; find.byPage = new Map(); find.cur = -1; find.done = false;
  find.texts.clear();
  state.pages.forEach((pv) => pv.findLayer?.replaceChildren());
  updateFindCount();
}

async function runSearch(query) {
  const run = ++find.run;
  const pdf = state.pdf;
  const old = [...find.byPage.keys()];
  find.matches = []; find.byPage = new Map(); find.cur = -1; find.done = false;
  old.forEach((n) => state.pages[n - 1] && drawFindMarks(state.pages[n - 1]));
  const needle = foldText(query).folded.trim();
  if (!needle || !pdf) { find.done = true; updateFindCount(); return; }
  if (needle.length >= 2) scanPages();
  updateFindCount();

  const from = state.curPage; // el primer resultado es el primero desde la página actual
  for (let n = 1; n <= pdf.numPages; n++) {
    let t;
    try { t = await pageText(n); } catch { continue; }
    if (run !== find.run || pdf !== state.pdf) return;
    const found = [];
    for (let i = t.folded.indexOf(needle); i >= 0; i = t.folded.indexOf(needle, i + needle.length)) {
      found.push(find.matches.length);
      find.matches.push({ page: n, start: t.map[i], end: t.map[i + needle.length - 1] + 1 });
    }
    if (found.length) {
      find.byPage.set(n, found);
      if (find.cur < 0 && n >= from) showMatch(found[0]);
      else drawFindMarks(state.pages[n - 1]);
    }
    if (n % 25 === 0) { updateFindCount(); await new Promise((r) => setTimeout(r, 0)); }
  }
  find.done = true;
  if (find.cur < 0 && find.matches.length) showMatch(0);
  updateFindCount();
}

function updateFindCount() {
  const n = find.matches.length;
  let txt = "";
  if (els.findInput.value.trim()) {
    const pos = `${pad2(Math.max(find.cur, 0) + 1)} / ${pad2(n)}`;
    if (!find.done) txt = n ? `${pos}…` : "Buscando…";
    else txt = n ? pos : "00 / 00";
  }
  // cada cambio del contador entra cayendo
  if (txt !== els.findCount.dataset.txt) {
    els.findCount.dataset.txt = txt;
    els.findCount.title = find.done && !n && txt ? "Sin resultados" : "";
    els.findCount.replaceChildren();
    if (txt) { const s = document.createElement("span"); s.className = "tick"; s.textContent = txt; els.findCount.appendChild(s); }
  }
  els.findBar.classList.toggle("has-q", !!els.findInput.value.trim());
  els.findBar.classList.toggle("none", find.done && !n && !!txt);
}

/** Va a la coincidencia i (centrada en pantalla) y la marca como actual */
function showMatch(i) {
  const m = find.matches[i];
  if (!m) return;
  const prev = find.matches[find.cur];
  find.cur = i;
  const pv = state.pages[m.page - 1];
  const t = find.texts.get(m.page);
  const it = t.items.find((x) => x.start + x.len > m.start) || t.items[0];
  const frac = it?.frac ?? 0;
  els.viewer.scrollTo({ top: Math.max(0, pv.div.offsetTop + frac * pv.div.offsetHeight - els.viewer.clientHeight * 0.35) });
  hideBars();
  updatePageIndicator();
  if (prev && prev.page !== m.page) drawFindMarks(state.pages[prev.page - 1]);
  drawFindMarks(pv);
  updateFindCount();
}

function stepMatch(dir) {
  const n = find.matches.length;
  if (!n) return;
  showMatch(((find.cur < 0 ? (dir > 0 ? -1 : 0) : find.cur) + dir + n) % n);
}

/** Pinta las coincidencias de una página (sólo si ya tiene text layer) */
function drawFindMarks(pv) {
  if (!pv?.findLayer) return;
  pv.findLayer.replaceChildren();
  const list = find.byPage.get(pv.num);
  const t = find.texts.get(pv.num);
  const divs = pv.textLayerObj?.textDivs;
  if (!list || !t || !divs || !pv.textLayer) return;
  const box = pv.div.getBoundingClientRect();
  const frag = document.createDocumentFragment();
  for (const idx of list) {
    const m = find.matches[idx];
    for (let k = 0; k < t.items.length; k++) {
      const it = t.items[k];
      if (it.start >= m.end) break;
      if (it.start + it.len <= m.start) continue;
      const node = divs[k]?.firstChild;
      if (!node || node.nodeType !== 3) continue;
      const r = document.createRange();
      r.setStart(node, clamp(m.start - it.start, 0, node.length));
      r.setEnd(node, clamp(m.end - it.start, 0, node.length));
      for (const cr of r.getClientRects()) {
        if (cr.width < 0.5 || cr.height < 0.5) continue;
        const d = document.createElement("div");
        d.className = "find-hit" + (idx === find.cur ? " current" : "");
        d.style.left = `${(cr.left - box.left) / box.width * 100}%`;
        d.style.top = `${(cr.top - box.top) / box.height * 100}%`;
        d.style.width = `${cr.width / box.width * 100}%`;
        d.style.height = `${cr.height / box.height * 100}%`;
        frag.appendChild(d);
      }
    }
  }
  pv.findLayer.appendChild(frag);
}

/** Al usar el buscador se estira hasta el borde de «Colores», tapando Tema y Colores */
function expandFind() {
  const box = els.findBar, colors = els.themeBtn.closest(".field"), tema = els.modeBtn.closest(".field");
  if (box.classList.contains("open")) return;
  const b = box.parentElement.getBoundingClientRect(), c = colors.getBoundingClientRect(); // el campo no cambia de tamaño
  // sólo si están en la misma fila (en ventanas angostas el buscador baja a su propia línea)
  if (els.topbar.hidden || Math.abs(c.bottom - b.bottom) > 4) return;
  const extra = Math.round(c.right - b.right);
  if (extra <= 0) return;
  box.style.width = `calc(100% + ${extra}px)`;
  box.classList.add("open");
  tema.classList.add("covered"); colors.classList.add("covered");
  closeThemePop();
}
function collapseFind() {
  els.findBar.style.width = "";
  els.findBar.classList.remove("open");
  els.topbar.querySelectorAll(".field.covered").forEach((f) => f.classList.remove("covered"));
}

let seekFlip = false;
/** Mientras escribes, la lupa se vuelve tres puntos que giran (A/B alternan para reiniciar la animación) */
function seekGlitch() {
  seekFlip = !seekFlip;
  els.findIc.classList.remove("seekA", "seekB");
  els.findIc.classList.add(seekFlip ? "seekA" : "seekB");
}
/** Una línea barre la zona de lectura de arriba abajo */
function scanPages() {
  if (reducedMotion()) return;
  els.viewer.parentElement.querySelector(".scan")?.remove();
  const s = document.createElement("div");
  s.className = "scan";
  s.style.width = `${els.viewer.clientWidth}px`;
  els.viewer.parentElement.appendChild(s);
  setTimeout(() => s.remove(), 900);
}

let findTimer;
/** El campo vive en la barra principal: si está oculta, se muestra */
function openFind() {
  if (els.topbar.hidden) setBarHidden(false);
  // con texto seleccionado, se busca eso
  const sel = getSelection()?.toString().trim();
  const changed = sel && sel.length < 80 && !sel.includes("\n") && sel !== els.findInput.value;
  if (changed) els.findInput.value = sel;
  els.findInput.focus();
  els.findInput.select();
  if (!state.pdf) return;
  if (els.findInput.value.trim() && (changed || !find.matches.length)) runSearch(els.findInput.value);
}
/** Borra la búsqueda y sus marcas */
function closeFind() {
  clearTimeout(findTimer);
  const pages = [...find.byPage.keys()];
  find.run++;
  find.matches = []; find.byPage = new Map(); find.cur = -1; find.done = false;
  pages.forEach((n) => state.pages[n - 1] && drawFindMarks(state.pages[n - 1]));
  els.findInput.value = "";
  updateFindCount();
  if (document.activeElement === els.findInput) els.findInput.blur();
}

/* ============================================================
   Zoom
   ============================================================ */
function anchor() {
  const top = els.viewer.scrollTop;
  const pv = state.pages.find((p) => p.div.offsetTop + p.div.offsetHeight > top) || state.pages[0];
  return pv ? { pv, frac: (top - pv.div.offsetTop) / pv.div.offsetHeight } : null;
}
function setScale(s, fit = false) {
  if (!state.pdf) return;
  const a = anchor();
  state.fit = fit;
  state.scale = clamp(s, 0.25, 5);
  state.pages.forEach(sizePage);
  if (a) els.viewer.scrollTop = a.pv.div.offsetTop + a.frac * a.pv.div.offsetHeight;
  state.pages.forEach((pv) => pv.visible && renderPage(pv));
  updateZoomLabel();
  hideBars();
}
function zoomStep(dir) {
  const cur = state.scale;
  const next = dir > 0 ? ZOOMS.find((z) => z > cur + 0.01) : [...ZOOMS].reverse().find((z) => z < cur - 0.01);
  if (next) setScale(next);
}
function updateZoomLabel() {
  els.zoomLabel.textContent = `${Math.round(state.scale * 100)} %`;
}

/* ============================================================
   Selección → rectángulos
   ============================================================ */
function selectionParts(range) {
  // Recorre sólo nodos de texto para obtener cajas exactas de los glifos
  const root = range.commonAncestorContainer.nodeType === 1
    ? range.commonAncestorContainer
    : range.commonAncestorContainer.parentNode;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode: (n) => (range.intersectsNode(n) && n.parentElement?.closest(".textLayer") ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
  });
  const rects = [];
  let n;
  while ((n = walker.nextNode())) {
    const r = document.createRange();
    r.selectNodeContents(n);
    if (n === range.startContainer) r.setStart(n, range.startOffset);
    if (n === range.endContainer) r.setEnd(n, range.endOffset);
    if (r.collapsed || !r.toString().trim()) continue;
    for (const cr of r.getClientRects()) if (cr.width > 0.5 && cr.height > 0.5) rects.push({ cr, page: n.parentElement.closest(".page") });
  }
  // agrupar por página y normalizar
  const byPage = new Map();
  for (const { cr, page } of rects) {
    if (!page) continue;
    const num = +page.dataset.page;
    const b = page.getBoundingClientRect();
    const list = byPage.get(num) || [];
    list.push({ x: (cr.left - b.left) / b.width, y: (cr.top - b.top) / b.height, w: cr.width / b.width, h: cr.height / b.height });
    byPage.set(num, list);
  }
  const parts = [];
  for (const [page, list] of [...byPage.entries()].sort((a, b) => a[0] - b[0])) {
    const pv = state.pages[page - 1];
    parts.push({ page, rects: mergeRects(list, pv.w / pv.h) });
  }
  return parts.filter((p) => p.rects.length);
}

function mergeRects(list, aspect) {
  list.sort((a, b) => a.y - b.y || a.x - b.x);
  const lines = [];
  for (const r of list) {
    const line = lines.find((l) => {
      const top = Math.max(l.y, r.y), bot = Math.min(l.y + l.h, r.y + r.h);
      return bot - top > 0.5 * Math.min(l.h, r.h);
    });
    if (line) { line.items.push(r); line.y = Math.min(line.y, r.y); line.h = Math.max(line.y + line.h, r.y + r.h) - line.y; }
    else lines.push({ y: r.y, h: r.h, items: [r] });
  }
  const out = [];
  for (const l of lines) {
    l.items.sort((a, b) => a.x - b.x);
    let cur = null;
    for (const r of l.items) {
      const gap = r.h * 1.2 / aspect; // tolerancia horizontal en unidades de ancho
      if (cur && r.x <= cur.x + cur.w + gap) {
        const right = Math.max(cur.x + cur.w, r.x + r.w);
        const top = Math.min(cur.y, r.y), bot = Math.max(cur.y + cur.h, r.y + r.h);
        cur.x = Math.min(cur.x, r.x); cur.w = right - cur.x; cur.y = top; cur.h = bot - top;
      } else {
        if (cur) out.push(cur);
        cur = { ...r };
      }
    }
    if (cur) out.push(cur);
  }
  return out.map((r) => [r.x, r.y, r.w, r.h].map((v) => +v.toFixed(5)));
}

function currentRange() {
  const sel = getSelection();
  if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
  const range = sel.getRangeAt(0);
  if (!els.pages.contains(range.commonAncestorContainer)) return null;
  if (!sel.toString().trim()) return null;
  return range;
}

/* ============================================================
   Marcas: crear, editar, borrar
   ============================================================ */
function snapshot() {
  state.undo.push(JSON.stringify(state.highlights));
  if (state.undo.length > 80) state.undo.shift();
  state.redo = [];
}
function commit() {
  saveHighlights();
  state.pages.forEach(drawPageHighlights);
  renderList();
  if (comp.id) placeComposer(); // (se cierra si su marca ya no está, p. ej. tras deshacer)
}

function highlightSelection(color = state.color) {
  const range = currentRange();
  if (!range) return null;
  const parts = selectionParts(range);
  if (!parts.length) return null;
  const text = cleanText(getSelection().toString());
  snapshot();
  const h = { id: uid(), color, style: state.style, text, created: Date.now(), parts };
  state.highlights.push(h);
  getSelection().removeAllRanges();
  hideBars();
  markFresh(h);
  commit();
  return h;
}

let freshTimer, freshAnim = null; // tiempos de cada renglón de la marca nueva (no se guardan con la marca)
/** La marca nueva se dibuja avanzando: hasta 0,9 s en total, repartidos entre sus renglones según su ancho */
function markFresh(h) {
  if (reducedMotion()) return;
  const rects = h.parts.flatMap((p) => p.rects);
  const total = rects.reduce((s, r) => s + r[2], 0) || 1;
  const dur = clamp((h.text || "").length * 0.02, 0.25, 0.9);
  let acc = 0;
  freshAnim = rects.map((r) => { const d = acc; acc += r[2] / total * dur; return { d, du: Math.max(r[2] / total * dur, 0.04) }; });
  state.fresh = h.id;
  clearTimeout(freshTimer);
  freshTimer = setTimeout(() => { if (state.fresh === h.id) { state.fresh = null; freshAnim = null; } }, dur * 1000 + 700);
}

function updateHighlight(id, patch) {
  const h = state.highlights.find((x) => x.id === id);
  if (!h) return;
  snapshot();
  Object.assign(h, patch);
  commit();
}
function deleteHighlight(id) {
  const i = state.highlights.findIndex((x) => x.id === id);
  if (i < 0) return;
  snapshot();
  state.highlights.splice(i, 1);
  if (state.activeId === id) state.activeId = null;
  hideBars();
  commit();
  toast("Marca borrada · Ctrl+Z para deshacer");
}
function undo() {
  if (!state.undo.length) return;
  state.redo.push(JSON.stringify(state.highlights));
  state.highlights = JSON.parse(state.undo.pop());
  hideBars(); commit();
}
function redo() {
  if (!state.redo.length) return;
  state.undo.push(JSON.stringify(state.highlights));
  state.highlights = JSON.parse(state.redo.pop());
  hideBars(); commit();
}

function drawPageHighlights(pv) {
  const layer = pv.hlLayer;
  layer.innerHTML = "";
  const aspect = pv.h / pv.w;
  const dark = document.documentElement.dataset.mode === "dark";
  for (const h of state.highlights) {
    // tinta oscura con texto invertido: una capa invierte la página (difference) y otra la tiñe (screen)
    const inv = !dark && inverts(h);
    const anim = h.id === state.fresh && freshAnim;
    let k = -1; // índice del renglón dentro de toda la marca (para el retraso de la animación)
    for (const part of h.parts) {
      if (part.page !== pv.num) { k += part.rects.length; continue; }
      for (const r of part.rects) {
        k++;
        const [x, y, w, hh] = drawBox(r, aspect);
        const t = anim && anim[k];
        const place = (el) => {
          el.style.left = `${x * 100}%`; el.style.top = `${y * 100}%`;
          el.style.width = `${w * 100}%`; el.style.height = `${hh * 100}%`;
          if (t) { el.classList.add("new"); el.style.setProperty("--d", `${t.d.toFixed(3)}s`); el.style.setProperty("--du", `${t.du.toFixed(3)}s`); }
        };
        if (inv) {
          const back = document.createElement("div");
          back.className = "hl-inv";
          place(back);
          layer.appendChild(back);
        }
        const d = document.createElement("div");
        d.className = "hl-rect" + (h.style === "underline" ? " underline" : "") + (inv ? " invert" : "") + (h.id === state.activeId ? " focus" : "");
        d.dataset.id = h.id;
        const def = colorDef(h.color);
        d.style.setProperty("--c", def.hex);
        d.style.setProperty("--cd", def.ui || def.hex);
        if (def.ui) d.style.setProperty("--edge-d", "rgba(236,231,221,.55)");
        d.style.setProperty("--a", h.style === "underline" ? 1 : def.alpha ?? 1);
        if (def.edge) d.style.setProperty("--edge", def.edge);
        place(d);
        layer.appendChild(d);
        if (t) {
          // cursor que va delante del color (fuera de la marca, que lleva transparencia)
          const cur = document.createElement("div");
          cur.className = "hl-cur";
          colorVars(cur, def);
          place(cur);
          cur.classList.remove("new");
          layer.appendChild(cur);
        }
      }
    }
  }
}

function hitTest(clientX, clientY) {
  const pageEl = document.elementsFromPoint(clientX, clientY).find((e) => e.classList?.contains("page"));
  if (!pageEl) return null;
  const b = pageEl.getBoundingClientRect();
  const px = (clientX - b.left) / b.width, py = (clientY - b.top) / b.height;
  const num = +pageEl.dataset.page;
  const pv = state.pages[num - 1];
  for (let i = state.highlights.length - 1; i >= 0; i--) {
    const h = state.highlights[i];
    for (const part of h.parts) {
      if (part.page !== num) continue;
      for (const r of part.rects) {
        const [x, y, w, hh] = drawBox(r, pv.h / pv.w);
        if (px >= x && px <= x + w && py >= y && py <= y + hh) return h;
      }
    }
  }
  return null;
}

/* ============================================================
   Barras flotantes
   ============================================================ */
function placeBar(bar, x, y) {
  bar.hidden = false;
  const bw = bar.offsetWidth, bh = bar.offsetHeight;
  let left = clamp(x - bw / 2, 8, innerWidth - bw - 8);
  let top = y - bh - 12;
  if (top < 64) top = y + 18;
  bar.style.left = `${left}px`;
  bar.style.top = `${top}px`;
}
function hideBars() {
  els.selBar.hidden = true;
  els.hlMenu.hidden = true;
  if (state.activeId) { state.activeId = null; refreshFocus(); }
}
function refreshFocus() {
  document.querySelectorAll(".hl-rect").forEach((d) => d.classList.toggle("focus", d.dataset.id === state.activeId));
  document.querySelectorAll(".hl-item").forEach((d) => d.classList.toggle("active", d.dataset.id === state.activeId));
  document.querySelectorAll(".mm-mark").forEach((d) => d.classList.toggle("on", d.dataset.id === state.activeId));
}
function showSelectionBar(range) {
  const rects = range.getClientRects();
  const last = rects[rects.length - 1] || range.getBoundingClientRect();
  const first = rects[0] || last;
  els.hlMenu.hidden = true;
  placeBar(els.selBar, (first.left + last.right) / 2, first.top);
}
function showHighlightMenu(h, x, y) {
  els.selBar.hidden = true;
  state.activeId = h.id;
  refreshFocus();
  els.menuSwatches.querySelectorAll(".swatch").forEach((b) => b.classList.toggle("active", b.dataset.color === h.color));
  placeBar(els.hlMenu, x, y);
  els.hlList.querySelector(`[data-id="${h.id}"]`)?.scrollIntoView({ block: "nearest", behavior: "smooth" });
}

/* ============================================================
   Capturas
   ============================================================ */
const hiResCache = new Map();
async function hiResPage(num) {
  if (hiResCache.has(num)) return hiResCache.get(num);
  const page = await state.pdf.getPage(num);
  const base = page.getViewport({ scale: 1 });
  const vp = page.getViewport({ scale: clamp(CAPTURE_WIDTH / base.width, 1, 6) });
  const c = document.createElement("canvas");
  c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
  const ctx = c.getContext("2d", { alpha: false });
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
  await page.render({ canvasContext: ctx, viewport: vp }).promise;
  hiResCache.set(num, c);
  if (hiResCache.size > 4) hiResCache.delete(hiResCache.keys().next().value);
  return c;
}

function roundRect(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/** Dibuja los subrayados de una página sobre un canvas de W×H (opcionalmente recortado en x0,y0 / cw×ch) */
function paintHighlights(ctx, num, W, H, x0 = 0, y0 = 0, cw = W, ch = H) {
  const pv = state.pages[num - 1];
  if (!pv) return;
  const aspect = pv.h / pv.w;
  ctx.save();
  ctx.globalCompositeOperation = "multiply";
  for (const other of state.highlights) {
    for (const p of other.parts) {
      if (p.page !== num) continue;
      const def = colorDef(other.color);
      const inv = inverts(other);
      ctx.fillStyle = def.hex;
      ctx.globalAlpha = other.style === "underline" || inv ? 1 : def.alpha ?? 1;
      for (const r of p.rects) {
        const [bx, by, bw, bh] = drawBox(r, aspect);
        const X = bx * W - x0, Y = by * H - y0, Wd = bw * W, Hd = bh * H;
        if (X > cw || Y > ch || X + Wd < 0 || Y + Hd < 0) continue;
        if (other.style === "underline") roundRect(ctx, X, Y + Hd * 0.76, Wd, Hd * 0.24, Hd * 0.08);
        else roundRect(ctx, X, Y, Wd, Hd, Hd * 0.14);
        if (inv) {
          // texto invertido: se invierte la zona y luego se tiñe con la tinta
          ctx.globalCompositeOperation = "difference"; ctx.fillStyle = "#ffffff"; ctx.fill();
          ctx.globalCompositeOperation = "screen"; ctx.fillStyle = def.hex; ctx.fill();
          ctx.globalCompositeOperation = "multiply";
          continue;
        }
        ctx.fill();
        if (def.edge) { ctx.strokeStyle = def.edge; ctx.lineWidth = Math.max(2, Hd * 0.045); ctx.stroke(); }
      }
      ctx.globalAlpha = 1;
    }
  }
  ctx.restore();
}

async function capturePart(h, part) {
  const pv = state.pages[part.page - 1];
  const src = await hiResPage(part.page);
  const W = src.width, H = src.height, aspect = pv.h / pv.w;
  const boxes = part.rects.map((r) => drawBox(r, aspect));
  const avgH = part.rects.reduce((s, r) => s + r[3], 0) / part.rects.length * H;
  let x0 = Math.min(...boxes.map((b) => b[0])) * W;
  let y0 = Math.min(...boxes.map((b) => b[1])) * H;
  let x1 = Math.max(...boxes.map((b) => b[0] + b[2])) * W;
  let y1 = Math.max(...boxes.map((b) => b[1] + b[3])) * H;
  const padX = avgH * 0.9, padY = avgH * 0.6;
  x0 = Math.floor(clamp(x0 - padX, 0, W)); y0 = Math.floor(clamp(y0 - padY, 0, H));
  x1 = Math.ceil(clamp(x1 + padX, 0, W));  y1 = Math.ceil(clamp(y1 + padY, 0, H));
  const cw = x1 - x0, ch = y1 - y0;

  const out = document.createElement("canvas");
  out.width = cw; out.height = ch;
  const ctx = out.getContext("2d");
  ctx.drawImage(src, x0, y0, cw, ch, 0, 0, cw, ch);
  // margen blanco limpio: tapa las líneas vecinas que quedarían cortadas a la mitad
  const firstH = Math.min(...boxes.map((b) => b[3])) * H;
  const top = Math.min(...boxes.map((b) => b[1])) * H - y0 + firstH * 0.12; // quita colas de la línea anterior
  const bottom = Math.max(...boxes.map((b) => b[1] + b[3])) * H - y0;
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, cw, Math.max(0, top));
  ctx.fillRect(0, bottom + 1, cw, ch - bottom);

  // dibuja todos los subrayados que caen dentro del recorte (como una captura real)
  paintHighlights(ctx, part.page, W, H, x0, y0, cw, ch);
  return out;
}

async function captureHighlight(h) {
  const pieces = [];
  for (const part of h.parts) pieces.push(await capturePart(h, part));
  if (pieces.length === 1) return pieces[0];
  const gap = 24;
  const w = Math.max(...pieces.map((p) => p.width));
  const c = document.createElement("canvas");
  c.width = w; c.height = pieces.reduce((s, p) => s + p.height, 0) + gap * (pieces.length - 1);
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
  let y = 0;
  for (const p of pieces) { ctx.drawImage(p, 0, y); y += p.height + gap; }
  return c;
}

const toBlob = (canvas) => new Promise((res) => canvas.toBlob(res, "image/png"));
function download(blob, filename) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
async function copyImage(blobPromise) {
  try {
    await navigator.clipboard.write([new ClipboardItem({ "image/png": blobPromise })]);
    toast("Imagen copiada ✓");
  } catch (e) {
    console.error(e);
    toast("No se pudo copiar; usa Descargar");
  }
}
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast("Texto copiado ✓"); }
  catch { toast("No se pudo copiar el texto"); }
}
const shotName = (h) => `${safeName(state.docName)}_p${h.parts[0].page}_${h.id.slice(0, 4)}.png`;

let modalBlob = null, modalName = "", modalKind = null;
function showModal({ title, meta, note = "", blob, name, kind }) {
  modalBlob = blob; modalName = name; modalKind = kind;
  if (els.shotImg.src) URL.revokeObjectURL(els.shotImg.src);
  els.shotImg.src = URL.createObjectURL(blob);
  els.modal.querySelector("h3").textContent = title;
  els.shotMeta.textContent = meta;
  els.shotNote.textContent = note;
  els.shotFilters.hidden = kind !== "all";
  els.modal.hidden = false;
}
async function openShot(h) {
  const canvas = await captureHighlight(h);
  showModal({
    title: "Captura",
    meta: `página ${h.parts.map((p) => p.page).join("–")} · ${canvas.width} px · PNG`,
    blob: await toBlob(canvas), name: shotName(h), kind: "one",
  });
}
const closeShot = () => { els.modal.hidden = true; modalKind = null; };

function positionOf(h) {
  const p = h.parts[0];
  const r = p.rects[0] || [0, 0];
  return p.page * 10 + r[1] * 9 + r[0] * 0.001;
}
const sortedHighlights = () => [...state.highlights].sort((a, b) => positionOf(a) - positionOf(b));

const SHEET_W = 1800;
const plural = (n) => `${n} marca${n === 1 ? "" : "s"}`;

/** Hoja con todas las marcas (en orden de lectura, con página y barra de color) */
async function buildSheet(list) {
  const shots = [];
  for (const h of list) shots.push({ h, c: await captureHighlight(h) });
  await Promise.all([
    document.fonts.load('400 52px "Newsreader"'),
    document.fonts.load('400 24px "JetBrains Mono"'),
  ]).catch(() => {});

  const W = SHEET_W, pad = 96, gap = 52, barW = 8, labelW = 96;
  const x0 = pad + barW + 24 + labelW;           // donde empieza la imagen
  const inner = W - x0 - pad;
  const scaled = shots.map(({ h, c }) => {
    const s = Math.min(1, inner / c.width);
    return { h, c, w: Math.round(c.width * s), hgt: Math.round(c.height * s) };
  });
  const headH = 250;
  const H = headH + scaled.reduce((s, x) => s + x.hgt + gap, 0) + pad - gap;
  const out = document.createElement("canvas");
  out.width = W; out.height = H;
  const ctx = out.getContext("2d");
  ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, W, H);

  // encabezado: título en serif, fecha y conteo en mono
  const serif = '"Newsreader", Georgia, serif', mono = '"JetBrains Mono", ui-monospace, monospace';
  ctx.textBaseline = "alphabetic";
  ctx.fillStyle = "#111111";
  ctx.font = `400 52px ${serif}`;
  let title = state.docName.replace(/\.pdf$/i, "");
  while (title.length > 8 && ctx.measureText(title).width > W - pad * 2 - 360) title = title.slice(0, -2);
  if (title !== state.docName.replace(/\.pdf$/i, "")) title += "…";
  ctx.fillText(title, pad, pad + 40);
  ctx.fillStyle = "#5E5B56";
  ctx.font = `400 22px ${mono}`;
  const date = new Date().toLocaleDateString("es-MX", { day: "numeric", month: "short", year: "numeric" });
  ctx.textAlign = "right";
  ctx.fillText(date, W - pad, pad + 40);
  ctx.textAlign = "left";
  ctx.fillText(plural(list.length), pad, pad + 86);
  ctx.fillStyle = "#111111";
  ctx.fillRect(pad, headH - 44, W - pad * 2, 2);

  let y = headH;
  for (const s of scaled) {
    const def = colorDef(s.h.color);
    ctx.fillStyle = def.hex;
    ctx.fillRect(pad, y, barW, s.hgt);
    if (def.edge) { ctx.strokeStyle = "#CFCBC3"; ctx.lineWidth = 2; ctx.strokeRect(pad, y, barW, s.hgt); }
    ctx.fillStyle = "#5E5B56";
    ctx.font = `400 22px ${mono}`;
    ctx.fillText(`p.${s.h.parts.map((p) => p.page).join("–")}`, pad + barW + 24, y + 26);
    ctx.drawImage(s.c, x0, y, s.w, s.hgt);
    y += s.hgt + gap;
  }
  return out;
}

function renderSheetFilters() {
  const counts = {};
  state.highlights.forEach((h) => (counts[h.color] = (counts[h.color] || 0) + 1));
  const used = ALL_COLORS.filter((c) => counts[c.id]);
  els.shotFilters.innerHTML = "";
  if (used.length < 2) { els.shotFilters.hidden = true; return; }
  const add = (label, id, def) => {
    const b = document.createElement("button");
    b.className = (state.filter || null) === id ? "on" : "";
    if (def) { colorVars(b, def); b.innerHTML = `<i></i>${label}`; b.title = `Sólo ${def.name.toLowerCase()}`; }
    else b.textContent = label;
    b.onclick = () => { state.filter = id; renderList(); exportAll(); };
    els.shotFilters.appendChild(b);
  };
  add("Todas", null);
  used.forEach((c) => add(counts[c.id], c.id, c));
}

async function exportAll() {
  const list = sortedHighlights().filter((h) => !state.filter || h.color === state.filter);
  if (!list.length) return toast("No hay marcas todavía");
  if (els.modal.hidden) toast(`Generando ${plural(list.length)}…`);
  const sheet = await buildSheet(list);
  showModal({
    title: "Todas las marcas",
    meta: `${plural(list.length)} · ${sheet.width} px · PNG`,
    note: "Orden de lectura · con número de página y barra de color",
    blob: await toBlob(sheet), name: `${safeName(state.docName)}_marcas.png`, kind: "all",
  });
  renderSheetFilters();
  els.toast.hidden = true;
}

/* ============================================================
   Impresión
   ============================================================ */
let printing = false, printUrls = [], printCancel = false, progressSpan = null;
function clearPrint() {
  printUrls.forEach((u) => u && URL.revokeObjectURL(u));
  printUrls = [];
  els.printBox.innerHTML = "";
  document.body.classList.remove("print-ready");
}

/** Aviso de progreso con botón para cancelar (sólo se arma una vez) */
function printProgress(done, n) {
  if (!progressSpan || !els.toast.contains(progressSpan)) {
    els.toast.textContent = "";
    progressSpan = document.createElement("span");
    els.toast.appendChild(progressSpan);
    if (n > 4) {
      const b = document.createElement("button");
      b.className = "toast-btn";
      b.textContent = "Cancelar";
      b.onclick = () => { printCancel = true; toast("Impresión cancelada"); };
      els.toast.appendChild(b);
    }
    els.toast.hidden = false;
  }
  progressSpan.textContent = n > 1 ? `Preparando impresión · ${done} de ${n}` : "Preparando impresión…";
  clearTimeout(toastTimer);
}

/* Ruta rápida: cuando no hay que pintar nada encima, se imprime el PDF tal cual
   en un iframe. Es inmediato y el texto se imprime vectorial, no rasterizado. */
async function printNative() {
  let url = null, frame = null;
  try {
    const data = await state.pdf.getData();
    url = URL.createObjectURL(new Blob([data], { type: "application/pdf" }));
    frame = document.createElement("iframe");
    frame.setAttribute("aria-hidden", "true");
    frame.style.cssText = "position:fixed;left:-10000px;top:0;width:820px;height:1060px;border:0";
    frame.src = url;
    const loaded = await new Promise((res) => {
      let settled = false;
      const end = (v) => { if (!settled) { settled = true; res(v); } };
      frame.onload = () => end(true);
      frame.onerror = () => end(false);
      setTimeout(() => end(false), 10000);
      document.body.appendChild(frame);
    });
    const win = loaded && frame.contentWindow;
    if (!win || typeof win.print !== "function") throw new Error("sin visor en el iframe");
    // si Chrome descarga los PDFs en vez de mostrarlos, el iframe queda vacío
    if (!frame.contentDocument?.querySelector("embed, object")) throw new Error("el PDF no se abrió en el iframe");
    await new Promise((r) => setTimeout(r, 250)); // deja que el visor arme las páginas
    win.focus();
    win.print();
    // print() bloquea hasta que se cierra el diálogo; aun así damos margen
    setTimeout(() => { frame.remove(); URL.revokeObjectURL(url); }, 120000);
    return true;
  } catch (e) {
    console.warn("Impresión directa no disponible, se rasteriza:", e);
    frame?.remove();
    if (url) URL.revokeObjectURL(url);
    return false;
  }
}

async function renderPrintPage(num, withHl) {
  const page = await state.pdf.getPage(num);
  const base = page.getViewport({ scale: 1 });
  if (state.pages[num - 1]) resizePage(state.pages[num - 1], base.width, base.height); // la hoja impresa usa la medida real
  // ~150 ppp, con tope de 16 MP por página para no agotar memoria
  const scale = Math.min(PRINT_DPI / 72, Math.sqrt(16e6 / (base.width * base.height)));
  const vp = page.getViewport({ scale });
  const c = document.createElement("canvas");
  c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
  const ctx = c.getContext("2d", { alpha: false });
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
  await page.render({ canvasContext: ctx, viewport: vp, intent: "print" }).promise;
  if (withHl) paintHighlights(ctx, num, c.width, c.height);
  return c;
}

/* Ruta lenta: hay subrayados que pintar (o la ruta directa falló), así que cada
   página se rasteriza. Varias páginas en paralelo, y los decodes se esperan todos al final. */
async function printRaster(withHl) {
  const pdf = state.pdf, n = pdf.numPages;
  const first = state.pages[0];
  els.printStyle.textContent = `@page { size: ${first.w}pt ${first.h}pt; margin: 0; }`;
  printUrls = new Array(n);
  printCancel = false;
  let done = 0, next = 0;
  printProgress(0, n);

  // 3 páginas en vuelo, 2 si son muy grandes (memoria)
  const big = first.w * first.h * (PRINT_DPI / 72) ** 2 > 8e6;
  const lanes = Math.min(big ? 2 : 3, n);
  const lane = async () => {
    while (true) {
      const i = next++;
      if (i >= n || printCancel || pdf !== state.pdf) return;
      const c = await renderPrintPage(i + 1, withHl);
      if (printCancel || pdf !== state.pdf) return;
      const blob = await toBlob(c);
      c.width = c.height = 0; // libera el canvas en cuanto se comprime
      printUrls[i] = URL.createObjectURL(blob);
      printProgress(++done, n);
    }
  };
  await Promise.all(Array.from({ length: lanes }, lane));
  if (printCancel || pdf !== state.pdf) { clearPrint(); return false; }

  const imgs = [];
  for (let i = 0; i < n; i++) {
    const pv = state.pages[i];
    const wrap = document.createElement("div");
    wrap.className = "print-page";
    wrap.style.width = `${pv.w}pt`;
    wrap.style.height = `${pv.h}pt`;
    const img = new Image();
    img.alt = "";
    img.src = printUrls[i];
    wrap.appendChild(img);
    els.printBox.appendChild(wrap);
    imgs.push(img);
  }
  await Promise.all(imgs.map((i) => i.decode().catch(() => {})));
  if (printCancel) { clearPrint(); return false; }
  document.body.classList.add("print-ready");
  els.toast.hidden = true;
  await new Promise((r) => setTimeout(r, 60));
  window.print();
  return true;
}

/** Descarga el PDF original, tal cual se abrió (sin los subrayados) */
async function downloadPdf() {
  if (!state.pdf) return toast("Abre un PDF para descargarlo");
  try {
    const data = await state.pdf.getData();
    const name = /\.pdf$/i.test(state.docName) ? state.docName : `${state.docName || "documento"}.pdf`;
    download(new Blob([data], { type: "application/pdf" }), name);
    toast("PDF descargado ✓");
  } catch (e) {
    console.error(e);
    toast("No se pudo descargar el PDF");
  }
}

async function printDocument() {
  if (!state.pdf) return toast("Abre un PDF para imprimir");
  if (printing) return;
  printing = true;
  els.printBtn.classList.add("busy");
  hideBars();
  clearPrint();
  try {
    // Sin subrayados que pintar no hace falta rasterizar nada
    const needsRaster = state.printHl && state.highlights.length > 0;
    if (!needsRaster && (await printNative())) return;
    await printRaster(needsRaster);
  } catch (e) {
    console.error(e);
    toast("No se pudo preparar la impresión");
    clearPrint();
  } finally {
    printing = false;
    els.printBtn.classList.remove("busy");
  }
}

/* ============================================================
   Panel lateral: marcas
   ============================================================ */
const ICON = {
  copy: `<svg class="ic" viewBox="0 0 24 24"><path d="M8 8h11v11H8z M5 16V5h11"/></svg>`,
  shot: `<svg class="ic" viewBox="0 0 24 24"><path d="M3 7h4l2-2h6l2 2h4v12H3z M12 10a3 3 0 1 0 0 6a3 3 0 1 0 0-6"/></svg>`,
  note: `<svg class="ic" viewBox="0 0 24 24"><path d="M4 4h16v12H9l-5 4z"/></svg>`,
  del: `<svg class="ic" viewBox="0 0 24 24"><path d="M5 7h14 M9 7V4h6v3 M7 7l1 13h8l1-13"/></svg>`,
};
const pad2 = (n) => String(n).padStart(2, "0");
const pagesOf = (h) => h.parts.map((p) => p.page).join("–");

function renderList() {
  const all = sortedHighlights();
  els.hlCount.textContent = all.length;
  const counts = {};
  all.forEach((h) => (counts[h.color] = (counts[h.color] || 0) + 1));
  const used = ALL_COLORS.filter((c) => counts[c.id]);

  // filtros por color
  els.filters.innerHTML = "";
  if (used.length > 1) {
    const label = document.createElement("span");
    label.textContent = "Filtrar:";
    const allBtn = document.createElement("button");
    allBtn.className = "chip" + (state.filter ? "" : " active");
    allBtn.textContent = "Todas";
    allBtn.onclick = () => { state.filter = null; renderList(); };
    els.filters.append(label, allBtn);
    used.forEach((c) => {
      const b = document.createElement("button");
      b.className = "chip" + (state.filter === c.id ? " active" : "");
      b.append(swatchI(c), `${c.name} ${counts[c.id]}`);
      b.title = `Mostrar sólo ${c.name.toLowerCase()}`;
      b.onclick = () => { state.filter = state.filter === c.id ? null : c.id; renderList(); };
      els.filters.appendChild(b);
    });
  } else state.filter = null;

  renderLegend(used, counts);
  renderMarkMap(all);
  updateTocMarks();

  const list = all.filter((h) => !state.filter || h.color === state.filter);
  const fc = state.filter && colorDef(state.filter);
  els.exportLabel.textContent = !list.length ? "Todavía no hay marcas que exportar"
    : list.length === 1 ? `Exportar la marca ${fc ? `en ${fc.name.toLowerCase()}` : "de este documento"}`
    : `Exportar las ${list.length} marcas ${fc ? `en ${fc.name.toLowerCase()}` : "de este documento"}`;

  els.hlList.innerHTML = "";
  if (!list.length) {
    els.hlList.innerHTML = state.pdf
      ? `<li class="hl-empty">Selecciona texto en el PDF y elige una tinta en la barra que aparece.<br><b>1–${themeColors().length}</b> tinta · <b>M</b> marcado automático · <b>Ctrl+Z</b> deshacer</li>`
      : `<li class="hl-empty">Abre un PDF para empezar.</li>`;
    return;
  }
  const rise = state.listRise;
  state.listRise = false;
  list.forEach((h, k) => {
    const def = colorDef(h.color);
    const li = document.createElement("li");
    li.className = "hl-item" + (h.id === state.activeId ? " active" : "") + (h.id === comp.id ? " composing" : "");
    // al abrir el documento la lista entra subiendo; la marca recién hecha se abre en su lugar
    if (h.id === state.fresh) li.classList.add("slot");
    else if (rise && k < 12) { li.classList.add("rise"); li.style.setProperty("--d", `${(0.3 + k * 0.06).toFixed(2)}s`); }
    li.dataset.id = h.id;
    colorVars(li, def);
    const bar = document.createElement("span");
    bar.className = "hl-bar" + (needsEdge(def) ? " edge" : "");
    const body = document.createElement("div");
    body.className = "hl-body";

    const meta = document.createElement("div");
    meta.className = "hl-meta";
    const num = document.createElement("span");
    num.className = "hl-num";
    num.textContent = pad2(all.indexOf(h) + 1);
    const kind = document.createElement("span");
    const invNow = inverts(h) && document.documentElement.dataset.mode !== "dark";
    kind.textContent = def.name + (h.style === "underline" ? " · subrayado" : invNow ? " · texto invertido" : "");
    const pg = document.createElement("span");
    pg.textContent = `Página ${pagesOf(h)}`;
    const go = document.createElement("button");
    go.className = "hl-go";
    go.dataset.a = "go";
    go.textContent = "Ir a la página";
    meta.append(num, kind, "·", pg);
    if (h.id === state.savedNote) {
      const stamp = document.createElement("span");
      stamp.className = "hl-stamp";
      stamp.textContent = "Nota guardada";
      meta.appendChild(stamp);
    }
    meta.appendChild(go);

    const txt = document.createElement("div");
    txt.className = "hl-text";
    txt.textContent = h.text || "(sin texto)";
    body.append(meta, txt);
    if (h.note) {
      const note = document.createElement("div");
      note.className = "hl-note";
      note.innerHTML = ICON.note;
      note.append(h.note);
      note.title = "Clic para editar la nota";
      note.dataset.a = "note";
      body.appendChild(note);
    }
    const btns = document.createElement("div");
    btns.className = "hl-btns";
    btns.innerHTML = `
      <button class="ctl" data-a="text" title="Copiar el texto">${ICON.copy}Copiar</button>
      <button class="ctl" data-a="shot" title="Ver la captura (copiar o descargar)">${ICON.shot}Capturar</button>
      <button class="ctl" data-a="note" title="Escribir una nota">${ICON.note}Nota</button>
      <button class="ctl danger" data-a="del" title="Borrar la marca (Supr)">${ICON.del}Borrar</button>`;
    body.appendChild(btns);
    li.append(bar, body);
    li.addEventListener("click", (e) => {
      if (e.target.closest("textarea")) return;
      const a = e.target.closest("[data-a]")?.dataset.a;
      if (a === "shot") return openShot(h);
      if (a === "text") return copyText(h.note ? `${h.text}\n\nNota: ${h.note}` : h.text);
      if (a === "del") return deleteHighlight(h.id);
      if (a === "note") return openComposer(h);
      goTo(h);
    });
    els.hlList.appendChild(li);
  });
}

/* ============================================================
   Nota: tarjeta junto al panel, unida a la marca por un cable
   ============================================================ */
const comp = { id: null };
let stampTimer;

/** Dónde nace el cable: el borde derecho de la página, a la altura del primer renglón de la marca */
function notePoint(h) {
  const part = h.parts[0], pv = state.pages[part.page - 1];
  const r = part.rects[0] || [0, 0, 0, 0];
  const b = pv.div.getBoundingClientRect();
  return { x: b.right, y: b.top + (r[1] + r[3] / 2) * b.height };
}
function placeComposer() {
  const h = state.highlights.find((x) => x.id === comp.id);
  if (!h) return closeComposer();
  const vr = els.viewer.getBoundingClientRect();
  const side = els.sidebar.offsetWidth && innerWidth > 1000 ? els.sidebar.getBoundingClientRect() : null;
  const w = side ? Math.min(360, side.width - 32) : Math.min(360, vr.width - 32);
  const left = side ? side.left + 16 : vr.right - w - 16;
  const ch = els.cpCard.offsetHeight || 220;
  const p = notePoint(h);
  const ly = clamp(p.y, vr.top + 8, vr.bottom - 8);
  els.cpCard.style.width = `${w}px`;
  els.cpCard.style.left = `${left}px`;
  els.cpCard.style.top = `${clamp(ly - 24, vr.top + 16, Math.max(vr.top + 16, vr.bottom - ch - 16))}px`;
  // el cable sólo se ve si la marca está a la vista y queda espacio entre la página y la tarjeta
  const x = Math.min(p.x, vr.right) - 3;
  const showWire = p.y > vr.top && p.y < vr.bottom && left - x > 12;
  els.cpDot.hidden = els.cpWire.hidden = !showWire;
  els.cpDot.style.left = `${x}px`; els.cpDot.style.top = `${ly}px`;
  els.cpWire.style.left = `${x + 6}px`; els.cpWire.style.top = `${ly}px`;
  els.cpWire.style.width = `${Math.max(0, left - x - 6)}px`;
}
function updateCpLen() {
  const n = els.cpText.value.length;
  els.cpLen.textContent = n ? `${n} caracter${n === 1 ? "" : "es"}` : `${isMac ? "⌘↵" : "Ctrl+↵"} para guardar`;
}
/** Abre la tarjeta de nota de una marca (la de la selección recién marcada o una de la lista) */
function openComposer(h) {
  hideBars();
  comp.id = h.id;
  state.activeId = h.id;
  const title = `NOTA · MARCA ${pad2(sortedHighlights().indexOf(h) + 1)} · P. ${h.parts[0].page}`;
  els.cpTitle.textContent = title;
  els.cpTitle.style.setProperty("--w", `calc(${title.length}ch + ${(title.length * 0.08).toFixed(2)}em)`);
  colorVars(els.cpBar, colorDef(h.color));
  els.cpText.value = h.note || "";
  updateCpLen();
  // reinicia las animaciones (punto, cable, tarjeta, título que se escribe)
  els.composer.hidden = true;
  void els.composer.offsetWidth;
  els.composer.hidden = false;
  placeComposer();
  renderList();
  refreshFocus();
  els.hlList.querySelector(`[data-id="${h.id}"]`)?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  setTimeout(() => comp.id === h.id && els.cpText.focus({ preventScroll: true }), reducedMotion() ? 0 : 600);
}
/** save: guarda lo escrito (vacío borra la nota) */
function closeComposer(save = false) {
  if (!comp.id) return;
  const h = state.highlights.find((x) => x.id === comp.id);
  comp.id = null;
  els.composer.hidden = true;
  if (save && h) {
    const note = els.cpText.value.trim();
    if (note !== (h.note || "")) {
      snapshot();
      if (note) h.note = note; else delete h.note;
      saveHighlights();
    }
    state.savedNote = note ? h.id : null;
    clearTimeout(stampTimer);
    if (note) stampTimer = setTimeout(() => { state.savedNote = null; renderList(); }, 2600);
  }
  renderList();
}

/** Leyenda de la franja: cuántas marcas hay de cada tinta */
function renderLegend(used, counts) {
  els.legend.replaceChildren(...used.slice(0, 4).map((c) => {
    const s = document.createElement("span");
    s.append(swatchI(c), `${c.name} ${counts[c.id]}`);
    return s;
  }));
}

/** Mapa de marcas: el documento entero en una línea; cada marca, en su lugar */
function renderMarkMap(all = sortedHighlights()) {
  const track = els.markMap;
  track.innerHTML = "";
  const n = state.pages.length;
  if (!n) return;
  if (!all.length) {
    const e = document.createElement("span");
    e.className = "mm-empty";
    e.textContent = "Todavía no hay marcas";
    track.appendChild(e);
  }
  all.forEach((h, i) => {
    const def = colorDef(h.color);
    const first = h.parts[0], last = h.parts.at(-1);
    const r0 = first.rects[0] || [0, 0, 0, 0], r1 = last.rects.at(-1) || r0;
    const a = (first.page - 1 + r0[1]) / n, b = (last.page - 1 + r1[1] + r1[3]) / n;
    const m = document.createElement("button");
    m.className = "mm-mark" + (needsEdge(def) ? " edge" : "") + (h.id === state.activeId ? " on" : "");
    m.dataset.id = h.id;
    colorVars(m, def);
    m.style.left = `${a * 100}%`;
    m.style.width = `${Math.max(0, b - a) * 100}%`;
    m.setAttribute("aria-label", `Marca ${pad2(i + 1)}, ${def.name}, página ${first.page}`);
    m.addEventListener("mouseenter", () => {
      els.markTip.textContent = `Marca ${pad2(i + 1)} · ${def.name} · p. ${first.page}`;
      els.markTip.hidden = false;
      const box = track.parentElement.getBoundingClientRect(), mr = m.getBoundingClientRect();
      els.markTip.style.left = `${clamp(mr.left + mr.width / 2 - box.left, 60, box.width - 60)}px`;
    });
    m.addEventListener("mouseleave", () => (els.markTip.hidden = true));
    m.addEventListener("click", () => goTo(h));
    track.appendChild(m);
  });
  const here = document.createElement("span");
  here.className = "mm-here";
  track.appendChild(here);
  moveMapCursor();
}
/** Dónde vas leyendo, sobre el mapa de marcas */
function moveMapCursor() {
  const here = els.markMap.querySelector(".mm-here");
  const a = anchor();
  if (!here || !a || !state.pages.length) return;
  here.style.left = `${clamp((a.pv.num - 1 + clamp(a.frac, 0, 1)) / state.pages.length, 0, 1) * 100}%`;
}

function goTo(h) {
  const part = h.parts[0];
  const pv = state.pages[part.page - 1];
  const y = pv.div.offsetTop + (part.rects[0]?.[1] || 0) * pv.div.offsetHeight - els.viewer.clientHeight * 0.3;
  els.viewer.scrollTo({ top: Math.max(0, y), behavior: "smooth" });
  state.activeId = h.id;
  refreshFocus();
  setTimeout(() => {
    document.querySelectorAll(`.hl-rect[data-id="${h.id}"]`).forEach((d) => {
      d.classList.remove("flash"); void d.offsetWidth; d.classList.add("flash");
    });
  }, 350);
}

/* ============================================================
   Eventos
   ============================================================ */
function rebuildSwatches() {
  buildSwatches(els.selSwatches, { onPick: (id) => { setColor(id); highlightSelection(id); } });
  buildSwatches(els.menuSwatches, {
    onPick: (id) => {
      const h = state.highlights.find((x) => x.id === state.activeId);
      if (h) { updateHighlight(h.id, { color: id }); state.activeId = h.id; refreshFocus();
        els.menuSwatches.querySelectorAll(".swatch").forEach((b) => b.classList.toggle("active", b.dataset.color === id)); }
    },
  });
  renderList();
}

function showSidebar() {
  if (document.body.classList.contains("side-hidden")) {
    document.body.classList.remove("side-hidden");
    savePrefs();
    if (state.fit) setTimeout(onResize, 0);
  }
}

function bindEvents() {
  buildThemes();
  rebuildSwatches();
  els.findInput.nextElementSibling.textContent = /Mac|iPhone|iPad/.test(navigator.platform) ? "⌘F" : "Ctrl F";

  document.querySelectorAll("button[data-style]").forEach((b) =>
    b.addEventListener("click", () => {
      state.style = b.dataset.style; syncPalette(); savePrefs();
      const h = state.highlights.find((x) => x.id === state.activeId);
      if (h && !els.hlMenu.hidden) updateHighlight(h.id, { style: state.style });
    })
  );
  document.querySelectorAll("button[data-mode]").forEach((b) =>
    b.addEventListener("click", (e) => setMode(b.dataset.mode, e))
  );
  // «Automático» cambia de papel con la hora: se revisa cada minuto
  setInterval(() => {
    if (state.mode === "auto" && modeByHour() !== document.documentElement.dataset.mode)
      transitionMode(() => { applyMode(); syncPalette(); refreshMarks(); }, "auto", { currentTarget: els.modeBtn });
  }, 60000);

  // controles con nombre: al pulsarlos se invierten un momento
  document.addEventListener("pointerdown", (e) => {
    const b = e.target.closest?.(".topbar .ctl, .topbar .segbox button, .topbar-mini .ctl, .strip .ctl, .export .ctl, .cp-foot .ctl, .float-bar .fb, .float-swatches .swatch");
    if (!b || b.disabled) return;
    clearTimeout(b._press);
    b.classList.add("press");
    b._press = setTimeout(() => b.classList.remove("press"), b.closest(".float-bar") ? 350 : 1450);
  }, true);
  els.invertDark.addEventListener("change", () => {
    state.invertDark = els.invertDark.checked;
    savePrefs();
    refreshMarks();
  });

  // colores, barra principal
  els.themeBtn.addEventListener("click", () => togglePop(els.themeBtn, els.themePop));
  els.modeBtn.addEventListener("click", () => togglePop(els.modeBtn, els.modePop));
  document.addEventListener("mousedown", (e) => {
    if (anyPopOpen() && !e.target.closest(".pop, #themeBtn, #modeBtn")) closeThemePop();
  });
  $("barHide").onclick = () => { closeThemePop(); setBarHidden(true); };
  $("barShow").onclick = () => setBarHidden(false);
  els.modeQuick.onclick = (e) => setMode(document.documentElement.dataset.mode === "dark" ? "light" : "dark", e);

  $("zoomIn").onclick = () => zoomStep(1);
  $("zoomOut").onclick = () => zoomStep(-1);
  els.zoomLabel.onclick = () => state.pages[0] && setScale(fitScale(state.pages[0].w), true);
  $("fileInput").addEventListener("change", (e) => openFile(e.target.files[0]));
  $("sidebarToggle").onclick = () => { document.body.classList.toggle("side-hidden"); savePrefs(); if (state.fit) setTimeout(onResize, 0); };
  $("exportAll").onclick = exportAll;
  $("copyAllText").onclick = () => {
    const list = sortedHighlights().filter((h) => !state.filter || h.color === state.filter);
    if (!list.length) return toast("No hay marcas todavía");
    copyText(list.map((h) => `• ${h.text} (p. ${h.parts[0].page})${h.note ? `\n  Nota: ${h.note}` : ""}`).join("\n\n"));
  };

  // pestañas del panel
  document.querySelectorAll(".side-tabs button").forEach((b) => b.addEventListener("click", () => setSideTab(b.dataset.tab)));
  els.tocExpand.addEventListener("click", () => {
    const expand = els.tocExpand.textContent === "Expandir todo";
    els.toc.querySelectorAll(".toc-kids").forEach((u) => (u.hidden = !expand));
    els.toc.querySelectorAll(".toc-caret:not(.blank)").forEach((c) => { c.classList.toggle("open", expand); c.setAttribute("aria-expanded", expand); });
    els.tocExpand.textContent = expand ? "Contraer todo" : "Expandir todo";
  });
  els.tocRegen.addEventListener("click", () => state.pdf && loadOutline(state.pdf, { regenerate: true }));

  // navegación de páginas
  els.pagePrev.onclick = () => goToPage(state.curPage - 1);
  els.pageNext.onclick = () => goToPage(state.curPage + 1);
  els.navBack.onclick = goBack;
  els.pageInput.addEventListener("focus", () => els.pageInput.select());
  els.pageInput.addEventListener("input", () => { els.pageInput.value = els.pageInput.value.replace(/\D/g, "").slice(0, 6); });
  els.pageInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      const n = parseInt(els.pageInput.value, 10);
      if (n && state.pages.length) {
        const t = clamp(n, 1, state.pages.length);
        if (t !== state.curPage) navigateTo({ page: t, frac: 0 });
        if (n !== t) toast(`El documento tiene ${state.pages.length} páginas`);
      }
      els.pageInput.blur();
    } else if (e.key === "Escape") {
      e.stopPropagation();
      els.pageInput.blur();
    }
  });
  els.pageInput.addEventListener("blur", () => { els.pageInput.value = state.pdf ? state.curPage : "–"; });

  // buscar
  let findDirty = false;
  $("findClose").onclick = closeFind;
  $("findNext").onclick = () => stepMatch(1);
  $("findPrev").onclick = () => stepMatch(-1);
  // se estira al entrar y vuelve a su tamaño al salir (las flechas de dentro no cuentan como salir)
  els.findBar.addEventListener("focusin", expandFind);
  els.findBar.addEventListener("focusout", (e) => { if (!els.findBar.contains(e.relatedTarget)) collapseFind(); });
  els.findBar.addEventListener("mousedown", (e) => { if (!e.target.closest("button, input")) { e.preventDefault(); els.findInput.focus(); } });
  els.findInput.addEventListener("input", () => {
    findDirty = true;
    clearTimeout(findTimer);
    seekGlitch();
    updateFindCount();
    findTimer = setTimeout(() => { findDirty = false; runSearch(els.findInput.value); }, 220);
  });
  els.findInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      if (!state.pdf) return toast("Abre un PDF para buscar");
      if (findDirty) { clearTimeout(findTimer); findDirty = false; runSearch(els.findInput.value); }
      else stepMatch(e.shiftKey ? -1 : 1);
    } else if (e.key === "Escape") {
      e.stopPropagation();
      closeFind();
    }
  });

  // descarga e impresión
  $("downloadBtn").onclick = downloadPdf;
  els.printBtn.onclick = printDocument;
  els.printHl.addEventListener("change", () => { state.printHl = els.printHl.checked; savePrefs(); });
  window.addEventListener("afterprint", () => setTimeout(clearPrint, 0));

  // selección
  $("selCapture").addEventListener("mousedown", (e) => e.preventDefault());
  $("selCapture").onclick = () => { const h = highlightSelection(); if (h) openShot(h); };
  $("selCopy").addEventListener("mousedown", (e) => e.preventDefault());
  $("selCopy").onclick = () => { copyText(cleanText(getSelection().toString())); };
  $("selNote").addEventListener("mousedown", (e) => e.preventDefault());
  $("selNote").onclick = () => { const h = highlightSelection(); if (h) openComposer(h); };

  // tarjeta de nota
  els.cpText.addEventListener("input", updateCpLen);
  els.cpText.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { e.stopPropagation(); closeComposer(); }
    else if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); e.stopPropagation(); closeComposer(true); }
  });
  $("cpCancel").onclick = () => closeComposer();
  $("cpSave").onclick = () => closeComposer(true);

  els.hlMenu.addEventListener("click", (e) => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    const h = state.highlights.find((x) => x.id === state.activeId);
    if (!act || !h) return;
    if (act === "capture") captureHighlight(h).then(toBlob).then((b) => { download(b, shotName(h)); toast("Captura descargada ✓"); });
    if (act === "copyimg") copyImage(captureHighlight(h).then(toBlob));
    if (act === "copytext") copyText(h.text);
    if (act === "note") openComposer(h);
    if (act === "delete") deleteHighlight(h.id);
  });

  // modal
  $("shotClose").onclick = closeShot;
  els.modal.addEventListener("click", (e) => { if (e.target === els.modal) closeShot(); });
  $("shotCopy").onclick = () => modalBlob && copyImage(Promise.resolve(modalBlob));
  $("shotDownload").onclick = () => {
    if (!modalBlob) return;
    download(modalBlob, modalName);
    toast(modalKind === "all" ? "Hoja de marcas descargada ✓" : "Captura descargada ✓");
  };

  // mouse sobre las páginas
  let down = null;
  els.pages.addEventListener("mousedown", (e) => {
    if (e.button !== 0) return;
    down = { x: e.clientX, y: e.clientY };
    if (e.target.closest(".pdf-link")) return;
    e.target.closest(".page")?.querySelector(".textLayer")?.classList.add("selecting");
    if (!e.target.closest(".float-bar")) { els.selBar.hidden = true; }
  });
  document.addEventListener("mouseup", (e) => {
    document.querySelectorAll(".textLayer.selecting").forEach((t) => t.classList.remove("selecting"));
    if (!down) return;
    const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y) > 4;
    down = null;
    if (!moved && e.target.closest?.(".pdf-link")) return; // clic en un enlace del PDF
    setTimeout(() => {
      const range = currentRange();
      if (range) {
        if (state.markerMode) highlightSelection();
        else showSelectionBar(range);
        return;
      }
      if (!moved) {
        const h = hitTest(e.clientX, e.clientY);
        if (h) showHighlightMenu(h, e.clientX, e.clientY);
        else hideBars();
      }
    }, 0);
  });

  // cursor de mano sobre las marcas
  let raf = 0;
  els.pages.addEventListener("mousemove", (e) => {
    if (raf || e.buttons) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      els.pages.classList.toggle("over-hl", !!hitTest(e.clientX, e.clientY));
    });
  });

  els.viewer.addEventListener("scroll", () => {
    els.selBar.hidden = true; els.hlMenu.hidden = true;
    updatePageIndicator();
    if (comp.id) placeComposer();
  }, { passive: true });

  // Ctrl + rueda = zoom del PDF
  els.viewer.addEventListener("wheel", (e) => {
    if (!e.ctrlKey || !state.pdf) return;
    e.preventDefault();
    setScale(state.scale * (e.deltaY < 0 ? 1.1 : 1 / 1.1));
  }, { passive: false });

  // teclado
  document.addEventListener("keydown", (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === "p") { e.preventDefault(); printDocument(); return; }
    if (mod && e.key.toLowerCase() === "s") { e.preventDefault(); downloadPdf(); return; }
    if (mod && e.key.toLowerCase() === "f") { e.preventDefault(); openFind(); return; }
    if ((e.key === "F3" || mod && e.key.toLowerCase() === "g") && find.matches.length) {
      e.preventDefault(); stepMatch(e.shiftKey ? -1 : 1); return;
    }
    if (e.key === "Escape" && anyPopOpen()) {
      const btn = els.modePop.hidden ? els.themeBtn : els.modeBtn;
      closeThemePop(); btn.focus(); return;
    }
    if (e.target.closest?.("input, textarea")) return;
    if (e.key === "Escape") { closeShot(); closeComposer(); hideBars(); getSelection().removeAllRanges(); return; }
    if (e.altKey && e.key === "ArrowLeft") { e.preventDefault(); goBack(); return; }
    if (mod && e.key.toLowerCase() === "z") { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
    if (mod && e.key.toLowerCase() === "y") { e.preventDefault(); redo(); return; }
    if (mod && e.key.toLowerCase() === "o") { e.preventDefault(); $("fileInput").click(); return; }
    if (mod && (e.key === "=" || e.key === "+")) { e.preventDefault(); zoomStep(1); return; }
    if (mod && e.key === "-") { e.preventDefault(); zoomStep(-1); return; }
    if (mod && e.key === "0") { e.preventDefault(); state.pages[0] && setScale(fitScale(state.pages[0].w), true); return; }
    if (mod || e.altKey) return;
    if (!els.modal.hidden) return;
    const n = parseInt(e.key, 10);
    if (n >= 1 && n <= themeColors().length) {
      const id = themeColors()[n - 1].id;
      const active = state.highlights.find((x) => x.id === state.activeId);
      if (currentRange()) { setColor(id); highlightSelection(id); }
      else if (active && !els.hlMenu.hidden) { updateHighlight(active.id, { color: id }); state.activeId = active.id; refreshFocus(); }
      else { setColor(id); toast(`Tinta: ${colorDef(id).name}`); }
      return;
    }
    if (state.pdf && (e.key === "ArrowRight" || e.key === "ArrowLeft")) {
      // ← → cambian de página, salvo que haga falta desplazarse a los lados (zoom grande)
      if (els.viewer.scrollWidth <= els.viewer.clientWidth + 1) {
        e.preventDefault();
        goToPage(state.curPage + (e.key === "ArrowRight" ? 1 : -1));
        return;
      }
    }
    const k = e.key.toLowerCase();
    if (k === "g" && state.pdf) { e.preventDefault(); els.pageInput.focus(); return; }
    if (k === "i") {
      if (document.body.classList.contains("side-hidden") || state.sideTab !== "toc") { showSidebar(); setSideTab("toc"); }
      else setSideTab("hl");
      return;
    }
    if (k === "h" && currentRange()) { highlightSelection(); return; }
    if (k === "m") { toggleMarkerMode(); return; }
    if ((e.key === "Delete" || e.key === "Backspace") && state.activeId) { deleteHighlight(state.activeId); return; }
  });

  // arrastrar y soltar
  let dragDepth = 0;
  window.addEventListener("dragenter", (e) => { e.preventDefault(); dragDepth++; document.body.classList.add("dragging"); if (!state.pdf) els.empty.hidden = false; });
  window.addEventListener("dragleave", () => { if (--dragDepth <= 0) { dragDepth = 0; document.body.classList.remove("dragging"); } });
  window.addEventListener("dragover", (e) => e.preventDefault());
  window.addEventListener("drop", (e) => {
    e.preventDefault(); dragDepth = 0; document.body.classList.remove("dragging");
    const f = [...e.dataTransfer.files].find((f) => f.type === "application/pdf" || /\.pdf$/i.test(f.name));
    if (f) openFile(f); else toast("Suelta un archivo PDF");
  });

  // ajustes
  els.autoOpen.addEventListener("change", () => store.set("autoOpen", els.autoOpen.checked));
  els.openNative.addEventListener("click", () => {
    if (hasChrome && state.sourceUrl) chrome.runtime.sendMessage({ type: "open-native", url: state.sourceUrl });
  });

  window.addEventListener("resize", () => { closeThemePop(); onResize(); if (comp.id) placeComposer(); });
}

/* Franja: página actual, porcentaje leído y posición en el mapa de marcas */
let pageRaf = 0;
function updatePageIndicator() {
  if (pageRaf) return;
  pageRaf = requestAnimationFrame(() => {
    pageRaf = 0;
    const has = !!state.pdf && state.pages.length > 0;
    els.pagePrev.disabled = els.pageNext.disabled = !has;
    if (!has) { els.readPct.textContent = "Sin documento"; return; }
    const mid = els.viewer.scrollTop + els.viewer.clientHeight * 0.4;
    const atEnd = els.viewer.scrollTop + els.viewer.clientHeight >= els.viewer.scrollHeight - 2;
    const pv = atEnd
      ? state.pages[state.pages.length - 1]
      : state.pages.find((p) => p.div.offsetTop + p.div.offsetHeight + 14 > mid) || state.pages[state.pages.length - 1];
    state.curPage = pv.num;
    if (document.activeElement !== els.pageInput) els.pageInput.value = pv.num;
    els.pagePrev.disabled = pv.num <= 1;
    els.pageNext.disabled = pv.num >= state.pages.length;
    const max = els.viewer.scrollHeight - els.viewer.clientHeight;
    els.readPct.textContent = `${max > 0 ? Math.round(els.viewer.scrollTop / max * 100) : 100} % leído`;
    moveMapCursor();
    updateTocHere();
  });
}

let resizeTimer;
function onResize() {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    if (state.fit && state.pages[0]) setScale(fitScale(state.pages[0].w), true);
  }, 150);
}

/* ============================================================
   Inicio
   ============================================================ */
(async function init() {
  await loadPrefs();
  bindEvents();
  syncPalette();
  setSideTab(state.sideTab, false);
  renderList();
  renderToc();
  updatePageIndicator();
  const file = new URLSearchParams(location.search).get("file");
  if (file) openFromUrl(file);
})();

// para pruebas
window.__subrayador = { state, highlightSelection, captureHighlight, exportAll, openDocument, goToPage, navigateTo, printDocument, resolveDest };
