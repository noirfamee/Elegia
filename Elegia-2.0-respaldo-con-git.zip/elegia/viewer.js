import * as pdfjsLib from "./lib/pdf.min.mjs";

pdfjsLib.GlobalWorkerOptions.workerSrc = "./lib/pdf.worker.min.mjs";
const hasChrome = typeof chrome !== "undefined" && !!chrome.storage;

/* ============================================================
   Configuración
   ============================================================ */
/* Tres temas, cada uno con su paleta de 3 colores.
   alpha = opacidad del rotulador (los oscuros se aclaran para no tapar el texto)
   edge  = borde fino para colores muy claros sobre la página blanca
   ui    = versión visible del color sobre la interfaz oscura
   accent / link = color de acento de la interfaz por tema: [claro, oscuro]  */
const THEMES = [
  { id: "neworder", name: "New Order", sub: "Movement · 1981", def: 1,
    accent: ["#657A83", "#657A83"], link: ["#657A83", "#a9bcc4"],
    colors: [
      { id: "no-paper", name: "Aged paper", hex: "#D9D4C8", alpha: 1,   edge: "rgba(70,58,30,.42)" },
      { id: "no-steel", name: "Steel blue", hex: "#657A83", alpha: 0.85 },
      { id: "no-char",  name: "Charcoal",   hex: "#292C30", alpha: 0.52, ui: "#8b939b" },
    ] },
  { id: "francia", name: "Francia", sub: "Parisian Modernism", def: 2,
    accent: ["#172B55", "#C93648"], link: ["#172B55", "#9fb2dc"],
    colors: [
      { id: "fr-navy",  name: "Azul marino",  hex: "#172B55", alpha: 0.52, ui: "#4f76c9" },
      { id: "fr-ivory", name: "Marfil",       hex: "#F5F0E8", alpha: 1,   edge: "rgba(110,85,40,.45)" },
      { id: "fr-red",   name: "Rojo burdeos", hex: "#C93648", alpha: 0.88 },
    ] },
  { id: "rosa", name: "Rosa mexicano", sub: "nueva propuesta", def: 0,
    accent: ["#7D174D", "#E4007C"], link: ["#7D174D", "#f07ab4"],
    colors: [
      { id: "rm-rosa",   name: "Rosa mexicano", hex: "#E4007C", alpha: 1 },
      { id: "rm-chicle", name: "Rosa chicle",   hex: "#F5A6C8", alpha: 1 },
      { id: "rm-bugam",  name: "Bugambilia",    hex: "#7D174D", alpha: 0.55, ui: "#c2417f" },
    ] },
];
// subrayados hechos con la primera versión (siguen viéndose igual)
const LEGACY = [
  { id: "yellow", name: "Amarillo", hex: "#FFE500" }, { id: "pink", name: "Rosa", hex: "#FF3EA5" },
  { id: "green", name: "Verde", hex: "#00E676" },    { id: "blue", name: "Cian", hex: "#00C8FF" },
  { id: "orange", name: "Naranja", hex: "#FF8A00" }, { id: "purple", name: "Morado", hex: "#B45CFF" },
];
const ALL_COLORS = [...THEMES.flatMap((t) => t.colors), ...LEGACY];
const colorDef = (id) => ALL_COLORS.find((c) => c.id === id) || THEMES[0].colors[1];
const colorHex = (id) => colorDef(id).hex;
const curTheme = () => THEMES.find((t) => t.id === state.theme) || THEMES[0];
const themeColors = () => curTheme().colors;
const ZOOMS = [0.5, 0.67, 0.75, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4];
const CAPTURE_WIDTH = 2400; // px del ancho de página al capturar (nitidez)

/* ============================================================
   Estado
   ============================================================ */
const state = {
  pdf: null,
  docKey: null,
  docName: "",
  sourceUrl: null,
  scale: 1,
  fit: true,
  pages: [],
  highlights: [],
  theme: "neworder",
  mode: "light",
  color: "no-steel",
  style: "marker",
  markerMode: false,
  filter: null,
  activeId: null,
  undo: [],
  redo: [],
};

const $ = (id) => document.getElementById(id);
const els = {
  viewer: $("viewer"), pages: $("pages"), empty: $("empty"), docTitle: $("docTitle"),
  palette: $("palette"), themes: $("themes"), selBar: $("selBar"), selSwatches: $("selSwatches"),
  hlMenu: $("hlMenu"), menuSwatches: $("menuSwatches"), hlList: $("hlList"),
  hlCount: $("hlCount"), filters: $("filters"), zoomLabel: $("zoomLabel"),
  toast: $("toast"), modal: $("shotModal"), shotImg: $("shotImg"),
  shotMeta: $("shotMeta"), shotFilters: $("shotFilters"), shotNote: $("shotNote"),
  markerMode: $("markerMode"), autoOpen: $("autoOpen"), openNative: $("openNative"),
  pageIndicator: $("pageIndicator"),
};

/* ============================================================
   Utilidades
   ============================================================ */
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
let toastTimer;
function toast(msg) {
  els.toast.textContent = msg;
  els.toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (els.toast.hidden = true), 1800);
}
const cleanText = (s) =>
  s.replace(/[­]/g, "")
   .replace(/(\p{L})-\s*\n\s*(?=\p{Ll})/gu, "$1")
   .replace(/\s+/g, " ")
   .trim();
const safeName = (s) => (s || "documento").replace(/\.pdf$/i, "").replace(/[^\p{L}\p{N}_-]+/gu, "_").slice(0, 60);

/** Rectángulo de dibujo (un poco más amplio que el glifo para que se vea "rotulado") */
function drawBox([x, y, w, h], pageAspect) {
  // h y w están normalizados; padX en función de la altura real
  const padY = h * 0.05;
  const padX = h * 0.12 * pageAspect; // compensa que x se normaliza por el ancho
  return [x - padX, y - padY, w + padX * 2, h + padY * 2];
}

/* ============================================================
   Preferencias y almacenamiento
   ============================================================ */
const store = {
  async get(key, def) {
    if (!hasChrome) { try { return JSON.parse(localStorage.getItem(key)) ?? def; } catch { return def; } }
    const r = await chrome.storage.local.get(key);
    return r[key] ?? def;
  },
  async set(key, val) {
    if (!hasChrome) { localStorage.setItem(key, JSON.stringify(val)); return; }
    await chrome.storage.local.set({ [key]: val });
  },
};

async function loadPrefs() {
  const p = await store.get("prefs", {});
  state.theme = THEMES.some((t) => t.id === p.theme) ? p.theme : "neworder";
  const th = curTheme();
  state.color = th.colors.some((c) => c.id === p.color) ? p.color : th.colors[th.def].id;
  state.style = p.style || "marker";
  state.markerMode = !!p.markerMode;
  state.mode = p.mode === "dark" || p.mode === "light"
    ? p.mode
    : (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  document.documentElement.dataset.mode = state.mode;
  if (p.sideHidden) document.body.classList.add("side-hidden");
  els.autoOpen.checked = await store.get("autoOpen", true);
}
function savePrefs() {
  store.set("prefs", {
    theme: state.theme, mode: state.mode, color: state.color, style: state.style, markerMode: state.markerMode,
    sideHidden: document.body.classList.contains("side-hidden"),
  });
}
let saveTimer;
function saveHighlights() {
  if (!state.docKey) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    store.set(state.docKey, { name: state.docName, url: state.sourceUrl, updated: Date.now(), highlights: state.highlights });
  }, 250);
}

/* ============================================================
   UI: paletas
   ============================================================ */
/** Variables de color para un elemento: tinta, versión para modo oscuro y contornos */
function colorVars(el, def) {
  el.style.setProperty("--c", def.hex);
  el.style.setProperty("--cd", def.ui || def.hex);
  if (def.edge) el.style.setProperty("--ring-l", "0 0 0 1px #b9b1a2");
  if (def.ui) el.style.setProperty("--ring-d", "0 0 0 1px #8a8d92");
}

function buildSwatches(container, { onPick, withKeys = false, floating = false }) {
  container.innerHTML = "";
  themeColors().forEach((c, i) => {
    const b = document.createElement("button");
    b.className = "swatch";
    colorVars(b, c);
    b.title = `${c.name} (${i + 1})`;
    b.dataset.color = c.id;
    b.setAttribute("role", "radio");
    if (floating) b.innerHTML = `<span class="dot"></span><kbd>${i + 1}</kbd>`;
    else if (withKeys) b.innerHTML = `<kbd>${i + 1}</kbd>`;
    b.addEventListener("mousedown", (e) => e.preventDefault()); // no perder la selección
    b.addEventListener("click", () => onPick(c.id));
    container.appendChild(b);
  });
}
function syncPalette() {
  els.palette.querySelectorAll(".swatch").forEach((b) => {
    const on = b.dataset.color === state.color;
    b.classList.toggle("active", on);
    b.setAttribute("aria-checked", on);
  });
  document.querySelectorAll(".seg-btn[data-style]").forEach((b) => b.classList.toggle("active", b.dataset.style === state.style));
  document.querySelectorAll(".seg-btn[data-mode]").forEach((b) => b.classList.toggle("active", b.dataset.mode === state.mode));
  els.markerMode.classList.toggle("on", state.markerMode);
  els.markerMode.setAttribute("aria-pressed", state.markerMode);
  applyThemeVars();
}
function applyThemeVars() {
  const th = curTheme(), root = document.documentElement.style, k = state.mode === "dark" ? 1 : 0;
  document.documentElement.dataset.mode = state.mode;
  root.setProperty("--accent", th.accent[k]);
  root.setProperty("--link", th.link[k]);
  th.colors.forEach((c, i) => root.setProperty(`--t${i + 1}`, c.hex));
  els.themes.querySelectorAll(".theme-btn").forEach((b) => b.classList.toggle("active", b.dataset.theme === state.theme));
}
function buildThemes() {
  els.themes.innerHTML = "";
  THEMES.forEach((t) => {
    const b = document.createElement("button");
    b.className = "seg-btn theme-btn";
    b.dataset.theme = t.id;
    b.title = `${t.name} — ${t.sub}`;
    b.setAttribute("aria-label", `Tema ${t.name}`);
    const dots = document.createElement("span");
    dots.className = "dots";
    t.colors.forEach((c) => { const i = document.createElement("i"); colorVars(i, c); dots.appendChild(i); });
    const name = document.createElement("span");
    name.className = "name";
    name.textContent = t.name;
    b.append(dots, name);
    b.addEventListener("click", () => setTheme(t.id));
    els.themes.appendChild(b);
  });
}
function setMode(mode) {
  if (mode === state.mode) return;
  state.mode = mode;
  syncPalette();
  savePrefs();
}
function setTheme(id) {
  if (id === state.theme) return;
  const slot = Math.max(0, themeColors().findIndex((c) => c.id === state.color));
  state.theme = id;
  state.color = curTheme().colors[slot].id;
  rebuildSwatches();
  syncPalette();
  savePrefs();
  toast(`Tema: ${curTheme().name}`);
}
function setColor(id) { state.color = id; syncPalette(); savePrefs(); }

/* ============================================================
   Carga del documento
   ============================================================ */
async function openFromUrl(url) {
  state.sourceUrl = url;
  els.openNative.hidden = !/^(https?|file):/i.test(url);
  showMessage("Cargando PDF…");
  try {
    const res = await fetch(url, { credentials: "include" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = await res.arrayBuffer();
    const head = new TextDecoder().decode(new Uint8Array(buf.slice(0, 1024)));
    if (!head.includes("%PDF")) throw new Error("NOT_PDF");
    let name = "";
    const cd = res.headers.get("content-disposition") || "";
    const m = cd.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i);
    if (m) name = decodeURIComponent(m[1]);
    if (!name) {
      try { name = decodeURIComponent(new URL(url).pathname.split("/").pop() || ""); } catch {}
    }
    await openDocument(new Uint8Array(buf), name || "documento.pdf");
  } catch (err) {
    console.error(err);
    if (String(err.message) === "NOT_PDF") {
      showMessage("Esta página no es un PDF.", "Abre un PDF o arrástralo aquí.");
    } else if (url.startsWith("file:")) {
      showMessage(
        "No tengo permiso para leer archivos locales.",
        "Ve a chrome://extensions → Elegia → Detalles y activa «Permitir el acceso a las URL de archivo». O arrastra el PDF aquí."
      );
    } else {
      showMessage("No se pudo cargar el PDF.", `${err.message}. Puedes descargarlo y arrastrarlo aquí.`);
    }
  }
}

async function openFile(file) {
  if (!file) return;
  state.sourceUrl = null;
  els.openNative.hidden = true;
  showMessage("Cargando PDF…");
  const buf = new Uint8Array(await file.arrayBuffer());
  await openDocument(buf, file.name);
}

function showMessage(title, sub = "") {
  els.pages.innerHTML = "";
  els.empty.hidden = false;
  els.empty.querySelector("h1").textContent = title;
  els.empty.querySelector("p").textContent = sub;
}

async function openDocument(data, name) {
  if (state.pdf) { state.pdf.destroy(); state.pdf = null; }
  hiResCache.clear();
  let pdf;
  try {
    pdf = await pdfjsLib.getDocument({
      data,
      cMapUrl: "./lib/cmaps/",
      cMapPacked: true,
      standardFontDataUrl: "./lib/standard_fonts/",
      isEvalSupported: false,
    }).promise;
  } catch (e) {
    showMessage("No se pudo abrir el PDF.", e?.message || "");
    return;
  }
  state.pdf = pdf;
  state.docName = name;
  state.docKey = "doc:" + (pdf.fingerprints?.[0] || name);
  state.highlights = (await store.get(state.docKey, {}))?.highlights || [];
  state.undo = []; state.redo = []; state.activeId = null; state.filter = null;
  els.docTitle.textContent = name;
  document.title = `${name} · Elegia`;
  els.empty.hidden = true;
  await buildPages();
  renderList();
  updatePageIndicator();
}

/* ============================================================
   Páginas
   ============================================================ */
let observer;
async function buildPages() {
  const pdf = state.pdf;
  els.pages.innerHTML = "";
  state.pages = [];
  observer?.disconnect();
  observer = new IntersectionObserver(onIntersect, { root: els.viewer, rootMargin: "800px 0px" });

  const first = await pdf.getPage(1);
  const baseVp = first.getViewport({ scale: 1 });
  if (state.fit) state.scale = fitScale(baseVp.width);

  // dimensiones de todas las páginas (en lotes para PDFs grandes)
  const dims = new Array(pdf.numPages);
  const batch = 24;
  for (let i = 0; i < pdf.numPages; i += batch) {
    const nums = [];
    for (let n = i + 1; n <= Math.min(pdf.numPages, i + batch); n++) nums.push(n);
    const pages = await Promise.all(nums.map((n) => pdf.getPage(n)));
    pages.forEach((p, k) => {
      const vp = p.getViewport({ scale: 1 });
      dims[nums[k] - 1] = { w: vp.width, h: vp.height };
    });
  }

  const frag = document.createDocumentFragment();
  dims.forEach((d, i) => {
    const div = document.createElement("div");
    div.className = "page loading";
    div.dataset.page = i + 1;
    const hl = document.createElement("div");
    hl.className = "hl-layer";
    const num = document.createElement("div");
    num.className = "page-num";
    num.textContent = `${i + 1} / ${pdf.numPages}`;
    div.append(hl, num);
    const pv = { num: i + 1, w: d.w, h: d.h, div, hlLayer: hl, canvas: null, textLayer: null, renderedScale: 0, task: null, visible: false };
    state.pages.push(pv);
    sizePage(pv);
    frag.appendChild(div);
    observer.observe(div);
  });
  els.pages.appendChild(frag);
  state.pages.forEach(drawPageHighlights);
  updateZoomLabel();
}

function fitScale(pageW) {
  const avail = els.viewer.clientWidth - 48;
  return clamp(avail / pageW, 0.4, 2.2);
}
function sizePage(pv) {
  pv.div.style.width = `${Math.floor(pv.w * state.scale)}px`;
  pv.div.style.height = `${Math.floor(pv.h * state.scale)}px`;
  pv.div.style.setProperty("--scale-factor", state.scale);
}

function onIntersect(entries) {
  for (const e of entries) {
    const pv = state.pages[+e.target.dataset.page - 1];
    if (!pv) continue;
    pv.visible = e.isIntersecting;
    if (pv.visible && pv.renderedScale !== state.scale) renderPage(pv);
  }
}

async function renderPage(pv) {
  const scale = state.scale;
  if (pv.task) { try { pv.task.cancel(); } catch {} }
  const page = await state.pdf.getPage(pv.num);
  const vp = page.getViewport({ scale });
  const dpr = Math.min(window.devicePixelRatio || 1, 3);
  const canvas = document.createElement("canvas");
  canvas.width = Math.floor(vp.width * dpr);
  canvas.height = Math.floor(vp.height * dpr);
  const task = page.render({
    canvasContext: canvas.getContext("2d", { alpha: false }),
    viewport: vp,
    transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : null,
  });
  pv.task = task;
  try { await task.promise; } catch (e) { if (e?.name === "RenderingCancelledException") return; throw e; }
  if (scale !== state.scale) return;
  pv.task = null;

  // texto seleccionable
  const tl = document.createElement("div");
  tl.className = "textLayer";
  const textLayer = new pdfjsLib.TextLayer({
    textContentSource: page.streamTextContent({ includeMarkedContent: true, disableNormalization: true }),
    container: tl,
    viewport: vp,
  });
  await textLayer.render();
  const eoc = document.createElement("div");
  eoc.className = "endOfContent";
  tl.appendChild(eoc);

  pv.canvas?.remove();
  pv.textLayer?.remove();
  pv.canvas = canvas;
  pv.textLayer = tl;
  pv.div.insertBefore(canvas, pv.hlLayer);
  pv.div.appendChild(tl);
  pv.div.classList.remove("loading");
  pv.renderedScale = scale;
}

/* ============================================================
   Zoom
   ============================================================ */
function anchor() {
  const top = els.viewer.scrollTop;
  const pv = state.pages.find((p) => p.div.offsetTop + p.div.offsetHeight > top) || state.pages[0];
  return pv ? { pv, frac: (top - pv.div.offsetTop) / pv.div.offsetHeight } : null;
}
function setScale(s, fit = false) {
  if (!state.pdf) return;
  const a = anchor();
  state.fit = fit;
  state.scale = clamp(s, 0.25, 5);
  state.pages.forEach(sizePage);
  if (a) els.viewer.scrollTop = a.pv.div.offsetTop + a.frac * a.pv.div.offsetHeight;
  state.pages.forEach((pv) => pv.visible && renderPage(pv));
  updateZoomLabel();
  hideBars();
}
function zoomStep(dir) {
  const cur = state.scale;
  const next = dir > 0 ? ZOOMS.find((z) => z > cur + 0.01) : [...ZOOMS].reverse().find((z) => z < cur - 0.01);
  if (next) setScale(next);
}
function updateZoomLabel() {
  els.zoomLabel.textContent = `${Math.round(state.scale * 100)}%`;
}

/* ============================================================
   Selección → rectángulos
   ============================================================ */
function selectionParts(range) {
  // Recorre sólo nodos de texto para obtener cajas exactas de los glifos
  const root = range.commonAncestorContainer.nodeType === 1
    ? range.commonAncestorContainer
    : range.commonAncestorContainer.parentNode;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode: (n) => (range.intersectsNode(n) && n.parentElement?.closest(".textLayer") ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
  });
  const rects = [];
  let n;
  while ((n = walker.nextNode())) {
    const r = document.createRange();
    r.selectNodeContents(n);
    if (n === range.startContainer) r.setStart(n, range.startOffset);
    if (n === range.endContainer) r.setEnd(n, range.endOffset);
    if (r.collapsed || !r.toString().trim()) continue;
    for (const cr of r.getClientRects()) if (cr.width > 0.5 && cr.height > 0.5) rects.push({ cr, page: n.parentElement.closest(".page") });
  }
  // agrupar por página y normalizar
  const byPage = new Map();
  for (const { cr, page } of rects) {
    if (!page) continue;
    const num = +page.dataset.page;
    const b = page.getBoundingClientRect();
    const list = byPage.get(num) || [];
    list.push({ x: (cr.left - b.left) / b.width, y: (cr.top - b.top) / b.height, w: cr.width / b.width, h: cr.height / b.height });
    byPage.set(num, list);
  }
  const parts = [];
  for (const [page, list] of [...byPage.entries()].sort((a, b) => a[0] - b[0])) {
    const pv = state.pages[page - 1];
    parts.push({ page, rects: mergeRects(list, pv.w / pv.h) });
  }
  return parts.filter((p) => p.rects.length);
}

function mergeRects(list, aspect) {
  list.sort((a, b) => a.y - b.y || a.x - b.x);
  const lines = [];
  for (const r of list) {
    const line = lines.find((l) => {
      const top = Math.max(l.y, r.y), bot = Math.min(l.y + l.h, r.y + r.h);
      return bot - top > 0.5 * Math.min(l.h, r.h);
    });
    if (line) { line.items.push(r); line.y = Math.min(line.y, r.y); line.h = Math.max(line.y + line.h, r.y + r.h) - line.y; }
    else lines.push({ y: r.y, h: r.h, items: [r] });
  }
  const out = [];
  for (const l of lines) {
    l.items.sort((a, b) => a.x - b.x);
    let cur = null;
    for (const r of l.items) {
      const gap = r.h * 1.2 / aspect; // tolerancia horizontal en unidades de ancho
      if (cur && r.x <= cur.x + cur.w + gap) {
        const right = Math.max(cur.x + cur.w, r.x + r.w);
        const top = Math.min(cur.y, r.y), bot = Math.max(cur.y + cur.h, r.y + r.h);
        cur.x = Math.min(cur.x, r.x); cur.w = right - cur.x; cur.y = top; cur.h = bot - top;
      } else {
        if (cur) out.push(cur);
        cur = { ...r };
      }
    }
    if (cur) out.push(cur);
  }
  return out.map((r) => [r.x, r.y, r.w, r.h].map((v) => +v.toFixed(5)));
}

function currentRange() {
  const sel = getSelection();
  if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
  const range = sel.getRangeAt(0);
  if (!els.pages.contains(range.commonAncestorContainer)) return null;
  if (!sel.toString().trim()) return null;
  return range;
}

/* ============================================================
   Subrayados: crear, editar, borrar
   ============================================================ */
function snapshot() {
  state.undo.push(JSON.stringify(state.highlights));
  if (state.undo.length > 80) state.undo.shift();
  state.redo = [];
}
function commit() {
  saveHighlights();
  state.pages.forEach(drawPageHighlights);
  renderList();
}

function highlightSelection(color = state.color) {
  const range = currentRange();
  if (!range) return null;
  const parts = selectionParts(range);
  if (!parts.length) return null;
  const text = cleanText(getSelection().toString());
  snapshot();
  const h = { id: uid(), color, style: state.style, text, created: Date.now(), parts };
  state.highlights.push(h);
  getSelection().removeAllRanges();
  hideBars();
  commit();
  return h;
}

function updateHighlight(id, patch) {
  const h = state.highlights.find((x) => x.id === id);
  if (!h) return;
  snapshot();
  Object.assign(h, patch);
  commit();
}
function deleteHighlight(id) {
  const i = state.highlights.findIndex((x) => x.id === id);
  if (i < 0) return;
  snapshot();
  state.highlights.splice(i, 1);
  if (state.activeId === id) state.activeId = null;
  hideBars();
  commit();
  toast("Subrayado borrado · Ctrl+Z para deshacer");
}
function undo() {
  if (!state.undo.length) return;
  state.redo.push(JSON.stringify(state.highlights));
  state.highlights = JSON.parse(state.undo.pop());
  hideBars(); commit();
}
function redo() {
  if (!state.redo.length) return;
  state.undo.push(JSON.stringify(state.highlights));
  state.highlights = JSON.parse(state.redo.pop());
  hideBars(); commit();
}

function drawPageHighlights(pv) {
  const layer = pv.hlLayer;
  layer.innerHTML = "";
  const aspect = pv.h / pv.w;
  for (const h of state.highlights) {
    for (const part of h.parts) {
      if (part.page !== pv.num) continue;
      for (const r of part.rects) {
        const [x, y, w, hh] = drawBox(r, aspect);
        const d = document.createElement("div");
        d.className = "hl-rect" + (h.style === "underline" ? " underline" : "") + (h.id === state.activeId ? " focus" : "");
        d.dataset.id = h.id;
        const def = colorDef(h.color);
        d.style.setProperty("--c", def.hex);
        d.style.setProperty("--cd", def.ui || def.hex);
        if (def.ui) d.style.setProperty("--edge-d", "rgba(236,231,221,.55)");
        d.style.setProperty("--a", h.style === "underline" ? 1 : def.alpha ?? 1);
        if (def.edge) d.style.setProperty("--edge", def.edge);
        d.style.left = `${x * 100}%`; d.style.top = `${y * 100}%`;
        d.style.width = `${w * 100}%`; d.style.height = `${hh * 100}%`;
        layer.appendChild(d);
      }
    }
  }
}

function hitTest(clientX, clientY) {
  const pageEl = document.elementsFromPoint(clientX, clientY).find((e) => e.classList?.contains("page"));
  if (!pageEl) return null;
  const b = pageEl.getBoundingClientRect();
  const px = (clientX - b.left) / b.width, py = (clientY - b.top) / b.height;
  const num = +pageEl.dataset.page;
  const pv = state.pages[num - 1];
  for (let i = state.highlights.length - 1; i >= 0; i--) {
    const h = state.highlights[i];
    for (const part of h.parts) {
      if (part.page !== num) continue;
      for (const r of part.rects) {
        const [x, y, w, hh] = drawBox(r, pv.h / pv.w);
        if (px >= x && px <= x + w && py >= y && py <= y + hh) return h;
      }
    }
  }
  return null;
}

/* ============================================================
   Barras flotantes
   ============================================================ */
function placeBar(bar, x, y) {
  bar.hidden = false;
  const bw = bar.offsetWidth, bh = bar.offsetHeight;
  let left = clamp(x - bw / 2, 8, innerWidth - bw - 8);
  let top = y - bh - 12;
  if (top < 64) top = y + 18;
  bar.style.left = `${left}px`;
  bar.style.top = `${top}px`;
}
function hideBars() {
  els.selBar.hidden = true;
  els.hlMenu.hidden = true;
  if (state.activeId) { state.activeId = null; refreshFocus(); }
}
function refreshFocus() {
  document.querySelectorAll(".hl-rect").forEach((d) => d.classList.toggle("focus", d.dataset.id === state.activeId));
  document.querySelectorAll(".hl-item").forEach((d) => d.classList.toggle("active", d.dataset.id === state.activeId));
}
function showSelectionBar(range) {
  const rects = range.getClientRects();
  const last = rects[rects.length - 1] || range.getBoundingClientRect();
  const first = rects[0] || last;
  els.hlMenu.hidden = true;
  placeBar(els.selBar, (first.left + last.right) / 2, first.top);
}
function showHighlightMenu(h, x, y) {
  els.selBar.hidden = true;
  state.activeId = h.id;
  refreshFocus();
  els.menuSwatches.querySelectorAll(".swatch").forEach((b) => b.classList.toggle("active", b.dataset.color === h.color));
  placeBar(els.hlMenu, x, y);
  els.hlList.querySelector(`[data-id="${h.id}"]`)?.scrollIntoView({ block: "nearest", behavior: "smooth" });
}

/* ============================================================
   Capturas
   ============================================================ */
const hiResCache = new Map();
async function hiResPage(num) {
  if (hiResCache.has(num)) return hiResCache.get(num);
  const page = await state.pdf.getPage(num);
  const base = page.getViewport({ scale: 1 });
  const vp = page.getViewport({ scale: clamp(CAPTURE_WIDTH / base.width, 1, 6) });
  const c = document.createElement("canvas");
  c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
  const ctx = c.getContext("2d", { alpha: false });
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
  await page.render({ canvasContext: ctx, viewport: vp }).promise;
  hiResCache.set(num, c);
  if (hiResCache.size > 4) hiResCache.delete(hiResCache.keys().next().value);
  return c;
}

function roundRect(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

async function capturePart(h, part) {
  const pv = state.pages[part.page - 1];
  const src = await hiResPage(part.page);
  const W = src.width, H = src.height, aspect = pv.h / pv.w;
  const boxes = part.rects.map((r) => drawBox(r, aspect));
  const avgH = part.rects.reduce((s, r) => s + r[3], 0) / part.rects.length * H;
  let x0 = Math.min(...boxes.map((b) => b[0])) * W;
  let y0 = Math.min(...boxes.map((b) => b[1])) * H;
  let x1 = Math.max(...boxes.map((b) => b[0] + b[2])) * W;
  let y1 = Math.max(...boxes.map((b) => b[1] + b[3])) * H;
  const padX = avgH * 0.9, padY = avgH * 0.6;
  x0 = Math.floor(clamp(x0 - padX, 0, W)); y0 = Math.floor(clamp(y0 - padY, 0, H));
  x1 = Math.ceil(clamp(x1 + padX, 0, W));  y1 = Math.ceil(clamp(y1 + padY, 0, H));
  const cw = x1 - x0, ch = y1 - y0;

  const out = document.createElement("canvas");
  out.width = cw; out.height = ch;
  const ctx = out.getContext("2d");
  ctx.drawImage(src, x0, y0, cw, ch, 0, 0, cw, ch);
  // margen blanco limpio: tapa las líneas vecinas que quedarían cortadas a la mitad
  const firstH = Math.min(...boxes.map((b) => b[3])) * H;
  const top = Math.min(...boxes.map((b) => b[1])) * H - y0 + firstH * 0.12; // quita colas de la línea anterior
  const bottom = Math.max(...boxes.map((b) => b[1] + b[3])) * H - y0;
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, cw, Math.max(0, top));
  ctx.fillRect(0, bottom + 1, cw, ch - bottom);

  // dibuja todos los subrayados que caen dentro del recorte (como una captura real)
  ctx.globalCompositeOperation = "multiply";
  for (const other of state.highlights) {
    for (const p of other.parts) {
      if (p.page !== part.page) continue;
      const def = colorDef(other.color);
      ctx.fillStyle = def.hex;
      ctx.globalAlpha = other.style === "underline" ? 1 : def.alpha ?? 1;
      for (const r of p.rects) {
        const [bx, by, bw, bh] = drawBox(r, aspect);
        const X = bx * W - x0, Y = by * H - y0, Wd = bw * W, Hd = bh * H;
        if (X > cw || Y > ch || X + Wd < 0 || Y + Hd < 0) continue;
        if (other.style === "underline") roundRect(ctx, X, Y + Hd * 0.76, Wd, Hd * 0.24, Hd * 0.08);
        else roundRect(ctx, X, Y, Wd, Hd, Hd * 0.14);
        ctx.fill();
        if (def.edge) { ctx.strokeStyle = def.edge; ctx.lineWidth = Math.max(2, Hd * 0.045); ctx.stroke(); }
      }
      ctx.globalAlpha = 1;
    }
  }
  ctx.globalCompositeOperation = "source-over";
  return out;
}

async function captureHighlight(h) {
  const pieces = [];
  for (const part of h.parts) pieces.push(await capturePart(h, part));
  if (pieces.length === 1) return pieces[0];
  const gap = 24;
  const w = Math.max(...pieces.map((p) => p.width));
  const c = document.createElement("canvas");
  c.width = w; c.height = pieces.reduce((s, p) => s + p.height, 0) + gap * (pieces.length - 1);
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
  let y = 0;
  for (const p of pieces) { ctx.drawImage(p, 0, y); y += p.height + gap; }
  return c;
}

const toBlob = (canvas) => new Promise((res) => canvas.toBlob(res, "image/png"));
function download(blob, filename) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
async function copyImage(blobPromise) {
  try {
    await navigator.clipboard.write([new ClipboardItem({ "image/png": blobPromise })]);
    toast("Imagen copiada ✓");
  } catch (e) {
    console.error(e);
    toast("No se pudo copiar; usa Descargar");
  }
}
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast("Texto copiado ✓"); }
  catch { toast("No se pudo copiar el texto"); }
}
const shotName = (h) => `${safeName(state.docName)}_p${h.parts[0].page}_${h.id.slice(0, 4)}.png`;

let modalBlob = null, modalName = "", modalKind = null;
function showModal({ title, meta, note = "", blob, name, kind }) {
  modalBlob = blob; modalName = name; modalKind = kind;
  if (els.shotImg.src) URL.revokeObjectURL(els.shotImg.src);
  els.shotImg.src = URL.createObjectURL(blob);
  els.modal.querySelector("h3").textContent = title;
  els.shotMeta.textContent = meta;
  els.shotNote.textContent = note;
  els.shotFilters.hidden = kind !== "all";
  els.modal.hidden = false;
}
async function openShot(h) {
  const canvas = await captureHighlight(h);
  showModal({
    title: "Captura",
    meta: `página ${h.parts.map((p) => p.page).join("–")} · ${canvas.width} px · PNG`,
    blob: await toBlob(canvas), name: shotName(h), kind: "one",
  });
}
const closeShot = () => { els.modal.hidden = true; modalKind = null; };

function positionOf(h) {
  const p = h.parts[0];
  const r = p.rects[0] || [0, 0];
  return p.page * 10 + r[1] * 9 + r[0] * 0.001;
}
const sortedHighlights = () => [...state.highlights].sort((a, b) => positionOf(a) - positionOf(b));

const SHEET_W = 1800;
const plural = (n) => `${n} subrayado${n === 1 ? "" : "s"}`;

/** Hoja con todos los subrayados (en orden de lectura, con página y barra de color) */
async function buildSheet(list) {
  const shots = [];
  for (const h of list) shots.push({ h, c: await captureHighlight(h) });
  await Promise.all([
    document.fonts.load('400 52px "Newsreader"'),
    document.fonts.load('400 24px "JetBrains Mono"'),
  ]).catch(() => {});

  const W = SHEET_W, pad = 96, gap = 52, barW = 8, labelW = 96;
  const x0 = pad + barW + 24 + labelW;           // donde empieza la imagen
  const inner = W - x0 - pad;
  const scaled = shots.map(({ h, c }) => {
    const s = Math.min(1, inner / c.width);
    return { h, c, w: Math.round(c.width * s), hgt: Math.round(c.height * s) };
  });
  const headH = 250;
  const H = headH + scaled.reduce((s, x) => s + x.hgt + gap, 0) + pad - gap;
  const out = document.createElement("canvas");
  out.width = W; out.height = H;
  const ctx = out.getContext("2d");
  ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, W, H);

  // encabezado: título en serif, fecha y conteo en mono
  const serif = '"Newsreader", Georgia, serif', mono = '"JetBrains Mono", ui-monospace, monospace';
  ctx.textBaseline = "alphabetic";
  ctx.fillStyle = "#2a2622";
  ctx.font = `400 52px ${serif}`;
  let title = state.docName.replace(/\.pdf$/i, "");
  while (title.length > 8 && ctx.measureText(title).width > W - pad * 2 - 360) title = title.slice(0, -2);
  if (title !== state.docName.replace(/\.pdf$/i, "")) title += "…";
  ctx.fillText(title, pad, pad + 40);
  ctx.fillStyle = "#a0968a";
  ctx.font = `400 22px ${mono}`;
  const date = new Date().toLocaleDateString("es-MX", { day: "numeric", month: "short", year: "numeric" });
  ctx.textAlign = "right";
  ctx.fillText(date, W - pad, pad + 40);
  ctx.textAlign = "left";
  ctx.fillText(plural(list.length), pad, pad + 86);
  ctx.fillStyle = "#ece7df";
  ctx.fillRect(pad, headH - 44, W - pad * 2, 2);

  let y = headH;
  for (const s of scaled) {
    const def = colorDef(s.h.color);
    ctx.fillStyle = def.hex;
    roundRect(ctx, pad, y, barW, s.hgt, 4); ctx.fill();
    if (def.edge) { ctx.strokeStyle = "#b9b1a2"; ctx.lineWidth = 2; ctx.stroke(); }
    ctx.fillStyle = "#a0968a";
    ctx.font = `400 22px ${mono}`;
    ctx.fillText(`p.${s.h.parts.map((p) => p.page).join("–")}`, pad + barW + 24, y + 26);
    ctx.drawImage(s.c, x0, y, s.w, s.hgt);
    y += s.hgt + gap;
  }
  return out;
}

function renderSheetFilters() {
  const counts = {};
  state.highlights.forEach((h) => (counts[h.color] = (counts[h.color] || 0) + 1));
  const used = ALL_COLORS.filter((c) => counts[c.id]);
  els.shotFilters.innerHTML = "";
  if (used.length < 2) { els.shotFilters.hidden = true; return; }
  const add = (label, id, def) => {
    const b = document.createElement("button");
    b.className = "seg-btn" + ((state.filter || null) === id ? " active" : "");
    if (def) { colorVars(b, def); b.innerHTML = `<i></i>${label}`; b.title = `Sólo ${def.name.toLowerCase()}`; }
    else b.textContent = label;
    b.onclick = () => { state.filter = id; renderList(); exportAll(); };
    els.shotFilters.appendChild(b);
  };
  add("Todos", null);
  used.forEach((c) => add(counts[c.id], c.id, c));
}

async function exportAll() {
  const list = sortedHighlights().filter((h) => !state.filter || h.color === state.filter);
  if (!list.length) return toast("No hay subrayados todavía");
  if (els.modal.hidden) toast(`Generando ${plural(list.length)}…`);
  const sheet = await buildSheet(list);
  showModal({
    title: "Capturar todos",
    meta: `${plural(list.length)} · ${sheet.width} px · PNG`,
    note: "Orden de lectura · con número de página y barra de color",
    blob: await toBlob(sheet), name: `${safeName(state.docName)}_subrayados.png`, kind: "all",
  });
  renderSheetFilters();
  els.toast.hidden = true;
}

/* ============================================================
   Barra lateral
   ============================================================ */
const ICON = {
  shot: `<svg viewBox="0 0 24 24"><path d="M4 8V6a2 2 0 012-2h2M16 4h2a2 2 0 012 2v2M20 16v2a2 2 0 01-2 2h-2M8 20H6a2 2 0 01-2-2v-2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="12" r="3"/></svg>`,
  img: `<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5-5-8 8" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>`,
  text: `<svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M16 8V6a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2h2" fill="none" stroke="currentColor" stroke-width="2"/></svg>`,
  del: `<svg viewBox="0 0 24 24"><path d="M5 7h14M10 7V5h4v2M7 7l1 13h8l1-13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
};

function renderList() {
  const all = sortedHighlights();
  els.hlCount.textContent = all.length;

  // filtros por color
  const counts = {};
  all.forEach((h) => (counts[h.color] = (counts[h.color] || 0) + 1));
  els.filters.innerHTML = "";
  const used = ALL_COLORS.filter((c) => counts[c.id]);
  if (used.length > 1) {
    const all = document.createElement("button");
    all.className = "chip" + (state.filter ? "" : " active");
    all.textContent = "Todos";
    all.onclick = () => { state.filter = null; renderList(); };
    els.filters.appendChild(all);
    used.forEach((c) => {
      const b = document.createElement("button");
      b.className = "chip" + (state.filter === c.id ? " active" : "");
      colorVars(b, c);
      b.innerHTML = `<i></i>${counts[c.id]}`;
      b.title = `Mostrar sólo ${c.name.toLowerCase()}`;
      b.onclick = () => { state.filter = state.filter === c.id ? null : c.id; renderList(); };
      els.filters.appendChild(b);
    });
  } else state.filter = null;

  const list = all.filter((h) => !state.filter || h.color === state.filter);
  els.hlList.innerHTML = "";
  if (!list.length) {
    els.hlList.innerHTML = state.pdf
      ? `<li class="hl-empty">Selecciona texto en el PDF y elige un color.<br><b>1–3</b> color · <b>M</b> modo auto · <b>Ctrl+Z</b> deshacer</li>`
      : `<li class="hl-empty">Abre un PDF para empezar.</li>`;
    return;
  }
  for (const h of list) {
    const li = document.createElement("li");
    li.className = "hl-item" + (h.id === state.activeId ? " active" : "");
    li.dataset.id = h.id;
    colorVars(li, colorDef(h.color));
    const bar = document.createElement("span");
    bar.className = "hl-bar";
    const body = document.createElement("div");
    body.className = "hl-body";
    const txt = document.createElement("div");
    txt.className = "hl-text";
    txt.textContent = h.text || "(sin texto)";
    const meta = document.createElement("div");
    meta.className = "hl-meta";
    meta.innerHTML = `<span>p. ${h.parts.map((p) => p.page).join("–")}</span>
      <div class="hl-btns">
        <button data-a="img" title="Copiar imagen">${ICON.img}</button>
        <button data-a="text" title="Copiar texto">${ICON.text}</button>
        <button data-a="del" class="danger" title="Borrar">${ICON.del}</button>
        <button data-a="shot" class="cap" title="Ver captura">Captura</button>
      </div>`;
    body.append(txt, meta);
    li.append(bar, body);
    li.addEventListener("click", (e) => {
      const a = e.target.closest("button")?.dataset.a;
      if (a === "shot") return openShot(h);
      if (a === "img") return copyImage(captureHighlight(h).then(toBlob));
      if (a === "text") return copyText(h.text);
      if (a === "del") return deleteHighlight(h.id);
      goTo(h);
    });
    els.hlList.appendChild(li);
  }
}

function goTo(h) {
  const part = h.parts[0];
  const pv = state.pages[part.page - 1];
  const y = pv.div.offsetTop + (part.rects[0]?.[1] || 0) * pv.div.offsetHeight - els.viewer.clientHeight * 0.3;
  els.viewer.scrollTo({ top: Math.max(0, y), behavior: "smooth" });
  state.activeId = h.id;
  refreshFocus();
  setTimeout(() => {
    document.querySelectorAll(`.hl-rect[data-id="${h.id}"]`).forEach((d) => {
      d.classList.remove("flash"); void d.offsetWidth; d.classList.add("flash");
    });
  }, 350);
}

/* ============================================================
   Eventos
   ============================================================ */
function rebuildSwatches() {
  buildSwatches(els.palette, { onPick: (id) => { setColor(id); if (currentRange()) highlightSelection(id); }, withKeys: true });
  buildSwatches(els.selSwatches, { floating: true, onPick: (id) => { setColor(id); highlightSelection(id); } });
  buildSwatches(els.menuSwatches, {
    floating: true,
    onPick: (id) => {
      const h = state.highlights.find((x) => x.id === state.activeId);
      if (h) { updateHighlight(h.id, { color: id }); state.activeId = h.id; refreshFocus();
        els.menuSwatches.querySelectorAll(".swatch").forEach((b) => b.classList.toggle("active", b.dataset.color === id)); }
    },
  });
}

function bindEvents() {
  rebuildSwatches();
  buildThemes();

  document.querySelectorAll(".seg-btn[data-style]").forEach((b) =>
    b.addEventListener("click", () => {
      state.style = b.dataset.style; syncPalette(); savePrefs();
      const h = state.highlights.find((x) => x.id === state.activeId);
      if (h && !els.hlMenu.hidden) updateHighlight(h.id, { style: state.style });
    })
  );
  document.querySelectorAll(".seg-btn[data-mode]").forEach((b) =>
    b.addEventListener("click", () => setMode(b.dataset.mode))
  );
  els.markerMode.addEventListener("click", () => {
    state.markerMode = !state.markerMode; syncPalette(); savePrefs();
    toast(state.markerMode ? "Modo rotulador: subraya al soltar" : "Modo rotulador desactivado");
  });

  $("zoomIn").onclick = () => zoomStep(1);
  $("zoomOut").onclick = () => zoomStep(-1);
  els.zoomLabel.onclick = () => state.pages[0] && setScale(fitScale(state.pages[0].w), true);
  $("fileInput").addEventListener("change", (e) => openFile(e.target.files[0]));
  $("sidebarToggle").onclick = () => { document.body.classList.toggle("side-hidden"); savePrefs(); if (state.fit) setTimeout(onResize, 0); };
  $("exportAll").onclick = exportAll;
  $("copyAllText").onclick = () => {
    const list = sortedHighlights().filter((h) => !state.filter || h.color === state.filter);
    if (!list.length) return toast("No hay subrayados todavía");
    copyText(list.map((h) => `• ${h.text} (p. ${h.parts[0].page})`).join("\n\n"));
  };

  // selección
  $("selCapture").addEventListener("mousedown", (e) => e.preventDefault());
  $("selCapture").onclick = () => { const h = highlightSelection(); if (h) openShot(h); };
  $("selCopy").addEventListener("mousedown", (e) => e.preventDefault());
  $("selCopy").onclick = () => { copyText(cleanText(getSelection().toString())); };

  els.hlMenu.addEventListener("click", (e) => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    const h = state.highlights.find((x) => x.id === state.activeId);
    if (!act || !h) return;
    if (act === "capture") captureHighlight(h).then(toBlob).then((b) => { download(b, shotName(h)); toast("Captura descargada ✓"); });
    if (act === "copyimg") copyImage(captureHighlight(h).then(toBlob));
    if (act === "copytext") copyText(h.text);
    if (act === "delete") deleteHighlight(h.id);
  });

  // modal
  $("shotClose").onclick = closeShot;
  els.modal.addEventListener("click", (e) => { if (e.target === els.modal) closeShot(); });
  $("shotCopy").onclick = () => modalBlob && copyImage(Promise.resolve(modalBlob));
  $("shotDownload").onclick = () => {
    if (!modalBlob) return;
    download(modalBlob, modalName);
    toast(modalKind === "all" ? "Hoja de subrayados descargada ✓" : "Captura descargada ✓");
  };

  // mouse sobre las páginas
  let down = null;
  els.pages.addEventListener("mousedown", (e) => {
    if (e.button !== 0) return;
    down = { x: e.clientX, y: e.clientY };
    e.target.closest(".page")?.querySelector(".textLayer")?.classList.add("selecting");
    if (!e.target.closest(".float-bar")) { els.selBar.hidden = true; }
  });
  document.addEventListener("mouseup", (e) => {
    document.querySelectorAll(".textLayer.selecting").forEach((t) => t.classList.remove("selecting"));
    if (!down) return;
    const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y) > 4;
    down = null;
    setTimeout(() => {
      const range = currentRange();
      if (range) {
        if (state.markerMode) highlightSelection();
        else showSelectionBar(range);
        return;
      }
      if (!moved) {
        const h = hitTest(e.clientX, e.clientY);
        if (h) showHighlightMenu(h, e.clientX, e.clientY);
        else hideBars();
      }
    }, 0);
  });

  // cursor de mano sobre subrayados
  let raf = 0;
  els.pages.addEventListener("mousemove", (e) => {
    if (raf || e.buttons) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      els.pages.classList.toggle("over-hl", !!hitTest(e.clientX, e.clientY));
    });
  });

  els.viewer.addEventListener("scroll", () => {
    els.selBar.hidden = true; els.hlMenu.hidden = true;
    updatePageIndicator();
  }, { passive: true });

  // Ctrl + rueda = zoom del PDF
  els.viewer.addEventListener("wheel", (e) => {
    if (!e.ctrlKey || !state.pdf) return;
    e.preventDefault();
    setScale(state.scale * (e.deltaY < 0 ? 1.1 : 1 / 1.1));
  }, { passive: false });

  // teclado
  document.addEventListener("keydown", (e) => {
    if (e.target.closest?.("input, textarea")) return;
    const mod = e.ctrlKey || e.metaKey;
    if (e.key === "Escape") { closeShot(); hideBars(); getSelection().removeAllRanges(); return; }
    if (mod && e.key.toLowerCase() === "z") { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
    if (mod && e.key.toLowerCase() === "y") { e.preventDefault(); redo(); return; }
    if (mod && e.key.toLowerCase() === "o") { e.preventDefault(); $("fileInput").click(); return; }
    if (mod && (e.key === "=" || e.key === "+")) { e.preventDefault(); zoomStep(1); return; }
    if (mod && e.key === "-") { e.preventDefault(); zoomStep(-1); return; }
    if (mod && e.key === "0") { e.preventDefault(); state.pages[0] && setScale(fitScale(state.pages[0].w), true); return; }
    if (mod || e.altKey) return;
    const n = parseInt(e.key, 10);
    if (n >= 1 && n <= themeColors().length) {
      const id = themeColors()[n - 1].id;
      const active = state.highlights.find((x) => x.id === state.activeId);
      if (currentRange()) { setColor(id); highlightSelection(id); }
      else if (active && !els.hlMenu.hidden) { updateHighlight(active.id, { color: id }); state.activeId = active.id; refreshFocus(); }
      else setColor(id);
      return;
    }
    if (e.key.toLowerCase() === "h" && currentRange()) { highlightSelection(); return; }
    if (e.key.toLowerCase() === "m") { els.markerMode.click(); return; }
    if ((e.key === "Delete" || e.key === "Backspace") && state.activeId) { deleteHighlight(state.activeId); return; }
  });

  // arrastrar y soltar
  let dragDepth = 0;
  window.addEventListener("dragenter", (e) => { e.preventDefault(); dragDepth++; document.body.classList.add("dragging"); if (!state.pdf) els.empty.hidden = false; });
  window.addEventListener("dragleave", () => { if (--dragDepth <= 0) { dragDepth = 0; document.body.classList.remove("dragging"); } });
  window.addEventListener("dragover", (e) => e.preventDefault());
  window.addEventListener("drop", (e) => {
    e.preventDefault(); dragDepth = 0; document.body.classList.remove("dragging");
    const f = [...e.dataTransfer.files].find((f) => f.type === "application/pdf" || /\.pdf$/i.test(f.name));
    if (f) openFile(f); else toast("Suelta un archivo PDF");
  });

  // ajustes
  els.autoOpen.addEventListener("change", () => store.set("autoOpen", els.autoOpen.checked));
  els.openNative.addEventListener("click", () => {
    if (hasChrome && state.sourceUrl) chrome.runtime.sendMessage({ type: "open-native", url: state.sourceUrl });
  });

  window.addEventListener("resize", onResize);
}

/* Indicador «Página X de N»: se atenúa cuando dejas de desplazarte */
let pillTimer, pillRaf = 0;
function updatePageIndicator() {
  if (pillRaf) return;
  pillRaf = requestAnimationFrame(() => {
    pillRaf = 0;
    const pill = els.pageIndicator;
    if (!state.pdf || !state.pages.length) { pill.hidden = true; return; }
    const mid = els.viewer.scrollTop + els.viewer.clientHeight * 0.4;
    const pv = state.pages.find((p) => p.div.offsetTop + p.div.offsetHeight + 11 > mid) || state.pages[state.pages.length - 1];
    pill.textContent = `Página ${pv.num} de ${state.pages.length}`;
    pill.hidden = false;
    pill.classList.remove("idle");
    clearTimeout(pillTimer);
    pillTimer = setTimeout(() => pill.classList.add("idle"), 1600);
  });
}

let resizeTimer;
function onResize() {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    if (state.fit && state.pages[0]) setScale(fitScale(state.pages[0].w), true);
  }, 150);
}

/* ============================================================
   Inicio
   ============================================================ */
(async function init() {
  await loadPrefs();
  bindEvents();
  syncPalette();
  renderList();
  const file = new URLSearchParams(location.search).get("file");
  if (file) openFromUrl(file);
})();

// para pruebas
window.__subrayador = { state, highlightSelection, captureHighlight, exportAll, openDocument };
