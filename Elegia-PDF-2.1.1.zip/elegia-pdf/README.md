# Elegia PDF

Extensión de Chrome (Manifest V3) para **leer PDFs**, **subrayarlos con colores vivos** y **sacar capturas en imagen** de lo subrayado. Incluye índice navegable, salto manual de páginas e impresión con o sin los subrayados.

![Pantalla principal](docs/captura-pantalla.png)

## Características

- **4 temas de color**, cada uno con su paleta de 3 tonos (ver abajo), con mezcla *multiply*: el texto sigue legible.
- Dos estilos: bloque de rotulador o línea gruesa.
- **Índice del documento**: los marcadores del PDF en la barra lateral, con su número de página, jerarquía plegable y salto directo. Los enlaces internos impresos en el propio PDF (tablas de contenido, referencias cruzadas) también funcionan, y `Volver` regresa a donde estabas.
- **Navegación manual de páginas**: `‹ [n] de N ›` flotante, escribir el número, flechas `←` `→` y `G` para ir a una página.
- **Imprimir** el documento completo (`Ctrl+P`), con o sin los subrayados. Sin subrayados que pintar la impresión es inmediata y el texto sale vectorial; con subrayados se rasteriza a ~150 ppp, con progreso y opción de cancelar.
- Capturas PNG en alta resolución (página re-renderizada a ~2400 px de ancho): copiar al portapapeles o descargar.
- **Capturar todos**: una sola hoja con todos los subrayados en orden, con el color y la página de cada uno.
- Los subrayados se guardan automáticamente por documento (`chrome.storage.local`).
- Barra lateral con lista, filtro por color, ir al subrayado y copiar texto.
- Modo claro y oscuro (el oscuro también oscurece la página del PDF).
- Deshacer / rehacer, modo rotulador, atajos de teclado.
- Se abre automáticamente con los PDFs de Chrome (se puede desactivar).

![Ejemplo de «Capturar todos»](docs/ejemplo-capturar-todos.png)

## Temas y paletas

Se cambian con los botones de la barra superior; cada uno trae 3 colores (teclas `1`–`3`). La interfaz también toma el color de acento del tema.

| Tema | Colores |
|---|---|
| **New Order** — *Movement (1981)* | Aged paper `#D9D4C8` · Steel blue `#657A83` · Charcoal `#292C30` |
| **Francia** — *Parisian Modernism* | Azul marino `#172B55` · Marfil `#F5F0E8` · Rojo burdeos `#C93648` |
| **Rosa mexicano** — *nueva propuesta* | Rosa mexicano `#E4007C` · Rosa chicle `#F5A6C8` · Bugambilia `#7D174D` |
| **Classic** — *fluorescentes* | Amarillo `#FFFF00` · Verde `#39FF14` · Naranja `#FF8000` |

Los tonos muy oscuros (Charcoal, Azul marino, Bugambilia) se aplican con transparencia para no tapar el texto, y los muy claros (Aged paper, Marfil) llevan un borde fino para notarse sobre el papel blanco. Se ajusta en `THEMES` (`alpha`, `edge`) dentro de `viewer.js`; para añadir un tema basta con agregar otra entrada ahí.

Los subrayados guardados conservan su color aunque cambies de tema.

## Instalación

1. Clona o descarga este repositorio.
2. Abre `chrome://extensions` y activa **Modo de desarrollador**.
3. **Cargar descomprimida** → elige la carpeta del repositorio (la que contiene `manifest.json`).
4. Para PDFs locales: en **Detalles** activa **Permitir el acceso a las URL de archivo**.

## Uso

| Acción | Cómo |
|---|---|
| Abrir un PDF | Ábrelo en Chrome, clic en el ícono, `Alt+Shift+S`, clic derecho en un enlace → *Abrir PDF con Elegia PDF*, o arrástralo a la ventana |
| Subrayar | Selecciona texto y elige color en la barra flotante |
| Subrayar + capturar | Botón de cámara de la barra flotante |
| Editar un subrayado | Clic sobre él: color, captura, copiar imagen/texto, borrar |
| Moverte por el documento | Pestaña **Índice**, los enlaces del propio PDF, o el control de página de abajo |
| Imprimir | Botón de impresora o `Ctrl+P`; el interruptor *Imprimir con subrayados* decide si salen marcados |
| Hoja con todo | **Capturar todos** en la barra lateral |

### Atajos

| Tecla | Acción |
|---|---|
| `1`–`3` | Color del tema actual (con texto seleccionado, lo subraya) |
| `H` | Subrayar la selección |
| `M` | Modo rotulador (subraya al soltar el mouse) |
| `I` | Mostrar el índice / volver a los subrayados |
| `←` `→` | Página anterior / siguiente |
| `G` | Ir a una página (escribe el número y `Enter`) |
| `Alt+←` | Volver tras saltar por el índice o un enlace |
| `Ctrl+P` | Imprimir |
| `Supr` | Borrar el subrayado activo |
| `Ctrl+Z` / `Ctrl+Y` | Deshacer / rehacer |
| `Ctrl` + rueda, `Ctrl +/−`, `Ctrl+0` | Zoom / ajustar al ancho |

## Cómo funciona

Chrome no permite que las extensiones modifiquen su visor de PDF nativo, así que la extensión incluye un visor propio basado en [PDF.js](https://mozilla.github.io/pdf.js/).

```
manifest.json     Permisos y configuración MV3
background.js     Service worker: redirige los PDFs al visor, menú contextual, atajo
viewer.html/css   Interfaz del visor
viewer.js         Render de páginas, índice, navegación, subrayados, capturas, impresión
lib/              PDF.js (build min), cmaps y fuentes estándar
icons/            Íconos
docs/             Imágenes de la documentación
```

- **Selección → subrayado:** se leen los rectángulos reales de los glifos del *text layer*, se agrupan por línea y se guardan **normalizados (0–1)** por página, así sobreviven a cualquier zoom.
- **Capa de subrayados:** va entre el canvas del PDF y el text layer, con `mix-blend-mode: multiply`.
- **Índice y enlaces:** `getOutline()` da los marcadores y `getAnnotations()` los enlaces de cada página; ambos destinos se resuelven con `getPageIndex()` a página + posición vertical, y se cachean. Los enlaces van en su propia capa encima del texto, desactivada mientras arrastras para seleccionar.
- **Capturas:** la página se re-renderiza a alta resolución, se recorta la zona subrayada y se dibujan los subrayados sobre el canvas.
- **Impresión:** hay dos rutas. Si no hay subrayados que pintar (ninguno, o el interruptor apagado) el PDF original se imprime tal cual desde un `iframe` con su `blob:` — inmediato y vectorial, sin rasterizar nada. Si hay subrayados que pintar no queda otra que rasterizar: cada página se renderiza a ~150 ppp (tope de 16 MP por página) con `intent: "print"`, se le pintan encima los subrayados y se arma todo en un contenedor que solo existe en `@media print`, con `@page` del tamaño real del PDF. Esa ruta va de 2 a 3 páginas en paralelo, espera los `decode()` al final y se puede cancelar a media preparación. Si la ruta directa falla (por ejemplo, si Chrome está configurado para descargar los PDFs en vez de abrirlos) cae sola a la rasterizada.
- **Datos:** clave `doc:<fingerprint del PDF>`, así que los subrayados reaparecen aunque cambies el archivo de lugar.

## Permisos

| Permiso | Para qué |
|---|---|
| `storage` | Guardar subrayados y preferencias |
| `webRequest` + `<all_urls>` | Detectar respuestas `application/pdf` y abrirlas en el visor |
| `tabs`, `contextMenus` | Redirigir pestañas y menú de clic derecho |
| `clipboardWrite` | Copiar imágenes y texto |

Todo ocurre en local; la extensión no envía datos a ningún servidor.

## Limitaciones

- Solo PDFs con capa de texto. Los escaneados necesitan OCR (no incluido).
- Los subrayados no se escriben dentro del PDF; viven en la extensión.
- El índice depende de que el PDF traiga marcadores; si no los trae, quedan los enlaces impresos y el salto por número de página.
- Imprimir **con** los subrayados rasteriza las páginas, así que ese PDF impreso no conserva el texto seleccionable y tarda más cuanto más largo sea el documento. Imprimir sin ellos no tiene ninguna de las dos desventajas.

## Ideas a futuro

- Exportar subrayados a Markdown / JSON.
- Notas en cada subrayado.
- Guardar un PDF con las anotaciones incrustadas.
- Buscar texto dentro del documento.
- OCR para PDFs escaneados.

## Licencia

MIT — ver [LICENSE](LICENSE). Incluye PDF.js (Apache-2.0) en `lib/`.
